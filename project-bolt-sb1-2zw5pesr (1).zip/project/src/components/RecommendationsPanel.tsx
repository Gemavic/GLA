import { useEffect, useState } from 'react';
import { Lightbulb, TrendingUp, BookOpen, Target, X, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Recommendation {
  id: string;
  recommendation_type: string;
  title: string;
  description: string;
  reason: string;
  confidence_score: number;
  priority: number;
  is_viewed: boolean;
  is_acted_on: boolean;
}

export default function RecommendationsPanel() {
  const { user } = useAuth();
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadRecommendations();
    }
  }, [user]);

  const loadRecommendations = async () => {
    try {
      setLoading(true);
      const { data } = await supabase
        .from('learning_recommendations')
        .select('*')
        .eq('user_id', user?.id)
        .order('priority', { ascending: false })
        .limit(5);

      if (data) {
        setRecommendations(data);
      }
    } catch (error) {
      console.error('Error loading recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsViewed = async (id: string) => {
    await supabase
      .from('learning_recommendations')
      .update({ is_viewed: true })
      .eq('id', id);

    setRecommendations(prev =>
      prev.map(r => r.id === id ? { ...r, is_viewed: true } : r)
    );
  };

  const markAsActedOn = async (id: string) => {
    await supabase
      .from('learning_recommendations')
      .update({ is_acted_on: true })
      .eq('id', id);

    setRecommendations(prev => prev.filter(r => r.id !== id));
  };

  const dismissRecommendation = async (id: string) => {
    await supabase
      .from('learning_recommendations')
      .delete()
      .eq('id', id);

    setRecommendations(prev => prev.filter(r => r.id !== id));
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'course': return <BookOpen className="h-5 w-5" />;
      case 'lesson': return <Target className="h-5 w-5" />;
      case 'study_time': return <TrendingUp className="h-5 w-5" />;
      default: return <Lightbulb className="h-5 w-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'course': return 'text-blue-600 bg-blue-50';
      case 'lesson': return 'text-purple-600 bg-purple-50';
      case 'study_time': return 'text-green-600 bg-green-50';
      default: return 'text-orange-600 bg-orange-50';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (recommendations.length === 0) {
    return (
      <div className="text-center p-8 bg-gray-50 rounded-lg">
        <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-3" />
        <p className="text-gray-600">No recommendations available</p>
        <p className="text-sm text-gray-500 mt-1">
          Keep learning and we'll suggest personalized content for you
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <Lightbulb className="h-6 w-6 text-yellow-500" />
        <h3 className="text-lg font-semibold text-gray-900">Recommended for You</h3>
      </div>

      {recommendations.map((rec) => (
        <div
          key={rec.id}
          className={`border-2 rounded-lg p-4 transition-all ${
            rec.is_viewed ? 'border-gray-200 bg-white' : 'border-blue-200 bg-blue-50'
          }`}
          onMouseEnter={() => !rec.is_viewed && markAsViewed(rec.id)}
        >
          <div className="flex items-start space-x-3">
            <div className={`flex-shrink-0 p-2 rounded-lg ${getTypeColor(rec.recommendation_type)}`}>
              {getTypeIcon(rec.recommendation_type)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{rec.title}</h4>
                  <p className="text-sm text-gray-600 mt-1">{rec.description}</p>
                  {rec.reason && (
                    <div className="flex items-start space-x-2 mt-2 p-2 bg-white rounded border border-gray-200">
                      <TrendingUp className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-gray-600">{rec.reason}</p>
                    </div>
                  )}
                  <div className="flex items-center space-x-4 mt-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-600 h-2 rounded-full"
                          style={{ width: `${rec.confidence_score}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500">{rec.confidence_score}% match</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => dismissRecommendation(rec.id)}
                  className="ml-2 p-1 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="flex items-center space-x-2 mt-3">
                <button
                  onClick={() => markAsActedOn(rec.id)}
                  className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Check className="h-4 w-4" />
                  <span>Start Now</span>
                </button>
                <button
                  onClick={() => dismissRecommendation(rec.id)}
                  className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  Not interested
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
