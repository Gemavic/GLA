import { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, Clock, Target, BookOpen, Award, BarChart3, Activity } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Analytics {
  total_time_spent_minutes: number;
  lessons_completed: number;
  average_assignment_score: number;
  average_quiz_score: number;
  engagement_score: number;
  performance_trend: string;
  assignments_submitted: number;
  quizzes_passed: number;
  discussions_created: number;
}

interface PerformanceData {
  week: string;
  score: number;
  activity: number;
}

export default function AnalyticsDashboard() {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([]);

  useEffect(() => {
    if (user) {
      loadAnalytics();
      generatePerformanceData();
    }
  }, [user]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const { data } = await supabase
        .from('student_analytics')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (data) {
        setAnalytics(data);
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const generatePerformanceData = () => {
    const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'];
    const data = weeks.map((week, index) => ({
      week,
      score: Math.floor(70 + Math.random() * 20 + index * 2),
      activity: Math.floor(60 + Math.random() * 30 + index * 3)
    }));
    setPerformanceData(data);
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getTrendIcon = (trend: string) => {
    if (trend === 'improving') return <TrendingUp className="h-5 w-5 text-green-600" />;
    if (trend === 'declining') return <TrendingDown className="h-5 w-5 text-red-600" />;
    return <Activity className="h-5 w-5 text-blue-600" />;
  };

  const getTrendColor = (trend: string) => {
    if (trend === 'improving') return 'text-green-600 bg-green-50';
    if (trend === 'declining') return 'text-red-600 bg-red-50';
    return 'text-blue-600 bg-blue-50';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="text-center p-12">
        <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No analytics data available yet</p>
        <p className="text-sm text-gray-500 mt-2">Start learning to see your progress!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Study Time</span>
            <Clock className="h-5 w-5 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            {formatTime(analytics.total_time_spent_minutes)}
          </p>
          <p className="text-xs text-gray-500 mt-1">Total learning time</p>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Completion Rate</span>
            <BookOpen className="h-5 w-5 text-green-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            {analytics.lessons_completed}
          </p>
          <p className="text-xs text-gray-500 mt-1">Lessons completed</p>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Avg. Score</span>
            <Target className="h-5 w-5 text-purple-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            {Math.round((analytics.average_assignment_score + analytics.average_quiz_score) / 2)}%
          </p>
          <p className="text-xs text-gray-500 mt-1">Overall performance</p>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Engagement</span>
            <Award className="h-5 w-5 text-orange-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            {Math.round(analytics.engagement_score)}%
          </p>
          <p className="text-xs text-gray-500 mt-1">Activity score</p>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Performance Trend</h3>
          <div className={`flex items-center space-x-2 px-3 py-1 rounded-lg ${getTrendColor(analytics.performance_trend)}`}>
            {getTrendIcon(analytics.performance_trend)}
            <span className="text-sm font-medium capitalize">{analytics.performance_trend}</span>
          </div>
        </div>

        <div className="space-y-4">
          {performanceData.map((data, index) => (
            <div key={index}>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-600 font-medium">{data.week}</span>
                <span className="text-gray-900 font-semibold">{data.score}%</span>
              </div>
              <div className="relative w-full bg-gray-200 rounded-full h-3">
                <div
                  className="absolute top-0 left-0 h-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all"
                  style={{ width: `${data.score}%` }}
                />
                <div
                  className="absolute top-0 left-0 h-3 rounded-full bg-green-500 opacity-30"
                  style={{ width: `${data.activity}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center space-x-6 mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-gradient-to-r from-blue-500 to-purple-500"></div>
            <span className="text-sm text-gray-600">Performance Score</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-green-500 opacity-30"></div>
            <span className="text-sm text-gray-600">Activity Level</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-3 rounded-lg">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-900">
                {analytics.assignments_submitted}
              </p>
              <p className="text-sm text-blue-700">Assignments Submitted</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-blue-200">
            <p className="text-sm text-blue-800">
              Average Score: <span className="font-bold">{Math.round(analytics.average_assignment_score)}%</span>
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-6 border border-purple-200">
          <div className="flex items-center space-x-3">
            <div className="bg-purple-600 p-3 rounded-lg">
              <Target className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-900">
                {analytics.quizzes_passed}
              </p>
              <p className="text-sm text-purple-700">Quizzes Passed</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-purple-200">
            <p className="text-sm text-purple-800">
              Average Score: <span className="font-bold">{Math.round(analytics.average_quiz_score)}%</span>
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-6 border border-green-200">
          <div className="flex items-center space-x-3">
            <div className="bg-green-600 p-3 rounded-lg">
              <Award className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-900">
                {analytics.discussions_created}
              </p>
              <p className="text-sm text-green-700">Discussion Posts</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-green-200">
            <p className="text-sm text-green-800">
              Great participation!
            </p>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold mb-2">Keep Up The Great Work!</h3>
            <p className="text-blue-100">
              You're making excellent progress. Stay focused and keep learning!
            </p>
          </div>
          <BarChart3 className="h-16 w-16 text-white opacity-50" />
        </div>
      </div>
    </div>
  );
}
