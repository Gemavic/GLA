import { useEffect, useState } from 'react';
import { Trophy, Medal, Award, TrendingUp, Zap, Crown, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface LeaderboardEntry {
  id: string;
  user_id: string;
  display_name: string;
  total_points: number;
  assignments_completed: number;
  quizzes_completed: number;
  discussions_posted: number;
  courses_completed: number;
  achievements_earned: number;
  current_streak: number;
  rank: number;
}

export default function Leaderboard() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [userEntry, setUserEntry] = useState<LeaderboardEntry | null>(null);
  const [period, setPeriod] = useState<'all_time' | 'monthly' | 'weekly'>('all_time');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboard();
  }, [period]);

  const loadLeaderboard = async () => {
    try {
      setLoading(true);
      const { data } = await supabase
        .from('leaderboard_entries')
        .select('*')
        .eq('period', period)
        .is('course_id', null)
        .order('rank', { ascending: true })
        .limit(50);

      if (data) {
        setEntries(data);
        const myEntry = data.find(e => e.user_id === user?.id);
        setUserEntry(myEntry || null);
      }
    } catch (error) {
      console.error('Error loading leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankBadge = (rank: number) => {
    if (rank === 1) {
      return <Crown className="h-6 w-6 text-yellow-500" />;
    } else if (rank === 2) {
      return <Medal className="h-6 w-6 text-gray-400" />;
    } else if (rank === 3) {
      return <Medal className="h-6 w-6 text-orange-600" />;
    }
    return <span className="text-gray-600 font-semibold">#{rank}</span>;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-300';
    if (rank === 2) return 'bg-gradient-to-r from-gray-50 to-gray-100 border-gray-300';
    if (rank === 3) return 'bg-gradient-to-r from-orange-50 to-orange-100 border-orange-300';
    return 'bg-white border-gray-200';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
            <Trophy className="h-8 w-8 text-yellow-500" />
            <span>Leaderboard</span>
          </h2>
          <p className="text-gray-600 mt-1">See how you rank against other students</p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setPeriod('weekly')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              period === 'weekly'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            This Week
          </button>
          <button
            onClick={() => setPeriod('monthly')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              period === 'monthly'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setPeriod('all_time')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              period === 'all_time'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All Time
          </button>
        </div>
      </div>

      {userEntry && (
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-white bg-opacity-20 rounded-full p-3">
                <Star className="h-8 w-8" />
              </div>
              <div>
                <p className="text-blue-100 text-sm">Your Ranking</p>
                <p className="text-2xl font-bold">#{userEntry.rank}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-blue-100 text-sm">Total Points</p>
              <p className="text-3xl font-bold">{userEntry.total_points}</p>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-4 mt-6 pt-6 border-t border-white border-opacity-20">
            <div className="text-center">
              <p className="text-2xl font-bold">{userEntry.assignments_completed}</p>
              <p className="text-xs text-blue-100 mt-1">Assignments</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{userEntry.quizzes_completed}</p>
              <p className="text-xs text-blue-100 mt-1">Quizzes</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{userEntry.courses_completed}</p>
              <p className="text-xs text-blue-100 mt-1">Courses</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold flex items-center justify-center space-x-1">
                <Zap className="h-5 w-5" />
                <span>{userEntry.current_streak}</span>
              </p>
              <p className="text-xs text-blue-100 mt-1">Day Streak</p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rank
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Points
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Completed
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Streak
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Badges
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {entries.map((entry, index) => {
                const isCurrentUser = entry.user_id === user?.id;
                return (
                  <tr
                    key={entry.id}
                    className={`${getRankColor(entry.rank)} border-2 ${
                      isCurrentUser ? 'ring-2 ring-blue-500' : ''
                    } transition-colors hover:bg-gray-50`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {getRankBadge(entry.rank)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                          {entry.display_name.charAt(0).toUpperCase()}
                        </div>
                        <div className="ml-3">
                          <div className="text-sm font-medium text-gray-900 flex items-center space-x-2">
                            <span>{entry.display_name}</span>
                            {isCurrentUser && (
                              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-medium rounded">
                                You
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-bold text-gray-900">{entry.total_points}</div>
                      <div className="text-xs text-gray-500">points</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {entry.assignments_completed + entry.quizzes_completed}
                      </div>
                      <div className="text-xs text-gray-500">activities</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-1">
                        <Zap className={`h-4 w-4 ${entry.current_streak > 0 ? 'text-orange-500' : 'text-gray-400'}`} />
                        <span className="text-sm font-semibold text-gray-900">{entry.current_streak}</span>
                        <span className="text-xs text-gray-500">days</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-1">
                        <Award className="h-4 w-4 text-purple-600" />
                        <span className="text-sm font-semibold text-gray-900">{entry.achievements_earned}</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {entries.length === 0 && (
        <div className="text-center p-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
          <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No leaderboard data yet</p>
          <p className="text-sm text-gray-500 mt-2">
            Start completing assignments and quizzes to climb the leaderboard!
          </p>
        </div>
      )}

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <TrendingUp className="h-5 w-5 text-blue-600 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-blue-900 mb-1">How to Climb the Leaderboard</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Complete assignments and quizzes to earn points</li>
              <li>• Maintain a learning streak by logging in daily</li>
              <li>• Participate in discussions to earn bonus points</li>
              <li>• Complete courses to unlock achievements</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
