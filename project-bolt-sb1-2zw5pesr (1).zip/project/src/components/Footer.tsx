import { MapPin, Phone, Mail, GraduationCap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <GraduationCap className="w-8 h-8 text-cyan-400" />
              <span className="text-2xl font-bold">Gemavic Learning Academy</span>
            </div>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Your trusted partner in educational excellence. Our Professional Hybrid Solution combines structured prep classes with personalized tutorial programs for measurable learning outcomes aligned with industry standards.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-cyan-400">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">About Us</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Professional Hybrid Solution</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Online Courses</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Admissions</a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-cyan-400">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">
                  1, Oluwagbemiga Street<br />
                  Beach Front Orufun<br />
                  Ibeju-Lekki, 105101<br />
                  Lagos State, Nigeria
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div className="text-gray-300 text-sm space-y-1">
                  <a href="tel:+2348069841614" className="block hover:text-white transition-colors">
                    +234 806 984 1614
                  </a>
                  <a href="tel:+2348034180915" className="block hover:text-white transition-colors">
                    +234 803 418 0915
                  </a>
                  <a href="tel:+16138615799" className="block hover:text-white transition-colors">
                    +1 613 861 5799
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} Gemavic Learning Academy. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}