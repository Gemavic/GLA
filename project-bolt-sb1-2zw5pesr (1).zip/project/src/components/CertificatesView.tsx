import { useEffect, useState } from 'react';
import { Award, Download, Share2, CheckCircle, ExternalLink } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Certificate {
  id: string;
  certificate_number: string;
  student_name: string;
  course_title: string;
  completion_date: string;
  grade: string;
  final_score: number;
  instructor_name: string;
  verification_url: string;
  issued_at: string;
}

export default function CertificatesView() {
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);

  useEffect(() => {
    if (user) {
      loadCertificates();
    }
  }, [user]);

  const loadCertificates = async () => {
    try {
      setLoading(true);
      const { data } = await supabase
        .from('certificates')
        .select('*')
        .eq('user_id', user?.id)
        .order('issued_at', { ascending: false });

      if (data) {
        setCertificates(data);
      }
    } catch (error) {
      console.error('Error loading certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const getGradeColor = (grade: string) => {
    if (grade === 'A') return 'text-green-600 bg-green-100';
    if (grade === 'B') return 'text-blue-600 bg-blue-100';
    if (grade === 'C') return 'text-yellow-600 bg-yellow-100';
    return 'text-gray-600 bg-gray-100';
  };

  const handleShare = (cert: Certificate) => {
    if (navigator.share) {
      navigator.share({
        title: `Certificate - ${cert.course_title}`,
        text: `I just completed ${cert.course_title} with a grade of ${cert.grade}!`,
        url: cert.verification_url
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {certificates.length === 0 ? (
        <div className="text-center p-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
          <Award className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No Certificates Yet</h3>
          <p className="text-gray-600">
            Complete courses to earn certificates you can share with employers and on social media
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              className="bg-white border-2 border-gray-200 rounded-lg overflow-hidden hover:border-blue-400 hover:shadow-lg transition-all cursor-pointer"
              onClick={() => setSelectedCert(cert)}
            >
              <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-6 text-white">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-3">
                      <Award className="h-8 w-8" />
                      <span className="text-sm font-medium opacity-90">Certificate of Completion</span>
                    </div>
                    <h3 className="text-xl font-bold mb-2">{cert.course_title}</h3>
                    <p className="text-blue-100 text-sm">Issued to {cert.student_name}</p>
                  </div>
                  <div className={`px-3 py-1 rounded-lg font-bold text-lg ${getGradeColor(cert.grade)} bg-white`}>
                    {cert.grade}
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Completion Date</p>
                    <p className="text-sm font-semibold text-gray-900">{formatDate(cert.completion_date)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Final Score</p>
                    <p className="text-sm font-semibold text-gray-900">{cert.final_score}%</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-xs text-gray-500 mb-1">Certificate Number</p>
                    <p className="text-sm font-mono text-gray-900">{cert.certificate_number}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 pt-4 border-t border-gray-200">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(cert.verification_url, '_blank');
                    }}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download</span>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleShare(cert);
                    }}
                    className="flex items-center justify-center px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <Share2 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(cert.verification_url, '_blank');
                    }}
                    className="flex items-center justify-center px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedCert && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-8 text-white text-center relative">
              <button
                onClick={() => setSelectedCert(null)}
                className="absolute top-4 right-4 text-white hover:text-gray-200"
              >
                <span className="text-2xl">&times;</span>
              </button>
              <Award className="h-20 w-20 mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-2">Certificate of Completion</h2>
              <p className="text-blue-100">Gemavic Learning Academy</p>
            </div>

            <div className="p-8 text-center">
              <p className="text-gray-600 mb-2">This certifies that</p>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">{selectedCert.student_name}</h3>
              <p className="text-gray-600 mb-2">has successfully completed</p>
              <h4 className="text-2xl font-bold text-gray-900 mb-6">{selectedCert.course_title}</h4>

              <div className="flex items-center justify-center space-x-8 mb-6">
                <div className="text-center">
                  <p className="text-sm text-gray-500 mb-1">Grade</p>
                  <div className={`text-3xl font-bold px-6 py-3 rounded-lg ${getGradeColor(selectedCert.grade)}`}>
                    {selectedCert.grade}
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-500 mb-1">Score</p>
                  <div className="text-3xl font-bold text-blue-600">
                    {selectedCert.final_score}%
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <p className="text-sm text-gray-500 mb-1">Date of Completion</p>
                <p className="text-lg font-semibold text-gray-900">{formatDate(selectedCert.completion_date)}</p>
              </div>

              <div className="border-t border-gray-200 pt-6 mb-6">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <p className="text-sm text-gray-600">Verified Certificate</p>
                </div>
                <p className="text-xs font-mono text-gray-500">{selectedCert.certificate_number}</p>
              </div>

              <div className="text-sm text-gray-600 mb-6">
                <p>Instructor: <span className="font-semibold">{selectedCert.instructor_name}</span></p>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={() => window.open(selectedCert.verification_url, '_blank')}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  <Download className="h-5 w-5" />
                  <span>Download Certificate</span>
                </button>
                <button
                  onClick={() => handleShare(selectedCert)}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                  Share
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
