import { useRef, useEffect, useState } from 'react';
import {
  RotateCcw,
  Minus,
  Circle,
  Type,
  Download,
  Trash2,
  Palette,
  Square,
  PenTool
} from 'lucide-react';

interface WhiteboardProps {
  sessionId: string;
  isInstructor?: boolean;
}

interface DrawState {
  startX: number;
  startY: number;
}

export default function Whiteboard({ sessionId, isInstructor }: WhiteboardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<'pen' | 'eraser' | 'line' | 'circle' | 'rectangle' | 'text'>('pen');
  const [color, setColor] = useState('#1f2937');
  const [size, setSize] = useState(3);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [drawState, setDrawState] = useState<DrawState | null>(null);
  const baseImageRef = useRef<ImageData | null>(null);

  const canEdit = isInstructor !== false;

  useEffect(() => {
    const setupCanvas = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const rect = container.getBoundingClientRect();
      canvas.width = Math.floor(rect.width);
      canvas.height = Math.floor(rect.height);

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#f3f4f6';

      for (let i = 0; i < canvas.width; i += 20) {
        ctx.fillRect(i, 0, 1, canvas.height);
      }
      for (let i = 0; i < canvas.height; i += 20) {
        ctx.fillRect(0, i, canvas.width, 1);
      }

      const initialState = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory([initialState]);
      baseImageRef.current = initialState;
    };

    setupCanvas();
    window.addEventListener('resize', setupCanvas);
    return () => window.removeEventListener('resize', setupCanvas);
  }, []);

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: Math.round(e.clientX - rect.left),
      y: Math.round(e.clientY - rect.top)
    };
  };

  const saveState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const newHistory = [...history, ctx.getImageData(0, 0, canvas.width, canvas.height)];
    setHistory(newHistory);
    baseImageRef.current = ctx.getImageData(0, 0, canvas.width, canvas.height);
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canEdit) return;
    setIsDrawing(true);

    const pos = getMousePos(e);
    setDrawState({ startX: pos.x, startY: pos.y });

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = size;
    ctx.strokeStyle = color;
    ctx.fillStyle = color;

    if (tool === 'pen' || tool === 'eraser') {
      if (tool === 'pen') {
        ctx.globalCompositeOperation = 'source-over';
      } else {
        ctx.globalCompositeOperation = 'destination-out';
      }
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    }
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    setDrawState(null);

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx) {
      ctx.closePath();
    }
    saveState();
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !drawState) return;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const pos = getMousePos(e);

    if (tool === 'pen') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.clearRect(pos.x - size / 2, pos.y - size / 2, size, size);
    } else if (tool === 'line' || tool === 'circle' || tool === 'rectangle') {
      if (baseImageRef.current) {
        ctx.putImageData(baseImageRef.current, 0, 0);
      }

      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = size;

      if (tool === 'line') {
        ctx.beginPath();
        ctx.moveTo(drawState.startX, drawState.startY);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
      } else if (tool === 'circle') {
        const radius = Math.sqrt(
          Math.pow(pos.x - drawState.startX, 2) + Math.pow(pos.y - drawState.startY, 2)
        );
        ctx.beginPath();
        ctx.arc(drawState.startX, drawState.startY, radius, 0, 2 * Math.PI);
        ctx.stroke();
      } else if (tool === 'rectangle') {
        const width = pos.x - drawState.startX;
        const height = pos.y - drawState.startY;
        ctx.strokeRect(drawState.startX, drawState.startY, width, height);
      }
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#f3f4f6';
    for (let i = 0; i < canvas.width; i += 20) {
      ctx.fillRect(i, 0, 1, canvas.height);
    }
    for (let i = 0; i < canvas.height; i += 20) {
      ctx.fillRect(0, i, canvas.width, 1);
    }
    saveState();
  };

  const undoDrawing = () => {
    if (history.length > 1) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const newHistory = [...history];
      newHistory.pop();
      const lastState = newHistory[newHistory.length - 1];
      ctx.putImageData(lastState, 0, 0);
      setHistory(newHistory);
      baseImageRef.current = lastState;
    }
  };

  const downloadWhiteboard = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = `whiteboard-${Date.now()}.png`;
    link.click();
  };

  const presetColors = ['#1f2937', '#dc2626', '#2563eb', '#16a34a', '#9333ea', '#ea580c'];

  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 text-white p-3 border-b border-slate-900">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold">Whiteboard</h3>
          <div className="text-xs opacity-75">{sessionId.slice(0, 8)}</div>
        </div>

        {canEdit && (
          <div className="flex flex-wrap gap-2 mt-3">
            <div className="flex gap-1 bg-black bg-opacity-20 rounded p-1">
              <button
                onClick={() => setTool('pen')}
                className={`p-2 rounded text-xs transition-all ${
                  tool === 'pen' ? 'bg-white text-slate-700' : 'hover:bg-white hover:bg-opacity-10'
                }`}
                title="Pen"
              >
                <PenTool className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTool('eraser')}
                className={`p-2 rounded text-xs transition-all ${
                  tool === 'eraser' ? 'bg-white text-slate-700' : 'hover:bg-white hover:bg-opacity-10'
                }`}
                title="Eraser"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTool('line')}
                className={`p-2 rounded text-xs transition-all ${
                  tool === 'line' ? 'bg-white text-slate-700' : 'hover:bg-white hover:bg-opacity-10'
                }`}
                title="Line"
              >
                <Minus className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTool('circle')}
                className={`p-2 rounded text-xs transition-all ${
                  tool === 'circle' ? 'bg-white text-slate-700' : 'hover:bg-white hover:bg-opacity-10'
                }`}
                title="Circle"
              >
                <Circle className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTool('rectangle')}
                className={`p-2 rounded text-xs transition-all ${
                  tool === 'rectangle' ? 'bg-white text-slate-700' : 'hover:bg-white hover:bg-opacity-10'
                }`}
                title="Rectangle"
              >
                <Square className="w-4 h-4" />
              </button>
            </div>

            <div className="flex gap-1">
              {presetColors.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={`w-6 h-6 rounded border-2 transition-all ${
                    color === c ? 'border-white scale-110' : 'border-white border-opacity-30'
                  }`}
                  style={{ backgroundColor: c }}
                  title={`Color ${c}`}
                />
              ))}
              <div className="relative">
                <button
                  onClick={() => setShowColorPicker(!showColorPicker)}
                  className="p-1 rounded bg-black bg-opacity-20 hover:bg-opacity-30 transition-all"
                  title="More colors"
                >
                  <Palette className="w-4 h-4" />
                </button>
                {showColorPicker && (
                  <div className="absolute top-full mt-1 left-0 bg-white rounded shadow-xl p-2 z-50">
                    <input
                      type="color"
                      value={color}
                      onChange={(e) => setColor(e.target.value)}
                      className="w-12 h-8 cursor-pointer rounded"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1 bg-black bg-opacity-20 rounded px-2">
              <span className="text-xs">Size:</span>
              <input
                type="range"
                min="1"
                max="15"
                value={size}
                onChange={(e) => setSize(parseInt(e.target.value))}
                className="w-16 cursor-pointer h-1"
              />
              <span className="text-xs w-4">{size}</span>
            </div>

            <div className="flex gap-1 bg-black bg-opacity-20 rounded p-1 ml-auto">
              <button
                onClick={undoDrawing}
                className="p-2 rounded hover:bg-white hover:bg-opacity-10 transition-all disabled:opacity-50"
                disabled={history.length <= 1}
                title="Undo"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={clearCanvas}
                className="p-2 rounded hover:bg-white hover:bg-opacity-10 transition-all"
                title="Clear"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={downloadWhiteboard}
                className="p-2 rounded hover:bg-white hover:bg-opacity-10 transition-all"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {!canEdit && (
          <div className="text-xs bg-white bg-opacity-10 rounded px-2 py-1 mt-2 w-fit">
            Read-only mode
          </div>
        )}
      </div>

      <div
        ref={containerRef}
        className="flex-1 overflow-hidden bg-white relative"
      >
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseUp={stopDrawing}
          onMouseMove={draw}
          onMouseLeave={stopDrawing}
          className={`absolute inset-0 ${canEdit ? 'cursor-crosshair' : 'cursor-default'}`}
          style={{ width: '100%', height: '100%', display: 'block' }}
        />
      </div>
    </div>
  );
}
