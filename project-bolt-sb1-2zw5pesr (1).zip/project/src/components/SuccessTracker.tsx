import { useState, useEffect } from 'react';
import { Trophy, TrendingUp, BookOpen, Save, History, X, ChevronDown, Printer, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface SubjectScore {
  name: string;
  score: number;
  grade: string;
  points: number;
}

interface ProgressSnapshot {
  id: string;
  exam_provider: string;
  student_name: string | null;
  exam_number: string | null;
  exam_centre: string | null;
  total_points: number;
  bonus_points: number;
  final_score: number;
  status: string;
  subjects_data: SubjectScore[];
  created_at: string;
}

interface ExamProvider {
  id: string;
  name: string;
  description: string;
  subjects: string[];
  maxScore: number;
  minScore: number;
  inputLabel: string;
}

const EXAM_PROVIDERS: ExamProvider[] = [
  {
    id: 'cambridge',
    name: 'Cambridge A-Level',
    description: 'Advanced Level Certificate',
    subjects: ['Mathematics', 'Physics', 'Computer Science', 'Chemistry', 'Further Mathematics', 'Biology'],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Mock Average (%)'
  },
  {
    id: 'waec',
    name: 'WAEC',
    description: 'West African Examinations Council',
    subjects: [
      'Mathematics',
      'English Language',
      'Physics',
      'Chemistry',
      'Biology',
      'Further Mathematics',
      'Economics',
      'Government',
      'Literature in English',
      'Civic Education',
      'Geography',
      'Commerce',
      'Accounting',
      'Computer Science',
      'Data Processing',
      'Agricultural Science',
      'Animal Husbandry',
      'Fishery',
      'Christian Religious Studies',
      'Islamic Studies',
      'History',
      'Fine Arts',
      'Technical Drawing',
      'Home Economics',
      'Food and Nutrition',
      'Physical Education',
      'Catering Craft Practice',
      'French',
      'Yoruba',
      'Hausa',
      'Igbo'
    ],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Expected Score (%)'
  },
  {
    id: 'neco',
    name: 'NECO',
    description: 'National Examinations Council',
    subjects: [
      'Mathematics',
      'English Language',
      'Physics',
      'Chemistry',
      'Biology',
      'Further Mathematics',
      'Economics',
      'Government',
      'Literature in English',
      'Civic Education',
      'Geography',
      'Commerce',
      'Accounting',
      'Computer Science',
      'Data Processing',
      'Agricultural Science',
      'Animal Husbandry',
      'Fishery',
      'Christian Religious Studies',
      'Islamic Studies',
      'History',
      'Fine Arts',
      'Technical Drawing',
      'Home Economics',
      'Food and Nutrition',
      'Physical Education',
      'Catering Craft Practice',
      'French',
      'Yoruba',
      'Hausa',
      'Igbo'
    ],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Expected Score (%)'
  },
  {
    id: 'jamb',
    name: 'JAMB UTME',
    description: 'Unified Tertiary Matriculation Examination',
    subjects: [
      'Use of English',
      'Mathematics',
      'Physics',
      'Chemistry',
      'Biology',
      'Economics',
      'Government',
      'Literature in English',
      'Commerce',
      'Accounting',
      'Geography',
      'Civic Education',
      'Christian Religious Studies',
      'Islamic Studies',
      'Agricultural Science',
      'Computer Studies'
    ],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Expected Score (out of 100 per subject)'
  },
  {
    id: 'nabteb',
    name: 'NABTEB',
    description: 'National Business and Technical Examinations Board',
    subjects: [
      'Mathematics',
      'English Language',
      'Civic Education',
      'Commerce',
      'Accounting',
      'Economics',
      'Business Studies',
      'Office Practice',
      'Marketing',
      'Computer Science',
      'Data Processing',
      'Physics',
      'Chemistry',
      'Biology',
      'Agricultural Science',
      'Animal Husbandry',
      'Fishery',
      'Technical Drawing',
      'Basic Electronics',
      'Basic Electricity',
      'Metal Work',
      'Wood Work',
      'Auto Mechanics',
      'Building Construction',
      'Home Economics',
      'Food and Nutrition',
      'Catering Craft Practice',
      'Clothing and Textiles',
      'Auto Body Repair and Spray Painting',
      'Printing Craft Practice',
      'Welding and Fabrication',
      'Plumbing and Pipe Fitting'
    ],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Expected Score (%)'
  },
  {
    id: 'igcse',
    name: 'IGCSE',
    description: 'International General Certificate of Secondary Education',
    subjects: ['Mathematics', 'English Language', 'Physics', 'Chemistry', 'Biology', 'Computer Science', 'Economics', 'Business Studies'],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Mock Score (%)'
  },
  {
    id: 'ijmb',
    name: 'IJMB A-Level',
    description: 'Interim Joint Matriculation Board',
    subjects: [
      'Mathematics',
      'English Language',
      'Physics',
      'Chemistry',
      'Biology',
      'Further Mathematics',
      'Economics',
      'Geography',
      'Government',
      'Literature in English',
      'Islamic Studies',
      'Christian Religious Studies',
      'Computer Science',
      'French',
      'Arabic',
      'Hausa',
      'Accounting'
    ],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Mock Average (%)'
  },
  {
    id: 'jupeb',
    name: 'JUPEB A-Level',
    description: 'Joint Universities Preliminary Examinations Board',
    subjects: [
      'Mathematics',
      'English Language',
      'Physics',
      'Chemistry',
      'Biology',
      'Further Mathematics',
      'Economics',
      'Geography',
      'Government',
      'Literature in English',
      'Islamic Studies',
      'Christian Religious Studies',
      'Computer Science',
      'French',
      'Arabic',
      'Hausa',
      'Accounting',
      'Commerce'
    ],
    maxScore: 100,
    minScore: 0,
    inputLabel: 'Mock Average (%)'
  }
];

function calculateCambridgeGrade(score: number): { grade: string; points: number } {
  if (score >= 80) return { grade: 'A', points: 5 };
  if (score >= 70) return { grade: 'B', points: 4 };
  if (score >= 60) return { grade: 'C', points: 3 };
  if (score >= 50) return { grade: 'D', points: 2 };
  if (score >= 40) return { grade: 'E', points: 1 };
  return { grade: 'F', points: 0 };
}

function calculateWAECGrade(score: number): { grade: string; points: number } {
  if (score >= 75) return { grade: 'A1', points: 9 };
  if (score >= 70) return { grade: 'B2', points: 8 };
  if (score >= 65) return { grade: 'B3', points: 7 };
  if (score >= 60) return { grade: 'C4', points: 6 };
  if (score >= 55) return { grade: 'C5', points: 5 };
  if (score >= 50) return { grade: 'C6', points: 4 };
  if (score >= 45) return { grade: 'D7', points: 3 };
  if (score >= 40) return { grade: 'E8', points: 2 };
  return { grade: 'F9', points: 0 };
}

function calculateJAMBGrade(score: number): { grade: string; points: number } {
  if (score >= 75) return { grade: 'A', points: 5 };
  if (score >= 60) return { grade: 'B', points: 4 };
  if (score >= 45) return { grade: 'C', points: 3 };
  if (score >= 30) return { grade: 'D', points: 2 };
  return { grade: 'F', points: 1 };
}

function calculateIGCSEGrade(score: number): { grade: string; points: number } {
  if (score >= 90) return { grade: 'A*', points: 9 };
  if (score >= 80) return { grade: 'A', points: 8 };
  if (score >= 70) return { grade: 'B', points: 7 };
  if (score >= 60) return { grade: 'C', points: 6 };
  if (score >= 50) return { grade: 'D', points: 5 };
  if (score >= 40) return { grade: 'E', points: 4 };
  if (score >= 30) return { grade: 'F', points: 3 };
  return { grade: 'G', points: 2 };
}

function getGradeCalculator(providerId: string) {
  switch (providerId) {
    case 'cambridge':
    case 'ijmb':
    case 'jupeb':
      return calculateCambridgeGrade;
    case 'waec':
    case 'neco':
    case 'nabteb':
      return calculateWAECGrade;
    case 'jamb':
      return calculateJAMBGrade;
    case 'igcse':
      return calculateIGCSEGrade;
    default:
      return calculateCambridgeGrade;
  }
}

function getStatusThresholds(providerId: string, numSubjects: number = 4): { elite: number; strong: number } {
  switch (providerId) {
    case 'cambridge':
    case 'ijmb':
    case 'jupeb':
      return { elite: 15, strong: 10 };
    case 'waec':
    case 'neco':
    case 'nabteb':
      return { elite: 45, strong: 30 };
    case 'jamb':
      return { elite: Math.round(numSubjects * 75), strong: Math.round(numSubjects * 62.5) };
    case 'igcse':
      return { elite: 60, strong: 45 };
    default:
      return { elite: 15, strong: 10 };
  }
}

function getGradingInfo(providerId: string): string[] {
  switch (providerId) {
    case 'cambridge':
    case 'ijmb':
    case 'jupeb':
      return [
        'A: 80-100% (5 pts)',
        'B: 70-79% (4 pts)',
        'C: 60-69% (3 pts)',
        'D: 50-59% (2 pts)',
        'E: 40-49% (1 pt)',
        'F: 0-39% (0 pts)',
        '+1 Bonus if no F grades'
      ];
    case 'waec':
    case 'neco':
    case 'nabteb':
      return [
        'A1: 75-100% (9 pts)',
        'B2: 70-74% (8 pts)',
        'B3: 65-69% (7 pts)',
        'C4: 60-64% (6 pts)',
        'C5: 55-59% (5 pts)',
        'C6: 50-54% (4 pts)',
        'D7: 45-49% (3 pts)',
        'E8: 40-44% (2 pts)',
        'F9: 0-39% (0 pts)'
      ];
    case 'jamb':
      return [
        'Each subject: 0-100 marks',
        'Total: Sum of all subjects',
        'Standard: 4 subjects = 400 max',
        'Per Subject Grades:',
        'A: 75-100 (5 pts)',
        'B: 60-74 (4 pts)',
        'C: 45-59 (3 pts)',
        'D: 30-44 (2 pts)',
        'F: 0-29 (1 pt)'
      ];
    case 'igcse':
      return [
        'A*: 90-100% (9 pts)',
        'A: 80-89% (8 pts)',
        'B: 70-79% (7 pts)',
        'C: 60-69% (6 pts)',
        'D: 50-59% (5 pts)',
        'E: 40-49% (4 pts)',
        'F: 30-39% (3 pts)',
        'G: 0-29% (2 pts)'
      ];
    default:
      return [];
  }
}

export default function SuccessTracker() {
  const { user } = useAuth();
  const [examProvider, setExamProvider] = useState<string>('cambridge');
  const [showProviderDropdown, setShowProviderDropdown] = useState(false);
  const [providerSearch, setProviderSearch] = useState('');
  const [subjects, setSubjects] = useState<SubjectScore[]>([]);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [scores, setScores] = useState<{ [key: string]: string }>({});
  const [showHistory, setShowHistory] = useState(false);
  const [snapshots, setSnapshots] = useState<ProgressSnapshot[]>([]);
  const [loading, setLoading] = useState(false);
  const [studentName, setStudentName] = useState('');
  const [examNumber, setExamNumber] = useState('');
  const [examCentre, setExamCentre] = useState('');

  const currentProvider = EXAM_PROVIDERS.find((p) => p.id === examProvider) || EXAM_PROVIDERS[0];

  useEffect(() => {
    setSelectedSubjects(currentProvider.subjects.slice(0, 3));
    setSubjects([]);
    setScores({});
  }, [examProvider]);

  useEffect(() => {
    if (user) {
      loadSnapshots();
    }
  }, [user, examProvider]);

  const loadSnapshots = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('progress_snapshots')
      .select('*')
      .eq('user_id', user.id)
      .eq('exam_provider', examProvider)
      .order('created_at', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Error loading snapshots:', error);
      return;
    }

    if (data) {
      setSnapshots(data);
    }
  };

  const handleScoreChange = (subject: string, value: string) => {
    setScores({ ...scores, [subject]: value });
  };

  const calculateResults = () => {
    const gradeCalculator = getGradeCalculator(examProvider);
    const results: SubjectScore[] = selectedSubjects.map((subject) => {
      const score = parseFloat(scores[subject] || '0');
      const { grade, points } = gradeCalculator(score);
      return { name: subject, score, grade, points };
    });

    setSubjects(results);
  };

  const saveProgress = async () => {
    if (!user) {
      alert('Please sign in to save your progress');
      return;
    }

    if (subjects.length === 0) {
      alert('Please calculate results first');
      return;
    }

    setLoading(true);

    const totalPoints = subjects.reduce((sum, s) => sum + s.points, 0);
    const bonusPoints = (examProvider === 'cambridge' || examProvider === 'ijmb' || examProvider === 'jupeb') && subjects.every((s) => s.points > 0) ? 1 : 0;

    let finalScore: number;
    if (examProvider === 'jamb') {
      finalScore = Math.round(subjects.reduce((sum, s) => sum + s.score, 0));
    } else {
      finalScore = totalPoints + bonusPoints;
    }

    const thresholds = getStatusThresholds(examProvider, subjects.length);
    let status = 'ACTION REQUIRED';
    if (finalScore >= thresholds.elite) status = 'ELITE';
    else if (finalScore >= thresholds.strong) status = 'STRONG';

    const { error: snapshotError } = await supabase
      .from('progress_snapshots')
      .insert({
        user_id: user.id,
        exam_provider: examProvider,
        student_name: studentName || null,
        exam_number: examNumber || null,
        exam_centre: examCentre || null,
        total_points: totalPoints,
        bonus_points: bonusPoints,
        final_score: finalScore,
        status,
        subjects_data: subjects
      });

    if (snapshotError) {
      console.error('Error saving snapshot:', snapshotError);
      alert('Error saving progress');
    } else {
      alert('Progress saved successfully!');
      loadSnapshots();
    }

    setLoading(false);
  };

  const toggleSubject = (subject: string) => {
    if (selectedSubjects.includes(subject)) {
      setSelectedSubjects(selectedSubjects.filter((s) => s !== subject));
    } else {
      setSelectedSubjects([...selectedSubjects, subject]);
    }
  };

  const printResults = (snapshot?: ProgressSnapshot) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow pop-ups to print results');
      return;
    }

    const dataToUse = snapshot || {
      student_name: studentName || null,
      exam_number: examNumber || null,
      exam_centre: examCentre || null,
      exam_provider: examProvider,
      subjects_data: subjects,
      total_points: totalPoints,
      bonus_points: bonusPoints,
      final_score: finalScore,
      status: status,
      created_at: new Date().toISOString()
    };

    const providerName = EXAM_PROVIDERS.find(p => p.id === dataToUse.exam_provider)?.name || dataToUse.exam_provider;
    const calculatedMaxPossible = dataToUse.exam_provider === 'jamb'
      ? dataToUse.subjects_data.length * 100
      : dataToUse.subjects_data.length * ((dataToUse.exam_provider === 'cambridge' || dataToUse.exam_provider === 'ijmb' || dataToUse.exam_provider === 'jupeb') ? 5 : 9) + ((dataToUse.exam_provider === 'cambridge' || dataToUse.exam_provider === 'ijmb' || dataToUse.exam_provider === 'jupeb') ? 1 : 0);

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Exam Results - ${dataToUse.student_name || 'Student'}</title>
          <style>
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            body {
              font-family: Arial, sans-serif;
              padding: 40px;
              color: #1f2937;
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 3px solid #2563eb;
              padding-bottom: 20px;
            }
            .header h1 {
              font-size: 28px;
              color: #1e40af;
              margin-bottom: 5px;
            }
            .header p {
              font-size: 14px;
              color: #6b7280;
            }
            .student-info {
              background: #f3f4f6;
              padding: 15px;
              border-radius: 8px;
              margin-bottom: 25px;
              border-left: 4px solid #2563eb;
            }
            .student-info h3 {
              font-size: 14px;
              color: #374151;
              margin-bottom: 10px;
            }
            .info-grid {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 15px;
            }
            .info-item {
              font-size: 12px;
            }
            .info-label {
              font-weight: bold;
              color: #6b7280;
            }
            .info-value {
              color: #1f2937;
            }
            .results-section {
              margin-bottom: 25px;
            }
            .results-section h2 {
              font-size: 18px;
              color: #1f2937;
              margin-bottom: 15px;
              border-bottom: 2px solid #e5e7eb;
              padding-bottom: 8px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
            }
            th, td {
              padding: 12px;
              text-align: left;
              border-bottom: 1px solid #e5e7eb;
            }
            th {
              background-color: #f9fafb;
              font-weight: bold;
              color: #374151;
              font-size: 13px;
            }
            td {
              font-size: 13px;
            }
            .summary {
              background: #eff6ff;
              padding: 20px;
              border-radius: 8px;
              border: 2px solid #2563eb;
            }
            .summary-row {
              display: flex;
              justify-content: space-between;
              padding: 8px 0;
              font-size: 14px;
            }
            .summary-row.total {
              font-size: 18px;
              font-weight: bold;
              border-top: 2px solid #2563eb;
              padding-top: 12px;
              margin-top: 8px;
            }
            .status-badge {
              display: inline-block;
              padding: 10px 20px;
              border-radius: 6px;
              font-weight: bold;
              font-size: 16px;
              margin-top: 10px;
              text-align: center;
              width: 100%;
            }
            .status-elite {
              background-color: #d1fae5;
              color: #065f46;
            }
            .status-strong {
              background-color: #dbeafe;
              color: #1e40af;
            }
            .status-action {
              background-color: #fee2e2;
              color: #991b1b;
            }
            .footer {
              margin-top: 40px;
              text-align: center;
              font-size: 11px;
              color: #9ca3af;
              border-top: 1px solid #e5e7eb;
              padding-top: 20px;
            }
            @media print {
              body {
                padding: 20px;
              }
              .no-print {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>EXAM PERFORMANCE REPORT</h1>
            <p>${providerName}</p>
          </div>

          ${(dataToUse.student_name || dataToUse.exam_number || dataToUse.exam_centre) ? `
            <div class="student-info">
              <h3>Student Information</h3>
              <div class="info-grid">
                ${dataToUse.student_name ? `
                  <div class="info-item">
                    <div class="info-label">Name:</div>
                    <div class="info-value">${dataToUse.student_name}</div>
                  </div>
                ` : ''}
                ${dataToUse.exam_number ? `
                  <div class="info-item">
                    <div class="info-label">Exam Number:</div>
                    <div class="info-value">${dataToUse.exam_number}</div>
                  </div>
                ` : ''}
                ${dataToUse.exam_centre ? `
                  <div class="info-item">
                    <div class="info-label">Exam Centre:</div>
                    <div class="info-value">${dataToUse.exam_centre}</div>
                  </div>
                ` : ''}
              </div>
            </div>
          ` : ''}

          <div class="results-section">
            <h2>Subject Performance</h2>
            <table>
              <thead>
                <tr>
                  <th>Subject</th>
                  <th>Score</th>
                  <th>Grade</th>
                  <th>Points</th>
                </tr>
              </thead>
              <tbody>
                ${dataToUse.subjects_data.map((subject: SubjectScore) => `
                  <tr>
                    <td>${subject.name}</td>
                    <td>${dataToUse.exam_provider === 'jamb' ? `${subject.score}/100` : `${subject.score}%`}</td>
                    <td><strong>${subject.grade}</strong></td>
                    <td>${subject.points}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="summary">
            ${dataToUse.exam_provider !== 'jamb' ? `
              <div class="summary-row">
                <span>Base Points:</span>
                <span><strong>${dataToUse.total_points}</strong></span>
              </div>
              ${(dataToUse.exam_provider === 'cambridge' || dataToUse.exam_provider === 'ijmb' || dataToUse.exam_provider === 'jupeb') ? `
                <div class="summary-row">
                  <span>Bonus Points:</span>
                  <span><strong>${dataToUse.bonus_points}</strong></span>
                </div>
              ` : ''}
            ` : ''}
            <div class="summary-row total">
              <span>Total ${dataToUse.exam_provider === 'jamb' ? 'UTME' : 'Predicted'} Score:</span>
              <span>${dataToUse.final_score}/${calculatedMaxPossible}</span>
            </div>
            <div class="status-badge status-${dataToUse.status === 'ELITE' ? 'elite' : dataToUse.status === 'STRONG' ? 'strong' : 'action'}">
              Status: ${dataToUse.status}
            </div>
          </div>

          <div class="footer">
            <p>Generated on ${new Date(dataToUse.created_at).toLocaleDateString()} at ${new Date(dataToUse.created_at).toLocaleTimeString()}</p>
            <p>Gemavic Learning Academy Success Tracker - Multi-Provider Progress Monitor</p>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  const totalPoints = subjects.reduce((sum, s) => sum + s.points, 0);
  const bonusPoints = (examProvider === 'cambridge' || examProvider === 'ijmb' || examProvider === 'jupeb') && subjects.length > 0 && subjects.every((s) => s.points > 0) ? 1 : 0;

  let finalScore: number;
  let maxPossible: number;

  if (examProvider === 'jamb') {
    finalScore = Math.round(subjects.reduce((sum, s) => sum + s.score, 0));
    maxPossible = selectedSubjects.length * 100;
  } else {
    finalScore = totalPoints + bonusPoints;
    maxPossible = selectedSubjects.length * ((examProvider === 'cambridge' || examProvider === 'ijmb' || examProvider === 'jupeb') ? 5 : 9) + ((examProvider === 'cambridge' || examProvider === 'ijmb' || examProvider === 'jupeb') ? 1 : 0);
  }

  const thresholds = getStatusThresholds(examProvider, selectedSubjects.length);
  let status = 'ACTION REQUIRED';
  if (finalScore >= thresholds.elite) status = 'ELITE';
  else if (finalScore >= thresholds.strong) status = 'STRONG';

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Trophy className="w-8 h-8 text-yellow-500" />
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Success Tracker</h2>
            <p className="text-sm text-gray-600">Multi-Provider Progress Monitor</p>
          </div>
        </div>
        {user && (
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <History className="w-4 h-4" />
            History
          </button>
        )}
      </div>

      <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg border border-blue-200">
        <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-600" />
          Student Information
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold text-gray-600 mb-1 block">Student Name</label>
            <input
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              placeholder="Enter full name"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600 mb-1 block">Exam Number</label>
            <input
              type="text"
              value={examNumber}
              onChange={(e) => setExamNumber(e.target.value)}
              placeholder="Enter exam number"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600 mb-1 block">Exam Centre</label>
            <input
              type="text"
              value={examCentre}
              onChange={(e) => setExamCentre(e.target.value)}
              placeholder="Enter exam centre"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
        </div>
      </div>

      <div className="mb-6 relative">
        <label className="text-sm font-semibold text-gray-700 mb-2 block">Exam Provider</label>
        <button
          onClick={() => {
            setShowProviderDropdown(!showProviderDropdown);
            if (!showProviderDropdown) {
              setProviderSearch('');
            }
          }}
          className="w-full flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all shadow-md"
        >
          <div className="text-left">
            <div className="font-semibold">{currentProvider.name}</div>
            <div className="text-xs text-blue-100">{currentProvider.description}</div>
          </div>
          <ChevronDown className={`w-5 h-5 transition-transform ${showProviderDropdown ? 'rotate-180' : ''}`} />
        </button>

        {showProviderDropdown && (
          <div className="absolute z-10 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-xl overflow-hidden">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search exam provider..."
                  value={providerSearch}
                  onChange={(e) => setProviderSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            </div>
            <div className="max-h-64 overflow-y-auto">
              {EXAM_PROVIDERS.filter(provider =>
                provider.name.toLowerCase().includes(providerSearch.toLowerCase()) ||
                provider.description.toLowerCase().includes(providerSearch.toLowerCase())
              ).map((provider) => (
                <button
                  key={provider.id}
                  onClick={() => {
                    setExamProvider(provider.id);
                    setShowProviderDropdown(false);
                    setProviderSearch('');
                  }}
                  className={`w-full text-left px-4 py-3 hover:bg-blue-50 transition-colors border-b border-gray-100 last:border-b-0 ${
                    provider.id === examProvider ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="font-semibold text-gray-800">{provider.name}</div>
                  <div className="text-xs text-gray-600">{provider.description}</div>
                </button>
              ))}
              {EXAM_PROVIDERS.filter(provider =>
                provider.name.toLowerCase().includes(providerSearch.toLowerCase()) ||
                provider.description.toLowerCase().includes(providerSearch.toLowerCase())
              ).length === 0 && (
                <div className="px-4 py-6 text-center text-gray-500 text-sm">
                  No exam providers found
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {showHistory && user ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Progress History</h3>
            <button
              onClick={() => setShowHistory(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {snapshots.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No saved progress yet</p>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {snapshots.map((snapshot) => (
                <div key={snapshot.id} className="border rounded-lg p-4 bg-gray-50">
                  {(snapshot.student_name || snapshot.exam_number || snapshot.exam_centre) && (
                    <div className="mb-3 pb-3 border-b border-gray-300">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                        {snapshot.student_name && (
                          <div>
                            <span className="font-semibold text-gray-600">Name: </span>
                            <span className="text-gray-800">{snapshot.student_name}</span>
                          </div>
                        )}
                        {snapshot.exam_number && (
                          <div>
                            <span className="font-semibold text-gray-600">Exam No: </span>
                            <span className="text-gray-800">{snapshot.exam_number}</span>
                          </div>
                        )}
                        {snapshot.exam_centre && (
                          <div>
                            <span className="font-semibold text-gray-600">Centre: </span>
                            <span className="text-gray-800">{snapshot.exam_centre}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-semibold text-gray-800">
                        Score: {snapshot.final_score}/
                        {snapshot.exam_provider === 'jamb'
                          ? snapshot.subjects_data.length * 100
                          : snapshot.subjects_data.length * ((snapshot.exam_provider === 'cambridge' || snapshot.exam_provider === 'ijmb' || snapshot.exam_provider === 'jupeb') ? 5 : 9) + ((snapshot.exam_provider === 'cambridge' || snapshot.exam_provider === 'ijmb' || snapshot.exam_provider === 'jupeb') ? 1 : 0)
                        }
                      </p>
                      <p className={`text-sm font-medium ${
                        snapshot.status === 'ELITE' ? 'text-green-600' :
                        snapshot.status === 'STRONG' ? 'text-blue-600' : 'text-red-600'
                      }`}>
                        {snapshot.status}
                      </p>
                    </div>
                    <p className="text-xs text-gray-500">
                      {new Date(snapshot.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                    {snapshot.subjects_data.map((subject: SubjectScore) => (
                      <div key={subject.name} className="flex justify-between">
                        <span className="text-gray-600">{subject.name}:</span>
                        <span className="font-medium">
                          {subject.grade}
                        </span>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => printResults(snapshot)}
                    className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors flex items-center justify-center gap-2 text-sm"
                  >
                    <Printer className="w-4 h-4" />
                    Print This Report
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <>
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Select Subjects</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {currentProvider.subjects.map((subject) => (
                <button
                  key={subject}
                  onClick={() => toggleSubject(subject)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    selectedSubjects.includes(subject)
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {subject}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 mb-6">
            <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              {currentProvider.inputLabel}
            </h3>
            {selectedSubjects.map((subject) => (
              <div key={subject} className="flex items-center gap-3">
                <label className="w-40 text-sm font-medium text-gray-700 truncate" title={subject}>
                  {subject}
                </label>
                <input
                  type="number"
                  min={currentProvider.minScore}
                  max={currentProvider.maxScore}
                  value={scores[subject] || ''}
                  onChange={(e) => handleScoreChange(subject, e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter score"
                />
              </div>
            ))}
          </div>

          <button
            onClick={calculateResults}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <TrendingUp className="w-5 h-5" />
            Calculate Results
          </button>

          {subjects.length > 0 && (
            <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg border border-blue-200">
              <h3 className="text-lg font-bold text-gray-800 mb-4">Predicted Performance Report</h3>

              {(studentName || examNumber || examCentre) && (
                <div className="mb-4 pb-3 border-b border-blue-300">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                    {studentName && (
                      <div>
                        <span className="font-semibold text-gray-600">Name: </span>
                        <span className="text-gray-800">{studentName}</span>
                      </div>
                    )}
                    {examNumber && (
                      <div>
                        <span className="font-semibold text-gray-600">Exam No: </span>
                        <span className="text-gray-800">{examNumber}</span>
                      </div>
                    )}
                    {examCentre && (
                      <div>
                        <span className="font-semibold text-gray-600">Centre: </span>
                        <span className="text-gray-800">{examCentre}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="space-y-2 mb-4">
                {subjects.map((subject) => (
                  <div key={subject.name} className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700 truncate pr-2">{subject.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">
                        {examProvider === 'jamb' ? `${subject.score}/100` : `${subject.score}%`}
                      </span>
                      <span className="px-2 py-1 rounded font-bold text-sm bg-blue-100 text-blue-700 whitespace-nowrap">
                        {subject.grade}
                      </span>
                      <span className="text-sm font-semibold text-gray-800">
                        {subject.points} pts
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-gray-300 pt-3 space-y-2">
                {examProvider !== 'jamb' && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Base Points:</span>
                      <span className="font-semibold">{totalPoints}</span>
                    </div>
                    {examProvider === 'cambridge' && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Bonus Point:</span>
                        <span className="font-semibold">{bonusPoints}</span>
                      </div>
                    )}
                  </>
                )}
                <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-300">
                  <span>Total {examProvider === 'jamb' ? 'UTME' : 'Predicted'} Score:</span>
                  <span className="text-blue-600">{finalScore}/{maxPossible}</span>
                </div>
                <div className={`text-center py-3 px-4 rounded-lg font-bold text-lg ${
                  status === 'ELITE' ? 'bg-green-100 text-green-700' :
                  status === 'STRONG' ? 'bg-blue-100 text-blue-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  Status: {status}
                </div>
                {status === 'ELITE' && (
                  <p className="text-xs text-center text-gray-600">
                    Excellent Performance - Top Tier Admission Potential
                  </p>
                )}
                {status === 'STRONG' && (
                  <p className="text-xs text-center text-gray-600">
                    Strong Performance - Competitive for Quality Institutions
                  </p>
                )}
                {status === 'ACTION REQUIRED' && (
                  <p className="text-xs text-center text-gray-600">
                    Needs Improvement - Increase Study Intensity
                  </p>
                )}
              </div>

              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                <button
                  onClick={() => printResults()}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  Print Results
                </button>
                {user && (
                  <button
                    onClick={saveProgress}
                    disabled={loading}
                    className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-medium py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    {loading ? 'Saving...' : 'Save Progress'}
                  </button>
                )}
              </div>
            </div>
          )}

          <div className="mt-4 p-3 bg-gray-50 rounded-lg text-xs text-gray-600">
            <h4 className="font-semibold mb-2">Grading Scale for {currentProvider.name}:</h4>
            <div className="space-y-1">
              {getGradingInfo(examProvider).map((info, idx) => (
                <div key={idx}>{info}</div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
