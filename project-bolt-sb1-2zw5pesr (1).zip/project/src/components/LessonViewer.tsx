import { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, CheckCircle, Clock, BookOpen } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import rehypeSanitize from 'rehype-sanitize';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { MermaidDiagram } from './MermaidDiagram';

interface Lesson {
  id: string;
  title: string;
  description: string;
  content: string;
  duration_minutes: number;
  order_index: number;
}

interface LessonViewerProps {
  courseId: string;
  lessons: Lesson[];
  initialLessonIndex: number;
  onClose: () => void;
  onProgressUpdate?: () => void;
}

export function LessonViewer({
  courseId,
  lessons,
  initialLessonIndex,
  onClose,
  onProgressUpdate,
}: LessonViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(initialLessonIndex);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());
  const { user } = useAuth();

  const currentLesson = lessons[currentIndex];
  const isFirstLesson = currentIndex === 0;
  const isLastLesson = currentIndex === lessons.length - 1;

  useEffect(() => {
    if (user) {
      loadProgress();
    }
  }, [user, courseId]);

  const loadProgress = async () => {
    if (!user) return;

    try {
      const { data } = await supabase
        .from('lesson_progress')
        .select('lesson_id, completed')
        .eq('user_id', user.id)
        .eq('completed', true);

      if (data) {
        setCompletedLessons(new Set(data.map((p) => p.lesson_id)));
      }
    } catch (error) {
      console.error('Error loading progress:', error);
    }
  };

  const markAsComplete = async () => {
    if (!user || !currentLesson) return;

    try {
      const { error } = await supabase.from('lesson_progress').upsert(
        {
          user_id: user.id,
          lesson_id: currentLesson.id,
          completed: true,
          completed_at: new Date().toISOString(),
        },
        {
          onConflict: 'user_id,lesson_id',
        }
      );

      if (error) throw error;

      setCompletedLessons((prev) => new Set([...prev, currentLesson.id]));

      const totalCompleted = completedLessons.size + 1;
      const progressPercentage = Math.round((totalCompleted / lessons.length) * 100);

      await supabase
        .from('enrollments')
        .update({
          progress_percentage: progressPercentage,
          last_accessed: new Date().toISOString(),
        })
        .eq('user_id', user.id)
        .eq('course_id', courseId);

      if (onProgressUpdate) {
        onProgressUpdate();
      }
    } catch (error) {
      console.error('Error marking lesson as complete:', error);
    }
  };

  const goToPrevious = () => {
    if (!isFirstLesson) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const goToNext = () => {
    if (!isLastLesson) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const isLessonCompleted = completedLessons.has(currentLesson?.id);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex-1">
            <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
              <BookOpen size={16} />
              <span>
                Lesson {currentIndex + 1} of {lessons.length}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-gray-900">{currentLesson?.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-2"
          >
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="bg-blue-50 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <Clock size={20} />
              </div>
              <div>
                <p className="text-sm text-gray-600">Duration</p>
                <p className="font-semibold text-gray-900">
                  {currentLesson?.duration_minutes} minutes
                </p>
              </div>
            </div>
            {user && (
              <button
                onClick={markAsComplete}
                disabled={isLessonCompleted}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors ${
                  isLessonCompleted
                    ? 'bg-green-100 text-green-700'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                <CheckCircle size={20} />
                <span>{isLessonCompleted ? 'Completed' : 'Mark Complete'}</span>
              </button>
            )}
          </div>

          {isFirstLesson && (
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border-l-4 border-green-500">
              <h4 className="font-bold text-gray-900 mb-3 flex items-center space-x-2">
                <BookOpen size={20} className="text-green-600" />
                <span>Before You Begin</span>
              </h4>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-1">Learning Objectives:</p>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Understand the core concepts and frameworks presented</li>
                    <li>• Learn practical strategies you can implement immediately</li>
                    <li>• Analyze real-world examples and case studies</li>
                    <li>• Develop actionable skills for your business or career</li>
                  </ul>
                </div>
                <div className="pt-2 border-t border-green-200">
                  <p className="text-sm font-semibold text-gray-700 mb-1">How to Study This Lesson:</p>
                  <ol className="space-y-1 text-sm text-gray-600">
                    <li>1. Read through the entire lesson first to get an overview</li>
                    <li>2. Pay special attention to diagrams, tables, and highlighted examples</li>
                    <li>3. Take notes on key concepts and strategies that apply to you</li>
                    <li>4. Review the case studies to see concepts in action</li>
                    <li>5. Think about how you can apply these lessons to your situation</li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3">Description</h3>
            <p className="text-gray-700 leading-relaxed">{currentLesson?.description}</p>
          </div>

          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3">Lesson Content</h3>
            <div className="prose prose-blue max-w-none">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                rehypePlugins={[rehypeRaw, rehypeSanitize]}
                components={{
                  code({ node, inline, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || '');
                    const language = match ? match[1] : '';
                    const codeContent = String(children).replace(/\n$/, '');

                    if (!inline && language === 'mermaid') {
                      return <MermaidDiagram chart={codeContent} />;
                    }

                    return (
                      <code className={className} {...props}>
                        {children}
                      </code>
                    );
                  },
                  table({ children }) {
                    return (
                      <div className="overflow-x-auto my-6">
                        <table className="min-w-full divide-y divide-gray-300 border border-gray-300">
                          {children}
                        </table>
                      </div>
                    );
                  },
                  thead({ children }) {
                    return <thead className="bg-gray-50">{children}</thead>;
                  },
                  th({ children }) {
                    return (
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-r border-gray-300 last:border-r-0">
                        {children}
                      </th>
                    );
                  },
                  td({ children }) {
                    return (
                      <td className="px-4 py-3 text-sm text-gray-700 border-r border-gray-300 last:border-r-0">
                        {children}
                      </td>
                    );
                  },
                  tr({ children }) {
                    return <tr className="border-b border-gray-200 last:border-b-0">{children}</tr>;
                  },
                  h1({ children }) {
                    return <h1 className="text-3xl font-bold text-gray-900 mt-8 mb-4">{children}</h1>;
                  },
                  h2({ children }) {
                    return <h2 className="text-2xl font-bold text-gray-900 mt-6 mb-3">{children}</h2>;
                  },
                  h3({ children }) {
                    return <h3 className="text-xl font-bold text-gray-900 mt-5 mb-2">{children}</h3>;
                  },
                  h4({ children }) {
                    return <h4 className="text-lg font-semibold text-gray-900 mt-4 mb-2">{children}</h4>;
                  },
                  p({ children }) {
                    return <p className="text-gray-700 leading-relaxed mb-4">{children}</p>;
                  },
                  ul({ children }) {
                    return <ul className="list-disc list-inside space-y-2 mb-4 ml-4">{children}</ul>;
                  },
                  ol({ children }) {
                    return <ol className="list-decimal list-inside space-y-2 mb-4 ml-4">{children}</ol>;
                  },
                  li({ children }) {
                    return <li className="text-gray-700">{children}</li>;
                  },
                  blockquote({ children }) {
                    return (
                      <blockquote className="border-l-4 border-blue-500 pl-4 py-2 my-4 bg-blue-50 italic">
                        {children}
                      </blockquote>
                    );
                  },
                  strong({ children }) {
                    return <strong className="font-bold text-gray-900">{children}</strong>;
                  },
                  em({ children }) {
                    return <em className="italic">{children}</em>;
                  },
                  a({ children, href }) {
                    return (
                      <a
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 underline"
                      >
                        {children}
                      </a>
                    );
                  },
                  pre({ children, ...props }) {
                    const codeElement = children as any;
                    const className = codeElement?.props?.className || '';
                    const match = /language-(\w+)/.exec(className);
                    const language = match ? match[1] : '';

                    return (
                      <div className="relative my-4">
                        {language && (
                          <div className="absolute top-0 right-0 bg-gray-700 text-gray-300 text-xs font-semibold px-3 py-1 rounded-bl-lg rounded-tr-lg">
                            {language.toUpperCase()}
                          </div>
                        )}
                        <pre className="bg-gray-900 text-gray-100 rounded-lg p-4 overflow-x-auto" {...props}>
                          {children}
                        </pre>
                      </div>
                    );
                  },
                }}
              >
                {currentLesson?.content || ''}
              </ReactMarkdown>
            </div>
          </div>

          {isFirstLesson && (
            <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl p-6 border-l-4 border-orange-500">
              <h4 className="font-bold text-gray-900 mb-4 text-lg">Key Takeaways & Action Steps</h4>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-2">What You Should Remember:</p>
                  <ul className="space-y-2">
                    {[
                      'The core frameworks and concepts covered in this lesson',
                      'Real-world examples and how successful companies applied these strategies',
                      'Key metrics and data points that matter for implementation',
                      'Common mistakes to avoid based on case studies',
                    ].map((item, index) => (
                      <li key={index} className="flex items-start space-x-3 text-sm">
                        <CheckCircle className="text-orange-600 flex-shrink-0 mt-0.5" size={18} />
                        <span className="text-gray-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="pt-3 border-t border-orange-200">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Apply What You Learned:</p>
                  <ol className="space-y-2 text-sm text-gray-600">
                    <li>1. Review your notes and highlight the most relevant concepts for your situation</li>
                    <li>2. Identify one strategy from this lesson you can implement this week</li>
                    <li>3. Create an action plan with specific steps and deadlines</li>
                    <li>4. Share your key learnings with your team or peers for accountability</li>
                    <li>5. Return to this lesson as a reference when implementing these strategies</li>
                  </ol>
                </div>
                <div className="pt-3 border-t border-orange-200">
                  <p className="text-sm text-gray-600 italic">
                    💡 <strong>Pro Tip:</strong> The best learning happens through application. Don't just read and move on—take action on at least one insight from this lesson before proceeding to the next.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="border-t p-6 bg-gray-50">
          <div className="flex items-center justify-between">
            <button
              onClick={goToPrevious}
              disabled={isFirstLesson}
              className="flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-colors disabled:opacity-40 disabled:cursor-not-allowed text-gray-700 hover:bg-gray-200"
            >
              <ChevronLeft size={20} />
              <span>Previous</span>
            </button>

            <div className="text-center">
              <div className="text-sm text-gray-600 mb-1">Progress</div>
              <div className="flex items-center space-x-2">
                {lessons.map((lesson, index) => (
                  <button
                    key={lesson.id}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentIndex
                        ? 'bg-blue-600 w-8'
                        : completedLessons.has(lesson.id)
                        ? 'bg-green-500'
                        : 'bg-gray-300'
                    }`}
                    title={lesson.title}
                  />
                ))}
              </div>
            </div>

            <button
              onClick={goToNext}
              disabled={isLastLesson}
              className="flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-colors disabled:opacity-40 disabled:cursor-not-allowed bg-blue-600 text-white hover:bg-blue-700"
            >
              <span>Next</span>
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
