import { X, MapPin, Phone, Mail } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ContactModal({ isOpen, onClose }: ContactModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full">
        <div className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white p-6 flex items-center justify-between rounded-t-xl">
          <h2 className="text-2xl font-bold">Contact Admissions</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          <p className="text-gray-700 mb-6">
            Our admissions team is ready to help you with any questions about our programs,
            enrollment process, or course details.
          </p>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <MapPin className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Visit Us</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  1, Oluwagbemiga Street<br />
                  Beach Front Orufun<br />
                  Ibeju-Lekki, 105101<br />
                  Lagos State, Nigeria
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-green-50 rounded-lg">
                <Phone className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Call Us</h3>
                <div className="space-y-1">
                  <a
                    href="tel:+2348069841614"
                    className="block text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    +234 806 984 1614
                  </a>
                  <a
                    href="tel:+2348034180915"
                    className="block text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    +234 803 418 0915
                  </a>
                  <a
                    href="tel:+16138615799"
                    className="block text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    +1 613 861 5799
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Office Hours:</strong> Monday - Friday, 9:00 AM - 5:00 PM (WAT)
            </p>
          </div>

          <button
            onClick={onClose}
            className="mt-6 w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-600 transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}