import { X, AlertCircle, CheckCircle } from 'lucide-react';

interface FeeBreakdown {
  registration?: number;
  acceptance?: number;
  textbook?: number;
  tuition: number;
  examination?: number;
  hostel?: number;
  other_fees?: Array<{ name: string; amount: number; optional?: boolean }>;
}

interface EnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  sessionTitle: string;
  programName: string;
  totalPrice: number;
  currency: string;
  feeBreakdown?: FeeBreakdown;
  priceDisclaimer?: string;
  isEnrolling: boolean;
}

export default function EnrollmentModal({
  isOpen,
  onClose,
  onConfirm,
  sessionTitle,
  programName,
  totalPrice,
  currency,
  feeBreakdown,
  priceDisclaimer,
  isEnrolling
}: EnrollmentModalProps) {
  if (!isOpen) return null;

  const calculateTotal = () => {
    if (!feeBreakdown) return totalPrice;

    let total = 0;
    if (feeBreakdown.registration) total += feeBreakdown.registration;
    if (feeBreakdown.acceptance) total += feeBreakdown.acceptance;
    if (feeBreakdown.textbook) total += feeBreakdown.textbook;
    if (feeBreakdown.tuition) total += feeBreakdown.tuition;
    if (feeBreakdown.examination) total += feeBreakdown.examination;

    if (feeBreakdown.other_fees) {
      feeBreakdown.other_fees.forEach(fee => {
        if (!fee.optional) total += fee.amount;
      });
    }

    return total;
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-cyan-500 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-1">Enrollment Confirmation</h2>
            <p className="text-blue-100 text-sm">{programName}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{sessionTitle}</h3>
            <p className="text-gray-600 text-sm">
              Please review the complete fee structure before confirming your enrollment.
            </p>
          </div>

          {feeBreakdown ? (
            <div className="mb-6">
              <div className="border-2 border-gray-200 rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="text-left p-4 font-bold text-gray-700 text-lg border-b-2 border-gray-200">
                        {programName}
                      </th>
                      <th className="text-right p-4 font-bold text-gray-700 text-lg border-b-2 border-gray-200">
                        Fee
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {feeBreakdown.registration && (
                      <tr className="border-b border-gray-200">
                        <td className="p-4 text-gray-800">Registration</td>
                        <td className="p-4 text-right font-semibold text-gray-900">
                          {currency}{formatCurrency(feeBreakdown.registration)}
                        </td>
                      </tr>
                    )}

                    {feeBreakdown.acceptance && (
                      <tr className="border-b border-gray-200">
                        <td className="p-4 text-gray-800">Acceptance Fee</td>
                        <td className="p-4 text-right font-semibold text-gray-900">
                          {currency}{formatCurrency(feeBreakdown.acceptance)}
                        </td>
                      </tr>
                    )}

                    {feeBreakdown.textbook && (
                      <tr className="border-b border-gray-200">
                        <td className="p-4 text-gray-800">Study Materials</td>
                        <td className="p-4 text-right font-semibold text-gray-900">
                          {currency}{formatCurrency(feeBreakdown.textbook)}
                        </td>
                      </tr>
                    )}

                    <tr className="border-b border-gray-200 bg-blue-50">
                      <td className="p-4 text-gray-800 font-medium">Tuition</td>
                      <td className="p-4 text-right font-semibold text-gray-900">
                        {currency}{formatCurrency(feeBreakdown.tuition)}
                      </td>
                    </tr>

                    {feeBreakdown.examination && (
                      <tr className="border-b border-gray-200">
                        <td className="p-4 text-gray-800">Examination</td>
                        <td className="p-4 text-right font-semibold text-gray-900">
                          {currency}{formatCurrency(feeBreakdown.examination)}
                        </td>
                      </tr>
                    )}

                    {feeBreakdown.hostel && (
                      <tr className="border-b border-gray-200 bg-amber-50">
                        <td className="p-4 text-gray-800">
                          Hostel <span className="text-sm text-gray-600">(Optional)</span>
                        </td>
                        <td className="p-4 text-right font-semibold text-gray-900">
                          {currency}{formatCurrency(feeBreakdown.hostel)}
                        </td>
                      </tr>
                    )}

                    {feeBreakdown.other_fees?.map((fee, index) => (
                      <tr key={index} className={`border-b border-gray-200 ${fee.optional ? 'bg-amber-50' : ''}`}>
                        <td className="p-4 text-gray-800">
                          {fee.name} {fee.optional && <span className="text-sm text-gray-600">(Optional)</span>}
                        </td>
                        <td className="p-4 text-right font-semibold text-gray-900">
                          {currency}{formatCurrency(fee.amount)}
                        </td>
                      </tr>
                    ))}

                    <tr className="bg-gradient-to-r from-gray-100 to-gray-200 font-bold">
                      <td className="p-4 text-gray-900 text-lg">Total</td>
                      <td className="p-4 text-right text-blue-600 text-xl">
                        {currency}{formatCurrency(calculateTotal())}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {feeBreakdown.hostel && (
                <div className="mt-3 flex items-start gap-2 text-sm text-amber-700 bg-amber-50 p-3 rounded-lg">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <p>
                    Optional fees (such as hostel accommodation) are not included in the total above.
                    You can add these services during the registration process.
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="mb-6 p-6 bg-gray-50 rounded-lg">
              <div className="text-center">
                <p className="text-gray-700 font-medium text-lg mb-2">Total Fee</p>
                <p className="text-3xl font-bold text-blue-600">
                  {currency} {formatCurrency(totalPrice)}
                </p>
              </div>
            </div>
          )}

          {priceDisclaimer && (
            <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-900 mb-1">Important Notice</p>
                  <p className="text-sm text-blue-800">{priceDisclaimer}</p>
                </div>
              </div>
            </div>
          )}

          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-green-800">
                <p className="font-semibold mb-1">What happens after enrollment?</p>
                <ul className="list-disc list-inside space-y-1 text-green-700">
                  <li>You'll receive a confirmation email with payment details</li>
                  <li>Access to course materials and schedule information</li>
                  <li>Instructions for completing registration and payment</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
              disabled={isEnrolling}
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              disabled={isEnrolling}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-600 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isEnrolling ? 'Processing...' : 'Confirm Enrollment'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}