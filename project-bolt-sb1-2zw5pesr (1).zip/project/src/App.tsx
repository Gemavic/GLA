import { useState, useEffect } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { Header } from './components/Header';
import Footer from './components/Footer';
import { HomePage } from './pages/HomePage';
import { CoursesPage } from './pages/CoursesPage';
import { CourseDetailPage } from './pages/CourseDetailPage';
import { DashboardPage } from './pages/DashboardPage';
import StudentDashboardPage from './pages/StudentDashboardPage';
import TutorialsPage from './pages/TutorialsPage';
import TutorialProgramPage from './pages/TutorialProgramPage';
import TutorPage from './pages/TutorPage';
import TutorSessionPage from './pages/TutorSessionPage';
import AdminTutorsPage from './pages/AdminTutorsPage';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { AuthModal } from './components/AuthModal';
import { ForgotPasswordModal } from './components/ForgotPasswordModal';

type Page = 'home' | 'courses' | 'course' | 'dashboard' | 'student-dashboard' | 'tutorials' | 'tutorialProgram' | 'tutor' | 'tutorSession' | 'adminTutors' | 'reset-password';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedCourseSlug, setSelectedCourseSlug] = useState<string>('');
  const [selectedProgramId, setSelectedProgramId] = useState<string>('');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('page') === 'reset-password') {
      setCurrentPage('reset-password');
    }
  }, []);

  const handleNavigate = (page: string, courseSlug?: string, programId?: string) => {
    setCurrentPage(page as Page);
    if (courseSlug) {
      setSelectedCourseSlug(courseSlug);
    }
    if (programId) {
      setSelectedProgramId(programId);
    }
    window.scrollTo(0, 0);
  };

  const handleAuthRequired = () => {
    setShowAuthModal(true);
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        {currentPage !== 'reset-password' && (
          <Header
            onNavigate={handleNavigate}
            currentPage={currentPage}
            onShowAuthModal={(mode) => {
              setShowAuthModal(true);
            }}
            onShowForgotPassword={() => {
              setShowForgotPasswordModal(true);
            }}
          />
        )}

        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
        {currentPage === 'courses' && <CoursesPage onNavigate={handleNavigate} />}
        {currentPage === 'course' && (
          <CourseDetailPage
            courseSlug={selectedCourseSlug}
            onNavigate={handleNavigate}
            onAuthRequired={handleAuthRequired}
          />
        )}
        {currentPage === 'dashboard' && <DashboardPage onNavigate={handleNavigate} />}
        {currentPage === 'student-dashboard' && <StudentDashboardPage onNavigate={handleNavigate} />}
        {currentPage === 'tutorials' && <TutorialsPage onNavigate={handleNavigate} />}
        {currentPage === 'tutorialProgram' && (
          <TutorialProgramPage
            programId={selectedProgramId}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'tutor' && <TutorPage onNavigate={handleNavigate} />}
        {currentPage === 'tutorSession' && <TutorSessionPage />}
        {currentPage === 'adminTutors' && <AdminTutorsPage onNavigate={handleNavigate} />}
        {currentPage === 'reset-password' && <ResetPasswordPage onNavigate={handleNavigate} />}

        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onShowForgotPassword={() => {
            setShowAuthModal(false);
            setShowForgotPasswordModal(true);
          }}
          initialMode="signup"
        />

        <ForgotPasswordModal
          isOpen={showForgotPasswordModal}
          onClose={() => setShowForgotPasswordModal(false)}
          onBack={() => {
            setShowForgotPasswordModal(false);
            setShowAuthModal(true);
          }}
        />

        {currentPage !== 'reset-password' && <Footer />}
      </div>
    </AuthProvider>
  );
}

export default App;
