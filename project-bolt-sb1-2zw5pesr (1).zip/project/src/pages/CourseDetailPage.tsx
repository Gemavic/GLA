import { useEffect, useState } from 'react';
import { Star, Users, Clock, Award, CheckCircle, PlayCircle, BookOpen, ArrowLeft, ChevronDown, ChevronUp } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { LessonViewer } from '../components/LessonViewer';

interface Course {
  id: string;
  title: string;
  slug: string;
  description: string;
  full_description: string;
  instructor_name: string;
  instructor_title: string;
  image_url: string;
  level: string;
  duration_hours: number;
  price: number;
  rating: number;
  total_students: number;
}

interface Lesson {
  id: string;
  title: string;
  description: string;
  content: string;
  duration_minutes: number;
  order_index: number;
  module_id?: string;
  learning_objectives?: string[];
}

interface Module {
  id: string;
  title: string;
  description: string;
  order_index: number;
  duration_hours: number;
  lessons: Lesson[];
}

interface CourseDetailPageProps {
  courseSlug: string;
  onNavigate: (page: string) => void;
  onAuthRequired: () => void;
}

export function CourseDetailPage({ courseSlug, onNavigate, onAuthRequired }: CourseDetailPageProps) {
  const [course, setCourse] = useState<Course | null>(null);
  const [modules, setModules] = useState<Module[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set());
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [enrolling, setEnrolling] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showLessonViewer, setShowLessonViewer] = useState(false);
  const [selectedLessonIndex, setSelectedLessonIndex] = useState(0);
  const { user } = useAuth();

  useEffect(() => {
    loadCourseData();
  }, [courseSlug, user]);

  const loadCourseData = async () => {
    try {
      const { data: courseData } = await supabase
        .from('courses')
        .select('*')
        .eq('slug', courseSlug)
        .eq('published', true)
        .single();

      if (courseData) {
        setCourse(courseData);

        const { data: modulesData } = await supabase
          .from('course_modules')
          .select('*')
          .eq('course_id', courseData.id)
          .order('order_index');

        const { data: lessonsData } = await supabase
          .from('lessons')
          .select('id, title, description, content, duration_minutes, order_index, module_id, learning_objectives')
          .eq('course_id', courseData.id)
          .order('order_index');

        if (lessonsData) setLessons(lessonsData);

        if (modulesData && modulesData.length > 0) {
          const modulesWithLessons = modulesData.map(module => ({
            ...module,
            lessons: lessonsData?.filter(lesson => lesson.module_id === module.id) || []
          }));
          setModules(modulesWithLessons);

          if (modulesWithLessons.length > 0) {
            setExpandedModules(new Set([modulesWithLessons[0].id]));
          }
        }

        if (user) {
          const { data: enrollmentData } = await supabase
            .from('enrollments')
            .select('id')
            .eq('user_id', user.id)
            .eq('course_id', courseData.id)
            .maybeSingle();

          setIsEnrolled(!!enrollmentData);
        }
      }
    } catch (error) {
      console.error('Error loading course:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async () => {
    if (!user) {
      onAuthRequired();
      return;
    }

    if (!course) return;

    setEnrolling(true);
    try {
      const { error } = await supabase.from('enrollments').insert({
        user_id: user.id,
        course_id: course.id,
        progress_percentage: 0,
        completed: false,
      });

      if (error) throw error;

      setIsEnrolled(true);
      onNavigate('dashboard');
    } catch (error: any) {
      console.error('Error enrolling:', error);
      alert(error.message || 'Failed to enroll in course');
    } finally {
      setEnrolling(false);
    }
  };

  const toggleModule = (moduleId: string) => {
    setExpandedModules(prev => {
      const newSet = new Set(prev);
      if (newSet.has(moduleId)) {
        newSet.delete(moduleId);
      } else {
        newSet.add(moduleId);
      }
      return newSet;
    });
  };

  const handleLessonClick = (index: number) => {
    setSelectedLessonIndex(index);
    setShowLessonViewer(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading course...</p>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Course not found</h2>
          <button
            onClick={() => onNavigate('courses')}
            className="text-blue-600 hover:text-blue-700 font-semibold"
          >
            Back to Courses
          </button>
        </div>
      </div>
    );
  }

  const totalDuration = lessons.reduce((sum, lesson) => sum + lesson.duration_minutes, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <button
            onClick={() => onNavigate('courses')}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft size={20} />
            <span>Back to Courses</span>
          </button>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-6">
              <div>
                <div className="inline-block bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold mb-4">
                  {course.level}
                </div>
                <h1 className="text-4xl md:text-5xl font-bold mb-4">
                  {course.title}
                </h1>
                <p className="text-xl text-gray-300 mb-6">
                  {course.description}
                </p>
              </div>

              <div className="flex flex-wrap gap-6 text-sm">
                <div className="flex items-center space-x-2">
                  <Star className="text-yellow-400 fill-current" size={20} />
                  <span className="font-semibold">{course.rating}</span>
                  <span className="text-gray-400">rating</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users size={20} />
                  <span className="font-semibold">{course.total_students.toLocaleString()}</span>
                  <span className="text-gray-400">students</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock size={20} />
                  <span className="font-semibold">{course.duration_hours} hours</span>
                  <span className="text-gray-400">total</span>
                </div>
              </div>

              <div className="border-t border-gray-700 pt-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex items-center justify-center text-2xl font-bold">
                    {course.instructor_name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Instructor</p>
                    <p className="font-semibold text-lg">{course.instructor_name}</p>
                    <p className="text-gray-400 text-sm">{course.instructor_title}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:col-span-1">
              <div className="bg-white rounded-xl shadow-xl overflow-hidden sticky top-20">
                <img
                  src={course.image_url}
                  alt={course.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="text-4xl font-bold text-gray-900 mb-6">
                    ${course.price}
                  </div>

                  {isEnrolled ? (
                    <button
                      onClick={() => onNavigate('dashboard')}
                      className="w-full bg-green-600 text-white py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
                    >
                      <CheckCircle size={20} />
                      <span>Go to My Learning</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleEnroll}
                      disabled={enrolling}
                      className="w-full bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {enrolling ? 'Enrolling...' : 'Enroll Now'}
                    </button>
                  )}

                  <div className="mt-6 space-y-3 text-sm">
                    <div className="flex items-center space-x-3 text-gray-700">
                      <PlayCircle size={20} className="text-blue-600" />
                      <span>{lessons.length} lessons</span>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-700">
                      <Clock size={20} className="text-blue-600" />
                      <span>{Math.round(totalDuration / 60)} hours of content</span>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-700">
                      <Award size={20} className="text-blue-600" />
                      <span>Certificate of completion</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <div className="bg-white rounded-xl shadow-sm p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                About This Course
              </h2>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                {course.full_description}
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
                <BookOpen size={24} />
                <span>Course Curriculum</span>
              </h2>

              {modules.length > 0 ? (
                <div className="space-y-3">
                  {modules.map((module, moduleIndex) => {
                    const isExpanded = expandedModules.has(module.id);
                    const moduleLessonCount = module.lessons.length;
                    const moduleDuration = module.lessons.reduce((sum, l) => sum + l.duration_minutes, 0);

                    return (
                      <div key={module.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <button
                          onClick={() => toggleModule(module.id)}
                          className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
                        >
                          <div className="flex items-center space-x-4 flex-1">
                            <div className="w-10 h-10 bg-blue-600 text-white rounded-lg flex items-center justify-center font-bold text-sm">
                              {moduleIndex + 1}
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold text-gray-900 text-lg">
                                {module.title}
                              </h3>
                              <p className="text-sm text-gray-600 mt-1">
                                {module.description}
                              </p>
                              <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                <span>{moduleLessonCount} lessons</span>
                                <span>•</span>
                                <span>{Math.round(moduleDuration / 60)}h {moduleDuration % 60}m</span>
                              </div>
                            </div>
                          </div>
                          {isExpanded ? (
                            <ChevronUp className="text-gray-400 flex-shrink-0" size={20} />
                          ) : (
                            <ChevronDown className="text-gray-400 flex-shrink-0" size={20} />
                          )}
                        </button>

                        {isExpanded && module.lessons.length > 0 && (
                          <div className="bg-white border-t border-gray-200">
                            {module.lessons.map((lesson, lessonIndex) => {
                              const globalIndex = lessons.findIndex(l => l.id === lesson.id);
                              return (
                                <button
                                  key={lesson.id}
                                  onClick={() => handleLessonClick(globalIndex)}
                                  className="w-full flex items-center justify-between p-4 hover:bg-blue-50 border-b border-gray-100 last:border-b-0 transition-all group text-left"
                                >
                                  <div className="flex items-center space-x-4 flex-1">
                                    <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-semibold text-sm group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                      {lessonIndex + 1}
                                    </div>
                                    <div className="flex-1">
                                      <span className="font-medium text-gray-900 group-hover:text-blue-600 transition-colors">
                                        {lesson.title}
                                      </span>
                                      {lesson.description && (
                                        <p className="text-sm text-gray-500 mt-1 line-clamp-1">
                                          {lesson.description}
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center space-x-3">
                                    <span className="text-sm text-gray-600">
                                      {lesson.duration_minutes} min
                                    </span>
                                    <PlayCircle className="text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity" size={20} />
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-2">
                  {lessons.map((lesson, index) => (
                    <button
                      key={lesson.id}
                      onClick={() => handleLessonClick(index)}
                      className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-blue-50 hover:border-blue-200 border-2 border-transparent transition-all group text-left"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-semibold text-sm group-hover:bg-blue-600 group-hover:text-white transition-colors">
                          {index + 1}
                        </div>
                        <div>
                          <span className="font-medium text-gray-900 group-hover:text-blue-600 transition-colors">
                            {lesson.title}
                          </span>
                          <p className="text-sm text-gray-500 mt-1 line-clamp-1">
                            {lesson.description}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-sm text-gray-600">
                          {lesson.duration_minutes} min
                        </span>
                        <PlayCircle className="text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity" size={20} />
                      </div>
                    </button>
                  ))}
                  {lessons.length === 0 && (
                    <p className="text-gray-500 text-center py-8">
                      Curriculum coming soon
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="md:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 space-y-6">
              <h3 className="font-bold text-lg text-gray-900">
                What You'll Learn
              </h3>
              <ul className="space-y-3">
                {[
                  'Master the fundamentals and advanced concepts',
                  'Build real-world projects from scratch',
                  'Learn industry best practices',
                  'Get hands-on experience with tools',
                  'Prepare for career opportunities',
                  'Join a community of learners',
                ].map((item, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <CheckCircle className="text-green-500 flex-shrink-0 mt-0.5" size={20} />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {showLessonViewer && course && lessons.length > 0 && (
        <LessonViewer
          courseId={course.id}
          lessons={lessons}
          initialLessonIndex={selectedLessonIndex}
          onClose={() => setShowLessonViewer(false)}
          onProgressUpdate={loadCourseData}
        />
      )}
    </div>
  );
}
