import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import {
  PlayCircle,
  Plus,
  Clock,
  Users,
  BookOpen,
  Search,
  ChevronRight,
  Calendar,
  MapPin,
  Video,
  MessageSquare,
  Share2,
  GraduationCap,
  CheckCircle,
  XCircle,
  AlertCircle,
  X,
  Shield
} from 'lucide-react';

interface TutorSession {
  id: string;
  title: string;
  description: string;
  tutor_id: string;
  scheduled_start: string;
  scheduled_end: string;
  status: string;
  max_participants: number;
  current_participants: number;
  whiteboard_enabled: boolean;
  chat_enabled: boolean;
  screen_share_enabled: boolean;
  is_active: boolean;
}

interface TutorProfile {
  id: string;
  user_id: string;
  full_name: string;
  display_name: string;
  email: string;
  phone: string;
  bio: string;
  expertise: string[];
  qualifications: string;
  experience_years: number;
  monthly_rate: number;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  rejection_reason?: string;
  applied_at: string;
  reviewed_at?: string;
}

interface TutorPageProps {
  onNavigate: (page: string, courseSlug?: string, programId?: string) => void;
}

export default function TutorPage({ onNavigate }: TutorPageProps) {
  const { user } = useAuth();
  const [sessions, setSessions] = useState<TutorSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<TutorSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'upcoming' | 'live' | 'completed'>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [tutorProfile, setTutorProfile] = useState<TutorProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [applicationForm, setApplicationForm] = useState({
    full_name: '',
    display_name: '',
    email: '',
    phone: '',
    bio: '',
    expertise: '',
    qualifications: '',
    experience_years: 0,
    monthly_rate: 0
  });
  const [submitting, setSubmitting] = useState(false);
  const [sessionForm, setSessionForm] = useState({
    title: '',
    description: '',
    scheduled_start: '',
    scheduled_end: '',
    max_participants: 20,
    whiteboard_enabled: true,
    chat_enabled: true,
    screen_share_enabled: true
  });

  useEffect(() => {
    fetchSessions();
    if (user) {
      fetchTutorProfile();
      checkAdminStatus();
    }
    const interval = setInterval(fetchSessions, 30000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    filterSessions();
  }, [sessions, searchQuery, filterStatus]);

  const fetchSessions = async () => {
    try {
      const { data, error } = await supabase
        .from('tutor_sessions')
        .select('*')
        .eq('is_active', true)
        .order('scheduled_start', { ascending: true });

      if (error) {
        console.error('Error fetching sessions:', error);
      } else {
        setSessions(data || []);
      }
      setLoading(false);
    } catch (error) {
      console.error('Unexpected error fetching sessions:', error);
      setLoading(false);
    }
  };

  const fetchTutorProfile = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('tutor_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching tutor profile:', error);
      } else {
        setTutorProfile(data);
      }
    } catch (error) {
      console.error('Unexpected error fetching tutor profile:', error);
    }
  };

  const checkAdminStatus = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!error && data) {
        setIsAdmin(true);
      }
    } catch (error) {
      console.error('Error checking admin status:', error);
    }
  };

  const filterSessions = () => {
    let filtered = sessions;

    if (searchQuery) {
      filtered = filtered.filter(
        (s) =>
          s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (filterStatus !== 'all') {
      const now = new Date();
      filtered = filtered.filter((s) => {
        const start = new Date(s.scheduled_start);
        const end = new Date(s.scheduled_end);

        if (filterStatus === 'upcoming') return start > now;
        if (filterStatus === 'live') return start <= now && end > now;
        if (filterStatus === 'completed') return end <= now;
        return true;
      });
    }

    setFilteredSessions(filtered);
  };

  const joinSession = (sessionId: string) => {
    localStorage.setItem('currentTutorSession', sessionId);
    onNavigate('tutorSession');
  };

  const getSessionStatus = (session: TutorSession): string => {
    const now = new Date();
    const start = new Date(session.scheduled_start);
    const end = new Date(session.scheduled_end);

    if (start > now) return 'Upcoming';
    if (start <= now && end > now) return 'Live Now';
    return 'Completed';
  };

  const getStatusColor = (status: string) => {
    if (status === 'Live Now') return 'bg-red-100 text-red-700';
    if (status === 'Upcoming') return 'bg-blue-100 text-blue-700';
    return 'bg-gray-100 text-gray-700';
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const submitTutorApplication = async () => {
    if (!user) return;
    setSubmitting(true);

    try {
      const { error } = await supabase.from('tutor_profiles').insert({
        user_id: user.id,
        full_name: applicationForm.full_name,
        display_name: applicationForm.display_name,
        email: applicationForm.email,
        phone: applicationForm.phone,
        bio: applicationForm.bio,
        expertise: applicationForm.expertise.split(',').map((e) => e.trim()).filter(Boolean),
        qualifications: applicationForm.qualifications,
        experience_years: applicationForm.experience_years,
        monthly_rate: applicationForm.monthly_rate,
        status: 'pending'
      });

      if (error) {
        console.error('Error submitting application:', error);
        alert('Failed to submit application. Please try again.');
      } else {
        setShowApplyModal(false);
        fetchTutorProfile();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const createSession = async () => {
    if (!user || !tutorProfile || tutorProfile.status !== 'approved') return;
    setSubmitting(true);

    try {
      const { error } = await supabase.from('tutor_sessions').insert({
        title: sessionForm.title,
        description: sessionForm.description,
        tutor_id: user.id,
        tutor_profile_id: tutorProfile.id,
        scheduled_start: sessionForm.scheduled_start,
        scheduled_end: sessionForm.scheduled_end,
        max_participants: sessionForm.max_participants,
        current_participants: 0,
        whiteboard_enabled: sessionForm.whiteboard_enabled,
        chat_enabled: sessionForm.chat_enabled,
        screen_share_enabled: sessionForm.screen_share_enabled,
        status: 'scheduled',
        is_active: true
      });

      if (error) {
        console.error('Error creating session:', error);
        alert('Failed to create session. Please try again.');
      } else {
        setShowCreateModal(false);
        setSessionForm({
          title: '',
          description: '',
          scheduled_start: '',
          scheduled_end: '',
          max_participants: 20,
          whiteboard_enabled: true,
          chat_enabled: true,
          screen_share_enabled: true
        });
        fetchSessions();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const renderTutorStatus = () => {
    if (!user) return null;

    if (!tutorProfile) {
      return (
        <button
          onClick={() => setShowApplyModal(true)}
          className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all transform hover:scale-105"
        >
          <GraduationCap className="w-5 h-5" />
          Become a Tutor
        </button>
      );
    }

    if (tutorProfile.status === 'pending') {
      return (
        <div className="inline-flex items-center gap-2 px-6 py-3 bg-amber-100 text-amber-800 rounded-xl font-semibold">
          <AlertCircle className="w-5 h-5" />
          Application Under Review
        </div>
      );
    }

    if (tutorProfile.status === 'rejected') {
      return (
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-red-100 text-red-800 rounded-xl font-semibold">
            <XCircle className="w-5 h-5" />
            Application Rejected
          </div>
          {tutorProfile.rejection_reason && (
            <p className="text-sm text-red-600">Reason: {tutorProfile.rejection_reason}</p>
          )}
        </div>
      );
    }

    if (tutorProfile.status === 'approved') {
      return (
        <div className="flex items-center gap-3">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-800 rounded-lg font-semibold">
            <CheckCircle className="w-5 h-5" />
            Approved Tutor
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all transform hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            Create Session
          </button>
        </div>
      );
    }

    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading tutor sessions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Live Tutor Sessions
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Join interactive live sessions with expert tutors. Get real-time help, use our advanced whiteboard,
            and collaborate with fellow students.
          </p>

          <div className="flex flex-col items-center gap-4">
            {renderTutorStatus()}
            {isAdmin && (
              <button
                onClick={() => onNavigate('adminTutors')}
                className="inline-flex items-center gap-2 px-4 py-2 bg-slate-700 text-white rounded-lg font-medium hover:bg-slate-800 transition-all"
              >
                <Shield className="w-4 h-4" />
                Admin Panel
              </button>
            )}
          </div>
        </div>

        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search sessions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
              />
            </div>
            <div className="flex gap-2">
              {(['all', 'upcoming', 'live', 'completed'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-4 py-3 rounded-xl font-medium transition-all ${
                    filterStatus === status
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'bg-white text-gray-700 border border-gray-300 hover:border-blue-400'
                  }`}
                >
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filteredSessions.length === 0 ? (
          <div className="text-center py-16">
            <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">No sessions found</p>
            <p className="text-gray-500 mt-2">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="grid gap-6">
            {filteredSessions.map((session) => {
              const status = getSessionStatus(session);
              const isFull = session.current_participants >= session.max_participants;
              const spotsFull = isFull && status === 'Live Now';

              return (
                <div
                  key={session.id}
                  className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all border border-gray-200 overflow-hidden group"
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-2xl font-bold text-gray-900">{session.title}</h3>
                          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(status)}`}>
                            {status}
                          </span>
                        </div>
                        <p className="text-gray-600 max-w-2xl">{session.description}</p>
                      </div>

                      {status === 'Live Now' && (
                        <div className="flex items-center gap-2 px-3 py-2 bg-red-50 rounded-lg">
                          <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></div>
                          <span className="text-sm font-semibold text-red-700">LIVE</span>
                        </div>
                      )}
                    </div>

                    <div className="grid md:grid-cols-4 gap-4 mb-6 pb-6 border-b border-gray-200">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-blue-600" />
                        <div>
                          <p className="text-xs text-gray-600">Start Time</p>
                          <p className="font-semibold text-gray-900">{formatTime(session.scheduled_start)}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Clock className="w-5 h-5 text-blue-600" />
                        <div>
                          <p className="text-xs text-gray-600">Duration</p>
                          <p className="font-semibold text-gray-900">
                            {Math.round(
                              (new Date(session.scheduled_end).getTime() -
                                new Date(session.scheduled_start).getTime()) /
                                60000
                            )}{' '}
                            min
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Users className="w-5 h-5 text-blue-600" />
                        <div>
                          <p className="text-xs text-gray-600">Participants</p>
                          <p className={`font-semibold ${isFull ? 'text-red-600' : 'text-gray-900'}`}>
                            {session.current_participants}/{session.max_participants}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <MapPin className="w-5 h-5 text-blue-600" />
                        <div>
                          <p className="text-xs text-gray-600">Type</p>
                          <p className="font-semibold text-gray-900">Virtual</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex gap-3">
                        {session.whiteboard_enabled && (
                          <div className="flex items-center gap-1 px-3 py-2 bg-blue-50 rounded-lg">
                            <BookOpen className="w-4 h-4 text-blue-600" />
                            <span className="text-sm font-medium text-blue-700">Whiteboard</span>
                          </div>
                        )}
                        {session.chat_enabled && (
                          <div className="flex items-center gap-1 px-3 py-2 bg-green-50 rounded-lg">
                            <MessageSquare className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-medium text-green-700">Chat</span>
                          </div>
                        )}
                        {session.screen_share_enabled && (
                          <div className="flex items-center gap-1 px-3 py-2 bg-cyan-50 rounded-lg">
                            <Share2 className="w-4 h-4 text-cyan-600" />
                            <span className="text-sm font-medium text-cyan-700">Screen Share</span>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => joinSession(session.id)}
                        disabled={spotsFull}
                        className={`inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all transform hover:scale-105 ${
                          status === 'Live Now'
                            ? spotsFull
                              ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                              : 'bg-gradient-to-r from-red-500 to-pink-500 text-white hover:shadow-lg'
                            : status === 'Upcoming'
                              ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white hover:shadow-lg'
                              : 'bg-gray-300 text-gray-600 cursor-not-allowed'
                        }`}
                      >
                        {status === 'Live Now' && !spotsFull && (
                          <>
                            <PlayCircle className="w-5 h-5" />
                            Join Now
                          </>
                        )}
                        {status === 'Live Now' && spotsFull && <>Session Full</>}
                        {status === 'Upcoming' && (
                          <>
                            <Video className="w-5 h-5" />
                            Register
                          </>
                        )}
                        {status === 'Completed' && <>Completed</>}
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Interactive Whiteboard</h3>
            <p className="text-gray-600">
              Collaborate in real-time with drawing tools, shapes, and annotations
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Live Chat</h3>
            <p className="text-gray-600">
              Ask questions and communicate with tutors and classmates instantly
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-cyan-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Share2 className="w-8 h-8 text-cyan-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Screen Sharing</h3>
            <p className="text-gray-600">
              Share documents, code, and resources during live sessions
            </p>
          </div>
        </div>
      </div>

      {showApplyModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-2xl font-bold text-gray-900">Apply to Become a Tutor</h2>
              <button
                onClick={() => setShowApplyModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    value={applicationForm.full_name}
                    onChange={(e) => setApplicationForm({ ...applicationForm, full_name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your legal name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Display Name *</label>
                  <input
                    type="text"
                    value={applicationForm.display_name}
                    onChange={(e) => setApplicationForm({ ...applicationForm, display_name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your professional name"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    value={applicationForm.email}
                    onChange={(e) => setApplicationForm({ ...applicationForm, email: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    value={applicationForm.phone}
                    onChange={(e) => setApplicationForm({ ...applicationForm, phone: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="+234 xxx xxx xxxx"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                <textarea
                  value={applicationForm.bio}
                  onChange={(e) => setApplicationForm({ ...applicationForm, bio: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Tell us about yourself..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Areas of Expertise *</label>
                <input
                  type="text"
                  value={applicationForm.expertise}
                  onChange={(e) => setApplicationForm({ ...applicationForm, expertise: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Mathematics, Physics, Programming (comma separated)"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Qualifications</label>
                <textarea
                  value={applicationForm.qualifications}
                  onChange={(e) => setApplicationForm({ ...applicationForm, qualifications: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Your degrees, certifications, and relevant credentials..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Years of Experience</label>
                  <input
                    type="number"
                    min="0"
                    value={applicationForm.experience_years}
                    onChange={(e) => setApplicationForm({ ...applicationForm, experience_years: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Rate (NGN)</label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={applicationForm.monthly_rate}
                    onChange={(e) => setApplicationForm({ ...applicationForm, monthly_rate: parseFloat(e.target.value) || 0 })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., 50000"
                  />
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => setShowApplyModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={submitTutorApplication}
                disabled={submitting || !applicationForm.full_name || !applicationForm.display_name || !applicationForm.email || !applicationForm.phone || !applicationForm.expertise}
                className="flex-1 px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? 'Submitting...' : 'Submit Application'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showCreateModal && tutorProfile?.status === 'approved' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-2xl font-bold text-gray-900">Create New Session</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Session Title</label>
                <input
                  type="text"
                  value={sessionForm.title}
                  onChange={(e) => setSessionForm({ ...sessionForm, title: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Advanced Python Programming"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={sessionForm.description}
                  onChange={(e) => setSessionForm({ ...sessionForm, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="What will students learn in this session?"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
                  <input
                    type="datetime-local"
                    value={sessionForm.scheduled_start}
                    onChange={(e) => setSessionForm({ ...sessionForm, scheduled_start: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
                  <input
                    type="datetime-local"
                    value={sessionForm.scheduled_end}
                    onChange={(e) => setSessionForm({ ...sessionForm, scheduled_end: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Participants</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={sessionForm.max_participants}
                  onChange={(e) => setSessionForm({ ...sessionForm, max_participants: parseInt(e.target.value) || 20 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-700">Session Features</label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sessionForm.whiteboard_enabled}
                    onChange={(e) => setSessionForm({ ...sessionForm, whiteboard_enabled: e.target.checked })}
                    className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">Enable Whiteboard</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sessionForm.chat_enabled}
                    onChange={(e) => setSessionForm({ ...sessionForm, chat_enabled: e.target.checked })}
                    className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">Enable Chat</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sessionForm.screen_share_enabled}
                    onChange={(e) => setSessionForm({ ...sessionForm, screen_share_enabled: e.target.checked })}
                    className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">Enable Screen Sharing</span>
                </label>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={createSession}
                disabled={submitting || !sessionForm.title || !sessionForm.scheduled_start || !sessionForm.scheduled_end}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? 'Creating...' : 'Create Session'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
