import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  BookOpen, Calendar, MessageSquare, Award, Target, Clock,
  TrendingUp, CheckCircle, AlertCircle, Users, FileText,
  Video, BarChart3, Medal, Zap, BookMarked, Trophy
} from 'lucide-react';
import NotificationCenter from '../components/NotificationCenter';
import AnalyticsDashboard from '../components/AnalyticsDashboard';
import CertificatesView from '../components/CertificatesView';
import Leaderboard from '../components/Leaderboard';
import RecommendationsPanel from '../components/RecommendationsPanel';

interface DashboardStats {
  activeEnrollments: number;
  completedCourses: number;
  averageProgress: number;
  totalHoursLearned: number;
  upcomingAssignments: number;
  pendingQuizzes: number;
  unreadMessages: number;
  achievements: number;
}

interface EnrollmentData {
  id: string;
  course: {
    title: string;
    image_url: string;
    slug: string;
  };
  progress_percentage: number;
  last_accessed: string;
}

interface Assignment {
  id: string;
  title: string;
  due_date: string;
  course: { title: string };
  total_points: number;
}

interface Quiz {
  id: string;
  title: string;
  course: { title: string };
  duration_minutes: number;
  passing_score: number;
}

interface CalendarEvent {
  id: string;
  title: string;
  start_time: string;
  event_type: string;
  meeting_link?: string;
}

interface Achievement {
  id: string;
  title: string;
  badge_icon: string;
  badge_color: string;
  earned_at: string;
}

interface StudentDashboardPageProps {
  onNavigate: (page: string, courseSlug?: string) => void;
}

export default function StudentDashboardPage({ onNavigate }: StudentDashboardPageProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<DashboardStats>({
    activeEnrollments: 0,
    completedCourses: 0,
    averageProgress: 0,
    totalHoursLearned: 0,
    upcomingAssignments: 0,
    pendingQuizzes: 0,
    unreadMessages: 0,
    achievements: 0,
  });
  const [enrollments, setEnrollments] = useState<EnrollmentData[]>([]);
  const [upcomingAssignments, setUpcomingAssignments] = useState<Assignment[]>([]);
  const [upcomingQuizzes, setUpcomingQuizzes] = useState<Quiz[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Load enrollments
      const { data: enrollmentsData } = await supabase
        .from('enrollments')
        .select(`
          id,
          progress_percentage,
          last_accessed,
          completed,
          course:courses(title, image_url, slug)
        `)
        .eq('user_id', user?.id)
        .order('last_accessed', { ascending: false });

      if (enrollmentsData) {
        setEnrollments(enrollmentsData as any);

        const active = enrollmentsData.filter(e => !e.completed).length;
        const completed = enrollmentsData.filter(e => e.completed).length;
        const avgProgress = enrollmentsData.length > 0
          ? Math.round(enrollmentsData.reduce((sum, e) => sum + (e.progress_percentage || 0), 0) / enrollmentsData.length)
          : 0;

        setStats(prev => ({
          ...prev,
          activeEnrollments: active,
          completedCourses: completed,
          averageProgress: avgProgress,
          totalHoursLearned: Math.round(avgProgress * 2.5), // Estimate
        }));
      }

      // Load upcoming assignments
      const { data: assignmentsData } = await supabase
        .from('assignments')
        .select(`
          id,
          title,
          due_date,
          total_points,
          course:courses(title)
        `)
        .gte('due_date', new Date().toISOString())
        .order('due_date', { ascending: true })
        .limit(5);

      if (assignmentsData) {
        setUpcomingAssignments(assignmentsData as any);
        setStats(prev => ({ ...prev, upcomingAssignments: assignmentsData.length }));
      }

      // Load upcoming quizzes
      const { data: quizzesData } = await supabase
        .from('quizzes')
        .select(`
          id,
          title,
          duration_minutes,
          passing_score,
          available_until,
          course:courses(title)
        `)
        .eq('status', 'published')
        .limit(5);

      if (quizzesData) {
        setUpcomingQuizzes(quizzesData as any);
        setStats(prev => ({ ...prev, pendingQuizzes: quizzesData.length }));
      }

      // Load calendar events
      const now = new Date();
      const endOfWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

      const { data: eventsData } = await supabase
        .from('calendar_events')
        .select('*')
        .gte('start_time', now.toISOString())
        .lte('start_time', endOfWeek.toISOString())
        .order('start_time', { ascending: true })
        .limit(5);

      if (eventsData) {
        setCalendarEvents(eventsData);
      }

      // Load achievements
      const { data: achievementsData } = await supabase
        .from('achievements')
        .select('*')
        .eq('user_id', user?.id)
        .order('earned_at', { ascending: false })
        .limit(6);

      if (achievementsData) {
        setAchievements(achievementsData);
        setStats(prev => ({ ...prev, achievements: achievementsData.length }));
      }

      // Load unread messages count
      const { count: unreadCount } = await supabase
        .from('messages')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_id', user?.id)
        .eq('is_read', false);

      setStats(prev => ({ ...prev, unreadMessages: unreadCount || 0 }));

    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const getDaysUntil = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.ceil((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Welcome back, {user?.email?.split('@')[0]}!</h1>
              <p className="mt-2 text-blue-100">Ready to continue your learning journey?</p>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <NotificationCenter />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="max-w-7xl mx-auto px-4 -mt-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Courses</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.activeEnrollments}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg. Progress</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.averageProgress}%</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Assignments Due</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.upcomingAssignments}</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <FileText className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Achievements</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.achievements}</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Award className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              {[
                { id: 'overview', label: 'Overview', icon: BarChart3 },
                { id: 'courses', label: 'My Courses', icon: BookOpen },
                { id: 'assignments', label: 'Assignments', icon: FileText },
                { id: 'quizzes', label: 'Quizzes', icon: Target },
                { id: 'calendar', label: 'Calendar', icon: Calendar },
                { id: 'analytics', label: 'Analytics', icon: TrendingUp },
                { id: 'certificates', label: 'Certificates', icon: Award },
                { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
                { id: 'achievements', label: 'Achievements', icon: Medal },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-5 w-5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Recent Activity */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Continue Learning</h3>
                    <div className="space-y-4">
                      {enrollments.slice(0, 3).map((enrollment) => (
                        <div key={enrollment.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors cursor-pointer" onClick={() => onNavigate('course', enrollment.course.slug)}>
                          <div className="flex items-start space-x-4">
                            <img
                              src={enrollment.course.image_url || 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=200'}
                              alt={enrollment.course.title}
                              className="w-16 h-16 rounded-lg object-cover"
                            />
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900">{enrollment.course.title}</h4>
                              <p className="text-sm text-gray-500 mt-1">
                                Last accessed {new Date(enrollment.last_accessed).toLocaleDateString()}
                              </p>
                              <div className="mt-2">
                                <div className="flex items-center justify-between text-sm mb-1">
                                  <span className="text-gray-600">Progress</span>
                                  <span className="font-medium text-blue-600">{enrollment.progress_percentage}%</span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-2">
                                  <div
                                    className="bg-blue-600 h-2 rounded-full transition-all"
                                    style={{ width: `${enrollment.progress_percentage}%` }}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Upcoming Events */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming This Week</h3>
                    <div className="space-y-3">
                      {calendarEvents.map((event) => (
                        <div key={event.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                          <div className="flex-shrink-0">
                            <Calendar className="h-5 w-5 text-blue-600 mt-0.5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-gray-900">{event.title}</p>
                            <p className="text-sm text-gray-500 mt-0.5">
                              {formatDate(event.start_time)} at {formatTime(event.start_time)}
                            </p>
                            {event.event_type && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 mt-1">
                                {event.event_type}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                      {calendarEvents.length === 0 && (
                        <p className="text-center text-gray-500 py-8">No upcoming events this week</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {[
                      { icon: MessageSquare, label: 'Discussions', count: 5, color: 'blue' },
                      { icon: Users, label: 'Study Groups', count: 2, color: 'green' },
                      { icon: Video, label: 'Live Classes', count: 3, color: 'red' },
                      { icon: BookMarked, label: 'Resources', count: 12, color: 'purple' },
                    ].map((action) => (
                      <button
                        key={action.label}
                        className="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-300 hover:shadow-md transition-all text-center"
                      >
                        <action.icon className={`h-8 w-8 text-${action.color}-600 mx-auto mb-2`} />
                        <p className="font-medium text-gray-900">{action.label}</p>
                        <p className="text-sm text-gray-500 mt-1">{action.count} active</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* AI Recommendations */}
                <div>
                  <RecommendationsPanel />
                </div>
              </div>
            )}

            {/* My Courses Tab */}
            {activeTab === 'courses' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">My Enrolled Courses</h3>
                  <select className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option>All Courses</option>
                    <option>In Progress</option>
                    <option>Completed</option>
                  </select>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {enrollments.map((enrollment) => (
                    <div key={enrollment.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                      <img
                        src={enrollment.course.image_url || 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=400'}
                        alt={enrollment.course.title}
                        className="w-full h-40 object-cover"
                      />
                      <div className="p-4">
                        <h4 className="font-semibold text-gray-900 mb-2">{enrollment.course.title}</h4>
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="text-gray-600">Progress</span>
                          <span className="font-medium text-blue-600">{enrollment.progress_percentage}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${enrollment.progress_percentage}%` }}
                          />
                        </div>
                        <button
                          onClick={() => onNavigate('course', enrollment.course.slug)}
                          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          Continue Learning
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Assignments Tab */}
            {activeTab === 'assignments' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Upcoming Assignments</h3>
                <div className="space-y-4">
                  {upcomingAssignments.map((assignment) => {
                    const daysUntil = getDaysUntil(assignment.due_date);
                    const isUrgent = daysUntil <= 3;

                    return (
                      <div
                        key={assignment.id}
                        className={`border-l-4 ${isUrgent ? 'border-red-500 bg-red-50' : 'border-blue-500 bg-blue-50'} p-4 rounded-r-lg`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <FileText className={`h-5 w-5 ${isUrgent ? 'text-red-600' : 'text-blue-600'}`} />
                              <h4 className="font-semibold text-gray-900">{assignment.title}</h4>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">{assignment.course.title}</p>
                            <div className="flex items-center space-x-4 mt-2 text-sm">
                              <span className={`flex items-center ${isUrgent ? 'text-red-600' : 'text-gray-600'}`}>
                                <Clock className="h-4 w-4 mr-1" />
                                Due {formatDate(assignment.due_date)}
                                {isUrgent && ` (${daysUntil} days left!)`}
                              </span>
                              <span className="text-gray-600">
                                {assignment.total_points} points
                              </span>
                            </div>
                          </div>
                          <button className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                            isUrgent
                              ? 'bg-red-600 text-white hover:bg-red-700'
                              : 'bg-blue-600 text-white hover:bg-blue-700'
                          }`}>
                            Start
                          </button>
                        </div>
                      </div>
                    );
                  })}
                  {upcomingAssignments.length === 0 && (
                    <div className="text-center py-12">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <p className="text-gray-600">All caught up! No pending assignments.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Quizzes Tab */}
            {activeTab === 'quizzes' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Available Quizzes</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {upcomingQuizzes.map((quiz) => (
                    <div key={quiz.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                      <div className="flex items-start space-x-3">
                        <div className="bg-purple-100 p-2 rounded-lg">
                          <Target className="h-6 w-6 text-purple-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{quiz.title}</h4>
                          <p className="text-sm text-gray-600 mt-1">{quiz.course.title}</p>
                          <div className="flex items-center space-x-4 mt-3 text-sm text-gray-600">
                            <span className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              {quiz.duration_minutes} min
                            </span>
                            <span>Passing: {quiz.passing_score}%</span>
                          </div>
                          <button className="mt-4 w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors">
                            Take Quiz
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {upcomingQuizzes.length === 0 && (
                    <div className="col-span-2 text-center py-12">
                      <Target className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No quizzes available at the moment.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Calendar Tab */}
            {activeTab === 'calendar' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Upcoming Schedule</h3>
                <div className="space-y-3">
                  {calendarEvents.map((event) => (
                    <div key={event.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <div className="bg-blue-100 p-2 rounded-lg">
                            <Calendar className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900">{event.title}</h4>
                            <p className="text-sm text-gray-600 mt-1">
                              {formatDate(event.start_time)} at {formatTime(event.start_time)}
                            </p>
                            {event.event_type && (
                              <span className="inline-block mt-2 px-2 py-1 text-xs font-medium rounded bg-blue-100 text-blue-800">
                                {event.event_type}
                              </span>
                            )}
                          </div>
                        </div>
                        {event.meeting_link && (
                          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                            Join
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Analytics Tab */}
            {activeTab === 'analytics' && <AnalyticsDashboard />}

            {/* Certificates Tab */}
            {activeTab === 'certificates' && <CertificatesView />}

            {/* Leaderboard Tab */}
            {activeTab === 'leaderboard' && <Leaderboard />}

            {/* Achievements Tab */}
            {activeTab === 'achievements' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Your Achievements</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {achievements.map((achievement) => (
                    <div
                      key={achievement.id}
                      className="border-2 border-gray-200 rounded-lg p-6 text-center hover:border-yellow-400 hover:shadow-lg transition-all"
                      style={{ borderColor: achievement.badge_color }}
                    >
                      <div
                        className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center text-3xl"
                        style={{ backgroundColor: `${achievement.badge_color}20` }}
                      >
                        <Medal className="h-10 w-10" style={{ color: achievement.badge_color }} />
                      </div>
                      <h4 className="font-semibold text-gray-900">{achievement.title}</h4>
                      <p className="text-sm text-gray-600 mt-2">{achievement.description}</p>
                      <p className="text-xs text-gray-500 mt-3">
                        Earned on {formatDate(achievement.earned_at)}
                      </p>
                    </div>
                  ))}
                  {achievements.length === 0 && (
                    <div className="col-span-3 text-center py-12">
                      <Award className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">Keep learning to earn achievements!</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Spacing */}
      <div className="h-12"></div>
    </div>
  );
}
