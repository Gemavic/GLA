import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import QuoteRequestModal from '../components/QuoteRequestModal';
import ContactModal from '../components/ContactModal';
import {
  ArrowLeft,
  Calendar,
  Clock,
  Users,
  FileText,
  BookOpen,
  CheckCircle,
  AlertCircle,
  DollarSign,
  Zap,
  Layers
} from 'lucide-react';

interface TutorialProgram {
  id: string;
  name: string;
  full_name: string;
  description: string;
  target_audience: string;
  duration: string;
  level: string;
  region: string;
  color: string;
}

interface TutorialSession {
  id: string;
  title: string;
  description: string;
  subjects: string[];
  schedule: string;
  max_students: number;
  enrolled_students: number;
  start_date: string;
  end_date: string;
  is_active: boolean;
}

interface QuoteRequest {
  session_id: string;
  status: string;
}

interface TutorialProgramPageProps {
  programId: string;
  onNavigate: (page: string, courseSlug?: string, programId?: string) => void;
}

const colorMap: Record<string, { gradient: string; badgeGradient: string; textColor: string }> = {
  blue: {
    gradient: 'bg-gradient-to-r from-blue-500 to-cyan-500',
    badgeGradient: 'bg-gradient-to-r from-blue-100 to-cyan-100',
    textColor: 'text-blue-700'
  },
  purple: {
    gradient: 'bg-gradient-to-r from-violet-500 to-fuchsia-500',
    badgeGradient: 'bg-gradient-to-r from-violet-100 to-fuchsia-100',
    textColor: 'text-violet-700'
  },
  green: {
    gradient: 'bg-gradient-to-r from-emerald-500 to-teal-500',
    badgeGradient: 'bg-gradient-to-r from-emerald-100 to-teal-100',
    textColor: 'text-emerald-700'
  },
  orange: {
    gradient: 'bg-gradient-to-r from-orange-500 to-amber-500',
    badgeGradient: 'bg-gradient-to-r from-orange-100 to-amber-100',
    textColor: 'text-orange-700'
  },
  red: {
    gradient: 'bg-gradient-to-r from-rose-500 to-pink-500',
    badgeGradient: 'bg-gradient-to-r from-rose-100 to-pink-100',
    textColor: 'text-rose-700'
  },
  teal: {
    gradient: 'bg-gradient-to-r from-teal-500 to-cyan-500',
    badgeGradient: 'bg-gradient-to-r from-teal-100 to-cyan-100',
    textColor: 'text-teal-700'
  },
  indigo: {
    gradient: 'bg-gradient-to-r from-indigo-500 to-blue-500',
    badgeGradient: 'bg-gradient-to-r from-indigo-100 to-blue-100',
    textColor: 'text-indigo-700'
  },
  yellow: {
    gradient: 'bg-gradient-to-r from-yellow-500 to-amber-500',
    badgeGradient: 'bg-gradient-to-r from-yellow-100 to-amber-100',
    textColor: 'text-yellow-700'
  },
};

export default function TutorialProgramPage({ programId, onNavigate }: TutorialProgramPageProps) {
  const { user } = useAuth();
  const [program, setProgram] = useState<TutorialProgram | null>(null);
  const [sessions, setSessions] = useState<TutorialSession[]>([]);
  const [quoteRequests, setQuoteRequests] = useState<QuoteRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [selectedSession, setSelectedSession] = useState<TutorialSession | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);

  useEffect(() => {
    if (programId) {
      fetchProgramData();
    }
  }, [programId]);

  const fetchProgramData = async () => {
    try {
      const [programResult, sessionsResult] = await Promise.all([
        supabase
          .from('hybrid_solution_tracks')
          .select('*')
          .eq('id', programId)
          .single(),
        supabase
          .from('tutorial_sessions')
          .select('*')
          .eq('program_id', programId)
          .eq('is_active', true)
          .order('start_date')
      ]);

      if (programResult.error) throw programResult.error;
      if (sessionsResult.error) throw sessionsResult.error;

      setProgram(programResult.data);
      setSessions(sessionsResult.data || []);

      if (user) {
        const { data: quoteData } = await supabase
          .from('quote_requests')
          .select('session_id, status')
          .eq('user_id', user.id);

        setQuoteRequests(quoteData || []);
      }
    } catch (error) {
      console.error('Error fetching program data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRequestQuote = (sessionId: string) => {
    if (!user) {
      alert('Please sign in to request a quote');
      return;
    }

    const session = sessions.find(s => s.id === sessionId);
    if (session) {
      setSelectedSession(session);
      setShowQuoteModal(true);
    }
  };

  const hasRequestedQuote = (sessionId: string) => {
    return quoteRequests.some(q => q.session_id === sessionId);
  };

  const getQuoteRequestStatus = (sessionId: string) => {
    const quoteRequest = quoteRequests.find(q => q.session_id === sessionId);
    return quoteRequest?.status;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading program details...</p>
        </div>
      </div>
    );
  }

  if (!program) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Program Not Found</h2>
          <button
            onClick={() => onNavigate('tutorials')}
            className="text-blue-600 hover:underline"
          >
            Back to Programs
          </button>
        </div>
      </div>
    );
  }

  const colors = colorMap[program.color] || colorMap.blue;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => onNavigate('tutorials')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Programs
        </button>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div className={`${colors.gradient} p-8 text-white`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold mb-2">
                  {program.name}
                </h1>
                <p className="text-xl text-white/90">{program.full_name}</p>
              </div>
              <span className="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-semibold">
                {program.region}
              </span>
            </div>
          </div>

          <div className="p-8">
            <p className="text-gray-700 text-lg leading-relaxed mb-6">
              {program.description}
            </p>

            <div className="grid md:grid-cols-3 gap-6 p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
              <div>
                <p className="text-sm text-gray-600 mb-1">Target Audience</p>
                <p className="font-semibold text-gray-900">{program.target_audience}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Duration</p>
                <p className="font-semibold text-gray-900">{program.duration}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Level</p>
                <p className="font-semibold text-gray-900 capitalize">{program.level}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Guided Hybrid Track Structure</h2>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl shadow-lg p-8 border border-blue-200">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-blue-100 rounded-lg p-3">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Prep Classes</h3>
                  <p className="text-sm text-gray-600">Structured Curriculum</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                Live and recorded lectures covering the complete curriculum. Access structured lessons at your own pace with comprehensive study materials.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 text-sm">Live sessions + recorded content</span>
                </li>
                <li className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 text-sm">Study materials & resources</span>
                </li>
                <li className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 text-sm">Flexible schedule options</span>
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl shadow-lg p-8 border border-emerald-200">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-emerald-100 rounded-lg p-3">
                  <Users className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Tutorial Programs</h3>
                  <p className="text-sm text-gray-600">The Human Layer</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                1:1 coaching, project troubleshooting, and portfolio reviews. Get personalized guidance and accountability for measurable skill gains.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 text-sm">1:1 coaching sessions</span>
                </li>
                <li className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 text-sm">Portfolio & project reviews</span>
                </li>
                <li className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 text-sm">Skill gap analysis & feedback</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-600 rounded-lg p-6 mb-8">
            <div className="flex gap-3">
              <Layers className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-gray-900 mb-1">Choose Your Learning Mode</p>
                <p className="text-gray-700">Select Prep Classes for structured learning, Tutorial Programs for personalized coaching, or combine both with our HyFlex approach to fit your schedule.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Available Sessions</h2>

          {sessions.length === 0 ? (
            <div className="bg-white rounded-xl shadow-lg p-12 text-center">
              <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">
                No active sessions available at the moment.
              </p>
              <p className="text-gray-500 text-sm mt-2">
                Please check back later for upcoming sessions.
              </p>
            </div>
          ) : (
            <div className="grid gap-6">
              {sessions.map((session) => {
                const hasQuote = hasRequestedQuote(session.id);
                const quoteStatus = getQuoteRequestStatus(session.id);
                const spotsLeft = session.max_students - session.enrolled_students;
                const isFullyBooked = spotsLeft <= 0;

                return (
                  <div
                    key={session.id}
                    className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all"
                  >
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-2xl font-bold text-gray-900 mb-2">
                            {session.title}
                          </h3>
                          <p className="text-gray-700 leading-relaxed">
                            {session.description}
                          </p>
                        </div>
                        {hasQuote && (
                          <div className="ml-4">
                            <span className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold ${
                              quoteStatus === 'responded' ? 'bg-green-100 text-green-800' :
                              quoteStatus === 'pending' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              <CheckCircle className="w-4 h-4" />
                              {quoteStatus === 'responded' ? 'Quote Received' :
                               quoteStatus === 'pending' ? 'Quote Requested' :
                               quoteStatus}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2 font-semibold">Subjects Covered:</p>
                        <div className="flex flex-wrap gap-2">
                          {session.subjects.map((subject, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium"
                            >
                              {subject}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="grid md:grid-cols-3 gap-4 mb-6">
                        <div className="flex items-center gap-3 text-gray-700">
                          <Calendar className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-xs text-gray-500">Start Date</p>
                            <p className="font-semibold">
                              {new Date(session.start_date).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-gray-700">
                          <Clock className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-xs text-gray-500">Schedule</p>
                            <p className="font-semibold text-sm">{session.schedule.split(',')[0]}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-gray-700">
                          <Users className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-xs text-gray-500">Spots Available</p>
                            <p className={`font-semibold ${spotsLeft <= 5 ? 'text-red-600' : ''}`}>
                              {spotsLeft} / {session.max_students}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 p-4 rounded-lg mb-4">
                        <div className="flex items-start gap-3">
                          <DollarSign className="w-5 h-5 text-blue-600 mt-0.5" />
                          <div>
                            <p className="font-semibold text-gray-900 mb-1">Pricing Information</p>
                            <p className="text-sm text-gray-700">
                              Tuition fees vary based on program duration and subjects. Request a personalized quote to get detailed pricing information tailored to your needs.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg mb-4">
                        <p className="text-sm text-gray-600">
                          <span className="font-semibold">Full Schedule:</span> {session.schedule}
                        </p>
                      </div>

                      {hasQuote && quoteStatus === 'pending' ? (
                        <button
                          disabled
                          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-100 text-blue-700 rounded-lg font-semibold cursor-not-allowed"
                        >
                          <CheckCircle className="w-5 h-5" />
                          Quote Request Submitted
                        </button>
                      ) : hasQuote && quoteStatus === 'responded' ? (
                        <div className="space-y-3">
                          <div className="flex items-center justify-center gap-2 px-6 py-3 bg-green-100 text-green-700 rounded-lg font-semibold">
                            <CheckCircle className="w-5 h-5" />
                            Quote Received - Check Your Email
                          </div>
                          <button
                            onClick={() => setShowContactModal(true)}
                            className="w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white rounded-lg font-semibold transition-all transform hover:scale-105 shadow-md"
                          >
                            Contact Admissions
                          </button>
                        </div>
                      ) : isFullyBooked ? (
                        <button
                          disabled
                          className="w-full px-6 py-3 bg-gray-200 text-gray-500 rounded-lg font-semibold cursor-not-allowed"
                        >
                          Fully Booked
                        </button>
                      ) : (
                        <button
                          onClick={() => handleRequestQuote(session.id)}
                          className={`w-full flex items-center justify-center gap-2 px-6 py-3 ${colors.gradient} hover:opacity-90 text-white rounded-lg font-semibold transition-all transform hover:scale-105 shadow-md`}
                        >
                          <FileText className="w-5 h-5" />
                          Request Quote
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className={`${colors.badgeGradient} border-2 border-gray-200 rounded-xl p-6`}>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Need More Information?</h3>
          <p className="text-gray-700 mb-4">
            Contact our admissions team for personalized guidance on choosing the right program
            and session for your educational goals.
          </p>
          <button
            onClick={() => setShowContactModal(true)}
            className={`px-6 py-2 ${colors.gradient} text-white rounded-lg font-semibold transition-all transform hover:scale-105 shadow-md`}
          >
            Contact Admissions
          </button>
        </div>
      </div>

      {selectedSession && (
        <QuoteRequestModal
          isOpen={showQuoteModal}
          onClose={() => {
            setShowQuoteModal(false);
            setSelectedSession(null);
            fetchProgramData();
          }}
          sessionId={selectedSession.id}
          sessionTitle={selectedSession.title}
          programName={program.name}
        />
      )}

      <ContactModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
      />
    </div>
  );
}
