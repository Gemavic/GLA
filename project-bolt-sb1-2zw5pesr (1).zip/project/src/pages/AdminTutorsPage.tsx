import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import {
  Shield,
  CheckCircle,
  XCircle,
  Clock,
  User,
  Briefcase,
  Calendar,
  ChevronLeft,
  AlertTriangle,
  Search,
  Trash2,
  Users,
  History,
  Crown,
  UserPlus,
  UserMinus,
  Mail,
  Phone,
  Banknote
} from 'lucide-react';

interface TutorProfile {
  id: string;
  user_id: string;
  full_name: string;
  display_name: string;
  email: string;
  phone: string;
  bio: string;
  expertise: string[];
  qualifications: string;
  experience_years: number;
  monthly_rate: number;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  rejection_reason?: string;
  applied_at: string;
  reviewed_at?: string;
  is_active: boolean;
  deleted_at?: string;
}

interface AdminUser {
  id: string;
  user_id: string;
  role: 'admin' | 'super_admin';
  created_at: string;
  email?: string;
}

interface AuditLog {
  id: string;
  admin_id: string;
  action: string;
  target_type: string;
  target_id?: string;
  details: Record<string, unknown>;
  created_at: string;
  admin_email?: string;
}

interface AdminTutorsPageProps {
  onNavigate: (page: string) => void;
}

type TabType = 'tutors' | 'admins' | 'audit';

export default function AdminTutorsPage({ onNavigate }: AdminTutorsPageProps) {
  const { user } = useAuth();
  const [profiles, setProfiles] = useState<TutorProfile[]>([]);
  const [filteredProfiles, setFilteredProfiles] = useState<TutorProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedProfile, setSelectedProfile] = useState<TutorProfile | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [processing, setProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('tutors');
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'admin' | 'super_admin'>('admin');
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<TutorProfile | null>(null);

  useEffect(() => {
    if (user) {
      checkAdminAndFetch();
    }
  }, [user]);

  useEffect(() => {
    filterProfiles();
  }, [profiles, searchQuery, filterStatus]);

  const checkAdminAndFetch = async () => {
    if (!user) return;

    try {
      const { data: adminData, error: adminError } = await supabase
        .from('admin_users')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (adminError || !adminData) {
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      setIsAdmin(true);
      setIsSuperAdmin(adminData.role === 'super_admin');
      fetchProfiles();

      if (adminData.role === 'super_admin') {
        fetchAdminUsers();
        fetchAuditLogs();
      }
    } catch (error) {
      console.error('Error checking admin status:', error);
      setLoading(false);
    }
  };

  const fetchProfiles = async () => {
    try {
      const { data, error } = await supabase
        .from('tutor_profiles')
        .select('*')
        .is('deleted_at', null)
        .order('applied_at', { ascending: false });

      if (error) {
        console.error('Error fetching profiles:', error);
      } else {
        setProfiles(data || []);
      }
      setLoading(false);
    } catch (error) {
      console.error('Unexpected error:', error);
      setLoading(false);
    }
  };

  const fetchAdminUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_users')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching admin users:', error);
        return;
      }

      const adminIds = data?.map(a => a.user_id) || [];
      if (adminIds.length > 0) {
        const { data: authData } = await supabase.auth.admin.listUsers();
        const emailMap = new Map<string, string>();
        authData?.users?.forEach(u => emailMap.set(u.id, u.email || 'Unknown'));

        const enrichedAdmins = data?.map(admin => ({
          ...admin,
          email: emailMap.get(admin.user_id) || 'Unknown'
        })) || [];

        setAdminUsers(enrichedAdmins);
      } else {
        setAdminUsers(data || []);
      }
    } catch (error) {
      console.error('Error fetching admin users:', error);
      setAdminUsers([]);
    }
  };

  const fetchAuditLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) {
        console.error('Error fetching audit logs:', error);
        return;
      }

      setAuditLogs(data || []);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
    }
  };

  const filterProfiles = () => {
    let filtered = profiles;

    if (searchQuery) {
      filtered = filtered.filter(
        (p) =>
          (p.display_name || p.full_name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.expertise.some((e) => e.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (filterStatus !== 'all') {
      filtered = filtered.filter((p) => p.status === filterStatus);
    }

    setFilteredProfiles(filtered);
  };

  const logAction = async (action: string, targetType: string, targetId?: string, details?: Record<string, unknown>) => {
    try {
      await supabase.rpc('log_admin_action', {
        p_action: action,
        p_target_type: targetType,
        p_target_id: targetId || null,
        p_details: details || {}
      });
    } catch (error) {
      console.error('Error logging action:', error);
    }
  };

  const approveProfile = async (profile: TutorProfile) => {
    if (!user) return;
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('tutor_profiles')
        .update({
          status: 'approved',
          reviewed_at: new Date().toISOString(),
          reviewed_by: user.id,
          rejection_reason: null
        })
        .eq('id', profile.id);

      if (error) {
        console.error('Error approving profile:', error);
        alert('Failed to approve profile.');
      } else {
        await logAction('APPROVE_TUTOR', 'tutor', profile.id, { tutor_name: profile.display_name || profile.full_name });
        setSelectedProfile(null);
        fetchProfiles();
        if (isSuperAdmin) fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const rejectProfile = async (profile: TutorProfile) => {
    if (!user || !rejectionReason.trim()) {
      alert('Please provide a rejection reason.');
      return;
    }
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('tutor_profiles')
        .update({
          status: 'rejected',
          reviewed_at: new Date().toISOString(),
          reviewed_by: user.id,
          rejection_reason: rejectionReason
        })
        .eq('id', profile.id);

      if (error) {
        console.error('Error rejecting profile:', error);
        alert('Failed to reject profile.');
      } else {
        await logAction('REJECT_TUTOR', 'tutor', profile.id, {
          tutor_name: profile.display_name || profile.full_name,
          reason: rejectionReason
        });
        setSelectedProfile(null);
        setRejectionReason('');
        fetchProfiles();
        if (isSuperAdmin) fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const suspendProfile = async (profile: TutorProfile) => {
    if (!user) return;
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('tutor_profiles')
        .update({
          status: 'suspended',
          is_active: false
        })
        .eq('id', profile.id);

      if (error) {
        console.error('Error suspending profile:', error);
        alert('Failed to suspend profile.');
      } else {
        await logAction('SUSPEND_TUTOR', 'tutor', profile.id, { tutor_name: profile.display_name || profile.full_name });
        setSelectedProfile(null);
        fetchProfiles();
        if (isSuperAdmin) fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const deleteTutorProfile = async (profile: TutorProfile) => {
    if (!user || !isSuperAdmin) return;
    setProcessing(true);

    try {
      const { data, error } = await supabase.rpc('delete_tutor_profile', {
        p_tutor_id: profile.id
      });

      if (error) {
        console.error('Error deleting profile:', error);
        alert('Failed to delete profile.');
      } else if (data && !data.success) {
        alert(data.error || 'Failed to delete profile.');
      } else {
        setShowDeleteConfirm(null);
        setSelectedProfile(null);
        fetchProfiles();
        fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const updateAdminRole = async (adminUser: AdminUser, newRole: 'admin' | 'super_admin') => {
    if (!user || !isSuperAdmin || adminUser.user_id === user.id) return;
    setProcessing(true);

    try {
      const { data, error } = await supabase.rpc('manage_admin_user', {
        p_target_user_id: adminUser.user_id,
        p_new_role: newRole
      });

      if (error) {
        console.error('Error updating admin role:', error);
        alert('Failed to update admin role.');
      } else if (data && !data.success) {
        alert(data.error || 'Failed to update admin role.');
      } else {
        fetchAdminUsers();
        fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const removeAdmin = async (adminUser: AdminUser) => {
    if (!user || !isSuperAdmin || adminUser.user_id === user.id) return;

    if (!confirm(`Are you sure you want to remove ${adminUser.email || 'this user'} as an admin?`)) {
      return;
    }

    setProcessing(true);

    try {
      const { data, error } = await supabase.rpc('manage_admin_user', {
        p_target_user_id: adminUser.user_id,
        p_remove: true
      });

      if (error) {
        console.error('Error removing admin:', error);
        alert('Failed to remove admin.');
      } else if (data && !data.success) {
        alert(data.error || 'Failed to remove admin.');
      } else {
        fetchAdminUsers();
        fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const addNewAdmin = async () => {
    if (!user || !isSuperAdmin || !newAdminEmail.trim()) return;
    setProcessing(true);

    try {
      const { data: userData } = await supabase
        .from('auth.users')
        .select('id')
        .eq('email', newAdminEmail.trim())
        .maybeSingle();

      if (!userData) {
        alert('User with this email not found. The user must have an account first.');
        setProcessing(false);
        return;
      }

      const { data, error } = await supabase.rpc('add_admin_user', {
        p_user_id: userData.id,
        p_role: newAdminRole
      });

      if (error) {
        console.error('Error adding admin:', error);
        alert('Failed to add admin.');
      } else if (data && !data.success) {
        alert(data.error || 'Failed to add admin.');
      } else {
        setNewAdminEmail('');
        setNewAdminRole('admin');
        setShowAddAdminModal(false);
        fetchAdminUsers();
        fetchAuditLogs();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium bg-amber-100 text-amber-800">
            <Clock className="w-4 h-4" />
            Pending
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-4 h-4" />
            Approved
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
            <XCircle className="w-4 h-4" />
            Rejected
          </span>
        );
      case 'suspended':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
            <AlertTriangle className="w-4 h-4" />
            Suspended
          </span>
        );
      default:
        return null;
    }
  };

  const getActionLabel = (action: string) => {
    const labels: Record<string, string> = {
      'APPROVE_TUTOR': 'Approved tutor',
      'REJECT_TUTOR': 'Rejected tutor',
      'SUSPEND_TUTOR': 'Suspended tutor',
      'DELETE_TUTOR': 'Deleted tutor',
      'ADD_ADMIN': 'Added admin',
      'REMOVE_ADMIN': 'Removed admin',
      'UPDATE_ADMIN_ROLE': 'Updated admin role'
    };
    return labels[action] || action;
  };

  const getActionIcon = (action: string) => {
    if (action.includes('APPROVE')) return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (action.includes('REJECT')) return <XCircle className="w-4 h-4 text-red-600" />;
    if (action.includes('SUSPEND')) return <AlertTriangle className="w-4 h-4 text-amber-600" />;
    if (action.includes('DELETE')) return <Trash2 className="w-4 h-4 text-red-600" />;
    if (action.includes('ADD')) return <UserPlus className="w-4 h-4 text-blue-600" />;
    if (action.includes('REMOVE')) return <UserMinus className="w-4 h-4 text-red-600" />;
    if (action.includes('UPDATE')) return <Users className="w-4 h-4 text-blue-600" />;
    return <History className="w-4 h-4 text-gray-600" />;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center bg-white rounded-xl shadow-lg p-8 max-w-md">
          <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
          <p className="text-gray-600 mb-6">You do not have permission to access this page.</p>
          <button
            onClick={() => onNavigate('tutor')}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('tutor')}
            className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
          >
            <ChevronLeft className="w-5 h-5" />
            Back to Tutor Sessions
          </button>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isSuperAdmin ? 'bg-amber-500' : 'bg-slate-700'}`}>
                {isSuperAdmin ? <Crown className="w-6 h-6 text-white" /> : <Shield className="w-6 h-6 text-white" />}
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  {isSuperAdmin ? 'Super Admin Panel' : 'Admin Panel'}
                </h1>
                <p className="text-gray-600">
                  {isSuperAdmin ? 'Full administrative control' : 'Review and manage tutor applications'}
                </p>
              </div>
            </div>
            {isSuperAdmin && (
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-amber-100 text-amber-800 rounded-full text-sm font-semibold">
                <Crown className="w-4 h-4" />
                GLAadmin01
              </span>
            )}
          </div>
        </div>

        {isSuperAdmin && (
          <div className="mb-8">
            <div className="flex gap-2 bg-white p-1 rounded-xl shadow-sm inline-flex">
              <button
                onClick={() => setActiveTab('tutors')}
                className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
                  activeTab === 'tutors' ? 'bg-slate-700 text-white' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <User className="w-5 h-5" />
                Tutor Applications
              </button>
              <button
                onClick={() => setActiveTab('admins')}
                className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
                  activeTab === 'admins' ? 'bg-slate-700 text-white' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Users className="w-5 h-5" />
                Manage Admins
              </button>
              <button
                onClick={() => setActiveTab('audit')}
                className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
                  activeTab === 'audit' ? 'bg-slate-700 text-white' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <History className="w-5 h-5" />
                Audit Logs
              </button>
            </div>
          </div>
        )}

        {activeTab === 'tutors' && (
          <>
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Applications</p>
                    <p className="text-3xl font-bold text-gray-900">{profiles.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Pending Review</p>
                    <p className="text-3xl font-bold text-amber-600">
                      {profiles.filter((p) => p.status === 'pending').length}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-amber-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Approved Tutors</p>
                    <p className="text-3xl font-bold text-green-600">
                      {profiles.filter((p) => p.status === 'approved').length}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Rejected</p>
                    <p className="text-3xl font-bold text-red-600">
                      {profiles.filter((p) => p.status === 'rejected').length}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <XCircle className="w-6 h-6 text-red-600" />
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-6 flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by name or expertise..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex gap-2">
                {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => setFilterStatus(status)}
                    className={`px-4 py-3 rounded-xl font-medium transition-all ${
                      filterStatus === status
                        ? 'bg-slate-700 text-white'
                        : 'bg-white text-gray-700 border border-gray-300 hover:border-slate-400'
                    }`}
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              {filteredProfiles.length === 0 ? (
                <div className="text-center py-16">
                  <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 text-lg">No applications found</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {filteredProfiles.map((profile) => (
                    <div
                      key={profile.id}
                      className="p-6 hover:bg-gray-50 cursor-pointer transition-all"
                      onClick={() => setSelectedProfile(profile)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-xl font-bold text-blue-600">
                              {(profile.display_name || profile.full_name || 'T').charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-gray-900">{profile.display_name || profile.full_name}</h3>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {profile.expertise.slice(0, 3).map((exp, i) => (
                                <span
                                  key={i}
                                  className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-xs font-medium"
                                >
                                  {exp}
                                </span>
                              ))}
                              {profile.expertise.length > 3 && (
                                <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                                  +{profile.expertise.length - 3} more
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                              <span className="flex items-center gap-1">
                                <Briefcase className="w-4 h-4" />
                                {profile.experience_years} years
                              </span>
                              <span className="flex items-center gap-1">
                                <Banknote className="w-4 h-4" />
                                ₦{profile.monthly_rate?.toLocaleString('en-NG') || '0'}/mo
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                Applied {new Date(profile.applied_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {getStatusBadge(profile.status)}
                          {isSuperAdmin && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowDeleteConfirm(profile);
                              }}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                              title="Delete tutor profile"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'admins' && isSuperAdmin && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Admin Users</h2>
              <button
                onClick={() => setShowAddAdminModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all"
              >
                <UserPlus className="w-5 h-5" />
                Add Admin
              </button>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="divide-y divide-gray-200">
                {adminUsers.map((admin) => (
                  <div key={admin.id} className="p-6 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        admin.role === 'super_admin' ? 'bg-amber-100' : 'bg-blue-100'
                      }`}>
                        {admin.role === 'super_admin' ? (
                          <Crown className="w-6 h-6 text-amber-600" />
                        ) : (
                          <Shield className="w-6 h-6 text-blue-600" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{admin.email || 'Unknown User'}</p>
                        <p className="text-sm text-gray-500">
                          Added {new Date(admin.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        admin.role === 'super_admin'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                      </span>
                      {admin.user_id !== user?.id && (
                        <div className="flex items-center gap-2">
                          <select
                            value={admin.role}
                            onChange={(e) => updateAdminRole(admin, e.target.value as 'admin' | 'super_admin')}
                            disabled={processing}
                            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="admin">Admin</option>
                            <option value="super_admin">Super Admin</option>
                          </select>
                          <button
                            onClick={() => removeAdmin(admin)}
                            disabled={processing}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                            title="Remove admin"
                          >
                            <UserMinus className="w-5 h-5" />
                          </button>
                        </div>
                      )}
                      {admin.user_id === user?.id && (
                        <span className="text-sm text-gray-500 italic">You</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'audit' && isSuperAdmin && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">Audit Logs</h2>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              {auditLogs.length === 0 ? (
                <div className="text-center py-16">
                  <History className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 text-lg">No audit logs yet</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="p-4 hover:bg-gray-50">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                          {getActionIcon(log.action)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-900">{getActionLabel(log.action)}</span>
                            <span className="text-gray-500">-</span>
                            <span className="text-sm text-gray-600">{log.target_type}</span>
                          </div>
                          {log.details && Object.keys(log.details).length > 0 && (
                            <div className="mt-1 text-sm text-gray-500">
                              {Object.entries(log.details).map(([key, value]) => (
                                <span key={key} className="mr-3">
                                  {key}: {String(value)}
                                </span>
                              ))}
                            </div>
                          )}
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(log.created_at).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {selectedProfile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-2xl font-bold text-gray-900">Application Details</h2>
              <button
                onClick={() => {
                  setSelectedProfile(null);
                  setRejectionReason('');
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl font-bold text-blue-600">
                    {(selectedProfile.display_name || selectedProfile.full_name || 'T').charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{selectedProfile.display_name || selectedProfile.full_name}</h3>
                  <div className="mt-1">{getStatusBadge(selectedProfile.status)}</div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-gray-500" />
                  <div>
                    <label className="text-xs font-medium text-gray-500">Email</label>
                    <p className="text-gray-900 font-medium">{selectedProfile.email || 'Not provided'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-gray-500" />
                  <div>
                    <label className="text-xs font-medium text-gray-500">Phone</label>
                    <p className="text-gray-900 font-medium">{selectedProfile.phone || 'Not provided'}</p>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium text-gray-500">Full Name</label>
                  <p className="text-gray-900 font-medium">{selectedProfile.full_name || 'Not provided'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Experience</label>
                  <p className="text-gray-900 font-medium">{selectedProfile.experience_years} years</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Monthly Rate (NGN)</label>
                  <p className="text-gray-900 font-medium">₦{selectedProfile.monthly_rate?.toLocaleString('en-NG') || '0'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Applied</label>
                  <p className="text-gray-900 font-medium">
                    {new Date(selectedProfile.applied_at).toLocaleDateString()}
                  </p>
                </div>
                {selectedProfile.reviewed_at && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Reviewed</label>
                    <p className="text-gray-900 font-medium">
                      {new Date(selectedProfile.reviewed_at).toLocaleDateString()}
                    </p>
                  </div>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500">Areas of Expertise</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectedProfile.expertise.map((exp, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                    >
                      {exp}
                    </span>
                  ))}
                </div>
              </div>

              {selectedProfile.bio && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Bio</label>
                  <p className="text-gray-700 mt-1">{selectedProfile.bio}</p>
                </div>
              )}

              {selectedProfile.qualifications && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Qualifications</label>
                  <p className="text-gray-700 mt-1">{selectedProfile.qualifications}</p>
                </div>
              )}

              {selectedProfile.rejection_reason && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-red-800">Rejection Reason</label>
                  <p className="text-red-700 mt-1">{selectedProfile.rejection_reason}</p>
                </div>
              )}

              {selectedProfile.status === 'pending' && (
                <div className="border-t border-gray-200 pt-6 space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Rejection Reason (if rejecting)</label>
                    <textarea
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      rows={2}
                      className="w-full mt-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Provide a reason if you're rejecting this application..."
                    />
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => approveProfile(selectedProfile)}
                      disabled={processing}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-all disabled:opacity-50"
                    >
                      <CheckCircle className="w-5 h-5" />
                      {processing ? 'Processing...' : 'Approve'}
                    </button>
                    <button
                      onClick={() => rejectProfile(selectedProfile)}
                      disabled={processing || !rejectionReason.trim()}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-all disabled:opacity-50"
                    >
                      <XCircle className="w-5 h-5" />
                      {processing ? 'Processing...' : 'Reject'}
                    </button>
                  </div>
                </div>
              )}

              {selectedProfile.status === 'approved' && (
                <div className="border-t border-gray-200 pt-6 flex gap-3">
                  <button
                    onClick={() => suspendProfile(selectedProfile)}
                    disabled={processing}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg font-medium hover:bg-gray-700 transition-all disabled:opacity-50"
                  >
                    <AlertTriangle className="w-5 h-5" />
                    {processing ? 'Processing...' : 'Suspend Tutor'}
                  </button>
                  {isSuperAdmin && (
                    <button
                      onClick={() => setShowDeleteConfirm(selectedProfile)}
                      disabled={processing}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-all disabled:opacity-50"
                    >
                      <Trash2 className="w-5 h-5" />
                      Delete Permanently
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Delete Tutor Profile</h3>
              <p className="text-gray-600 mb-6">
                Are you sure you want to permanently delete <strong>{showDeleteConfirm.display_name || showDeleteConfirm.full_name}</strong>'s profile? This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(null)}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={() => deleteTutorProfile(showDeleteConfirm)}
                  disabled={processing}
                  className="flex-1 px-4 py-3 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-all disabled:opacity-50"
                >
                  {processing ? 'Deleting...' : 'Delete'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showAddAdminModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Add New Admin</h3>
              <button
                onClick={() => {
                  setShowAddAdminModal(false);
                  setNewAdminEmail('');
                  setNewAdminRole('admin');
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">User Email</label>
                <input
                  type="email"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  placeholder="Enter user's email address"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">User must have an existing account</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                <select
                  value={newAdminRole}
                  onChange={(e) => setNewAdminRole(e.target.value as 'admin' | 'super_admin')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="admin">Admin</option>
                  <option value="super_admin">Super Admin</option>
                </select>
              </div>

              <button
                onClick={addNewAdmin}
                disabled={processing || !newAdminEmail.trim()}
                className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all disabled:opacity-50"
              >
                {processing ? 'Adding...' : 'Add Admin'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
