import { useEffect, useState } from 'react';
import { ArrowRight, Star, Users, Clock, TrendingUp, Award, Sparkles, BookOpen, GraduationCap } from 'lucide-react';
import { supabase } from '../lib/supabase';
import SuccessTracker from '../components/SuccessTracker';

interface Course {
  id: string;
  title: string;
  slug: string;
  description: string;
  instructor_name: string;
  image_url: string;
  level: string;
  duration_hours: number;
  price: number;
  rating: number;
  total_students: number;
}

interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
}

interface HomePageProps {
  onNavigate: (page: string, courseSlug?: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const [featuredCourses, setFeaturedCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [coursesRes, categoriesRes] = await Promise.all([
        supabase
          .from('courses')
          .select('*')
          .eq('published', true)
          .order('total_students', { ascending: false })
          .limit(6),
        supabase.from('categories').select('*').order('name'),
      ]);

      if (coursesRes.data) setFeaturedCourses(coursesRes.data);
      if (categoriesRes.data) setCategories(categoriesRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const stats = [
    { icon: Users, label: 'Active Students', value: '5,000+' },
    { icon: Award, label: 'Expert Instructors', value: '50+' },
    { icon: TrendingUp, label: 'Course Completion', value: '95%' },
    { icon: Sparkles, label: 'Success Stories', value: '2,200+' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-cyan-500 to-teal-500 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white opacity-10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-cyan-300 opacity-10 rounded-full blur-3xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Transform Your Future with
              <span className="block mt-2 bg-gradient-to-r from-yellow-200 to-orange-200 bg-clip-text text-transparent">
                Expert-Led Learning
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-50 leading-relaxed">
              Join thousands of learners mastering new skills with our world-class courses.
              From beginners to professionals, we have something for everyone.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('courses')}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-blue-50 transition-all transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
              >
                <span>Explore Courses</span>
                <ArrowRight size={20} />
              </button>
              <button
                onClick={() => onNavigate('courses')}
                className="bg-blue-700 bg-opacity-50 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-opacity-70 transition-all border-2 border-white border-opacity-30"
              >
                Start Free Trial
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl shadow-xl p-8 text-white">
              <div className="flex items-center gap-3 mb-6">
                <GraduationCap className="w-10 h-10" />
                <div>
                  <h2 className="text-3xl font-bold">Professional Hybrid Solution</h2>
                  <p className="text-blue-100">Guided Hybrid Tracks — Cambridge A-Level & NABTEB Excellence</p>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
                  <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                    <BookOpen className="w-5 h-5" />
                    Prep Classes — Structured Curriculum
                  </h3>
                  <p className="text-blue-100 text-sm">
                    Live and recorded lectures covering Cambridge A-Level and NABTEB subjects. Science, Technology, Commerce, and Arts streams with complete study materials.
                  </p>
                </div>

                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
                  <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                    <BookOpen className="w-5 h-5" />
                    Tutorial Programs — The Human Layer
                  </h3>
                  <p className="text-blue-100 text-sm">
                    1:1 coaching, portfolio reviews, project troubleshooting. Personalized guidance for measurable skill gains and career readiness.
                  </p>
                </div>

                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-lg">Why Choose Hybrid?</h3>
                  </div>
                  <ul className="text-blue-100 text-sm space-y-1">
                    <li>• HyFlex capability: Choose your learning mode each week</li>
                    <li>• ROI Evidence: Track real skill gains, not just attendance</li>
                    <li>• Industry Alignment: Mirrors corporate and university professional models</li>
                    <li>• Expert guidance at every step of your journey</li>
                  </ul>
                </div>
              </div>

              <button
                onClick={() => onNavigate('tutorials')}
                className="w-full bg-white text-blue-600 px-6 py-4 rounded-xl font-semibold text-lg hover:bg-blue-50 transition-all transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
              >
                <span>Explore Professional Hybrid Solution</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div>
              <SuccessTracker />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-xl mb-4">
                  <stat.icon className="text-blue-600" size={32} />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Popular Categories
            </h2>
            <p className="text-xl text-gray-600">
              Explore our diverse range of learning paths
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => onNavigate('courses')}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-all transform hover:scale-105 text-center group"
              >
                <div className="text-4xl mb-3">{getCategoryEmoji(category.icon)}</div>
                <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                  {category.name}
                </h3>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Featured Courses
              </h2>
              <p className="text-xl text-gray-600">
                Start learning with our most popular courses
              </p>
            </div>
            <button
              onClick={() => onNavigate('courses')}
              className="hidden md:flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
            >
              <span>View All</span>
              <ArrowRight size={20} />
            </button>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse">
                  <div className="w-full h-48 bg-gray-200"></div>
                  <div className="p-6 space-y-4">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredCourses.map((course) => (
                <button
                  key={course.id}
                  onClick={() => onNavigate('course', course.slug)}
                  className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-xl transition-all transform hover:scale-105 text-left group"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={course.image_url}
                      alt={course.title}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-semibold text-blue-600">
                      {course.level}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-bold text-xl text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {course.title}
                    </h3>
                    <p className="text-gray-600 mb-4 line-clamp-2">
                      {course.description}
                    </p>
                    <div className="text-sm text-gray-500 mb-4">
                      by {course.instructor_name}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-1">
                          <Star className="text-yellow-400 fill-current" size={16} />
                          <span className="font-semibold">{course.rating}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Users size={16} />
                          <span>{course.total_students.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock size={16} />
                          <span>{course.duration_hours}h</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t">
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-gray-900">
                          ${course.price}
                        </span>
                        <span className="text-blue-600 font-semibold group-hover:translate-x-1 transition-transform">
                          Learn More →
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}

          <div className="text-center mt-12 md:hidden">
            <button
              onClick={() => onNavigate('courses')}
              className="inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
            >
              <span>View All Courses</span>
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-blue-600 to-cyan-500 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Start Your Learning Journey?
          </h2>
          <p className="text-xl mb-8 text-blue-50">
            Join thousands of students already learning at Gemavic Learning Academy
          </p>
          <button
            onClick={() => onNavigate('courses')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-blue-50 transition-all transform hover:scale-105 shadow-lg inline-flex items-center space-x-2"
          >
            <span>Get Started Now</span>
            <ArrowRight size={20} />
          </button>
        </div>
      </section>
    </div>
  );
}

function getCategoryEmoji(icon: string): string {
  const emojiMap: { [key: string]: string } = {
    code: '💻',
    palette: '🎨',
    briefcase: '💼',
    megaphone: '📢',
    database: '📊',
    user: '🌱',
  };
  return emojiMap[icon] || '📚';
}
