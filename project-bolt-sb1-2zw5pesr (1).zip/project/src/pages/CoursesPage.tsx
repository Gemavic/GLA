import { useEffect, useState } from 'react';
import { Search, Star, Users, Clock, Filter } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Course {
  id: string;
  title: string;
  slug: string;
  description: string;
  instructor_name: string;
  image_url: string;
  level: string;
  duration_hours: number;
  price: number;
  rating: number;
  total_students: number;
  category_id: string;
}

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface CoursesPageProps {
  onNavigate: (page: string, courseSlug?: string) => void;
}

export function CoursesPage({ onNavigate }: CoursesPageProps) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [coursesRes, categoriesRes] = await Promise.all([
        supabase
          .from('courses')
          .select('*')
          .eq('published', true)
          .order('total_students', { ascending: false }),
        supabase.from('categories').select('*').order('name'),
      ]);

      if (coursesRes.data) setCourses(coursesRes.data);
      if (categoriesRes.data) setCategories(categoriesRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'all' || course.category_id === selectedCategory;
    const matchesLevel =
      selectedLevel === 'all' || course.level === selectedLevel;

    return matchesSearch && matchesCategory && matchesLevel;
  });

  const groupCoursesByLevel = () => {
    const levels = ['Beginner', 'Intermediate', 'Advanced'];
    return levels.map(level => ({
      level,
      courses: filteredCourses.filter(course => course.level === level)
    })).filter(group => group.courses.length > 0);
  };

  const groupedCourses = groupCoursesByLevel();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-blue-600 to-cyan-500 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Explore Our Courses
          </h1>
          <p className="text-xl text-blue-50 mb-8">
            Discover the perfect course to advance your career and skills
          </p>

          <div className="relative max-w-2xl">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search courses..."
              className="w-full pl-12 pr-4 py-4 rounded-xl text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-blue-300 transition-all"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          <aside className="lg:w-64 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Filter size={20} className="text-gray-600" />
                <h3 className="font-bold text-lg text-gray-900">Filters</h3>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Category
                  </label>
                  <div className="space-y-2">
                    <button
                      onClick={() => setSelectedCategory('all')}
                      className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                        selectedCategory === 'all'
                          ? 'bg-blue-50 text-blue-600 font-semibold'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      All Categories
                    </button>
                    {categories.map((category) => (
                      <button
                        key={category.id}
                        onClick={() => setSelectedCategory(category.id)}
                        className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                          selectedCategory === category.id
                            ? 'bg-blue-50 text-blue-600 font-semibold'
                            : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {category.name}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Level
                  </label>
                  <div className="space-y-2">
                    {['all', 'Beginner', 'Intermediate', 'Advanced'].map((level) => (
                      <button
                        key={level}
                        onClick={() => setSelectedLevel(level)}
                        className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                          selectedLevel === level
                            ? 'bg-blue-50 text-blue-600 font-semibold'
                            : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {level === 'all' ? 'All Levels' : level}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </aside>

          <main className="flex-1">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-gray-600">
                Showing <span className="font-semibold text-gray-900">{filteredCourses.length}</span> courses
              </p>
            </div>

            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse">
                    <div className="w-full h-48 bg-gray-200"></div>
                    <div className="p-6 space-y-4">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredCourses.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                <p className="text-gray-600 text-lg">
                  No courses found matching your criteria.
                </p>
              </div>
            ) : selectedLevel !== 'all' ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map((course) => (
                  <button
                    key={course.id}
                    onClick={() => onNavigate('course', course.slug)}
                    className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-xl transition-all transform hover:scale-105 text-left group"
                  >
                    <div className="relative overflow-hidden">
                      <img
                        src={course.image_url}
                        alt={course.title}
                        className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-semibold text-blue-600">
                        {course.level}
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="font-bold text-xl text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                        {course.title}
                      </h3>
                      <p className="text-gray-600 mb-4 line-clamp-2">
                        {course.description}
                      </p>
                      <div className="text-sm text-gray-500 mb-4">
                        by {course.instructor_name}
                      </div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <div className="flex items-center space-x-1">
                            <Star className="text-yellow-400 fill-current" size={16} />
                            <span className="font-semibold">{course.rating}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users size={16} />
                            <span>{course.total_students.toLocaleString()}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock size={16} />
                            <span>{course.duration_hours}h</span>
                          </div>
                        </div>
                      </div>
                      <div className="pt-4 border-t">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-gray-900">
                            ${course.price}
                          </span>
                          <span className="text-blue-600 font-semibold group-hover:translate-x-1 transition-transform">
                            View Details →
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-12">
                {groupedCourses.map((group) => (
                  <div key={group.level} className="space-y-6">
                    <div className="flex items-center gap-4">
                      <div className={`px-6 py-3 rounded-xl font-bold text-lg ${
                        group.level === 'Beginner' ? 'bg-green-100 text-green-700' :
                        group.level === 'Intermediate' ? 'bg-blue-100 text-blue-700' :
                        'bg-orange-100 text-orange-700'
                      }`}>
                        {group.level} Level
                      </div>
                      <div className="flex-1 h-px bg-gray-300"></div>
                      <span className="text-gray-500 text-sm font-semibold">
                        {group.courses.length} {group.courses.length === 1 ? 'Course' : 'Courses'}
                      </span>
                    </div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {group.courses.map((course) => (
                        <button
                          key={course.id}
                          onClick={() => onNavigate('course', course.slug)}
                          className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-xl transition-all transform hover:scale-105 text-left group"
                        >
                          <div className="relative overflow-hidden">
                            <img
                              src={course.image_url}
                              alt={course.title}
                              className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                            <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-sm font-semibold ${
                              course.level === 'Beginner' ? 'bg-green-100 text-green-700' :
                              course.level === 'Intermediate' ? 'bg-blue-100 text-blue-700' :
                              'bg-orange-100 text-orange-700'
                            }`}>
                              {course.level}
                            </div>
                          </div>
                          <div className="p-6">
                            <h3 className="font-bold text-xl text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                              {course.title}
                            </h3>
                            <p className="text-gray-600 mb-4 line-clamp-2">
                              {course.description}
                            </p>
                            <div className="text-sm text-gray-500 mb-4">
                              by {course.instructor_name}
                            </div>
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <div className="flex items-center space-x-1">
                                  <Star className="text-yellow-400 fill-current" size={16} />
                                  <span className="font-semibold">{course.rating}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Users size={16} />
                                  <span>{course.total_students.toLocaleString()}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Clock size={16} />
                                  <span>{course.duration_hours}h</span>
                                </div>
                              </div>
                            </div>
                            <div className="pt-4 border-t">
                              <div className="flex items-center justify-between">
                                <span className="text-2xl font-bold text-gray-900">
                                  ${course.price}
                                </span>
                                <span className="text-blue-600 font-semibold group-hover:translate-x-1 transition-transform">
                                  View Details →
                                </span>
                              </div>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
