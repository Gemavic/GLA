import { useEffect, useState } from 'react';
import { BookOpen, Clock, Award, TrendingUp, PlayCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface EnrolledCourse {
  id: string;
  progress_percentage: number;
  last_accessed: string;
  completed: boolean;
  course: {
    id: string;
    title: string;
    slug: string;
    description: string;
    instructor_name: string;
    image_url: string;
    level: string;
    duration_hours: number;
  };
}

interface DashboardPageProps {
  onNavigate: (page: string, courseSlug?: string) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const [enrolledCourses, setEnrolledCourses] = useState<EnrolledCourse[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadEnrollments();
    }
  }, [user]);

  const loadEnrollments = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          id,
          progress_percentage,
          last_accessed,
          completed,
          course:courses (
            id,
            title,
            slug,
            description,
            instructor_name,
            image_url,
            level,
            duration_hours
          )
        `)
        .eq('user_id', user.id)
        .order('last_accessed', { ascending: false });

      if (error) throw error;
      if (data) setEnrolledCourses(data as any);
    } catch (error) {
      console.error('Error loading enrollments:', error);
    } finally {
      setLoading(false);
    }
  };

  const inProgressCourses = enrolledCourses.filter(
    (e) => !e.completed && e.progress_percentage > 0
  );
  const notStartedCourses = enrolledCourses.filter(
    (e) => !e.completed && e.progress_percentage === 0
  );
  const completedCourses = enrolledCourses.filter((e) => e.completed);

  const stats = [
    {
      icon: BookOpen,
      label: 'Enrolled Courses',
      value: enrolledCourses.length,
      color: 'blue',
    },
    {
      icon: TrendingUp,
      label: 'In Progress',
      value: inProgressCourses.length,
      color: 'cyan',
    },
    {
      icon: Award,
      label: 'Completed',
      value: completedCourses.length,
      color: 'green',
    },
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Please sign in to view your dashboard
          </h2>
          <button
            onClick={() => onNavigate('home')}
            className="text-blue-600 hover:text-blue-700 font-semibold"
          >
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-blue-600 to-cyan-500 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-2">My Learning</h1>
          <p className="text-blue-50 text-lg">
            Welcome back, {user.user_metadata?.full_name || 'Student'}!
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div
                  className={`w-14 h-14 bg-${stat.color}-100 rounded-xl flex items-center justify-center`}
                >
                  <stat.icon className={`text-${stat.color}-600`} size={28} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading your courses...</p>
          </div>
        ) : enrolledCourses.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm p-12 text-center">
            <BookOpen className="mx-auto text-gray-400 mb-4" size={64} />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              No Courses Yet
            </h2>
            <p className="text-gray-600 mb-6">
              Start your learning journey by enrolling in a course
            </p>
            <button
              onClick={() => onNavigate('courses')}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Browse Courses
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {inProgressCourses.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  Continue Learning
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {inProgressCourses.map((enrollment) => (
                    <CourseCard
                      key={enrollment.id}
                      enrollment={enrollment}
                      onNavigate={onNavigate}
                    />
                  ))}
                </div>
              </div>
            )}

            {notStartedCourses.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  Start Learning
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {notStartedCourses.map((enrollment) => (
                    <CourseCard
                      key={enrollment.id}
                      enrollment={enrollment}
                      onNavigate={onNavigate}
                    />
                  ))}
                </div>
              </div>
            )}

            {completedCourses.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  Completed Courses
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {completedCourses.map((enrollment) => (
                    <CourseCard
                      key={enrollment.id}
                      enrollment={enrollment}
                      onNavigate={onNavigate}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function CourseCard({
  enrollment,
  onNavigate,
}: {
  enrollment: EnrolledCourse;
  onNavigate: (page: string, courseSlug?: string) => void;
}) {
  const course = enrollment.course;

  return (
    <button
      onClick={() => onNavigate('course', course.slug)}
      className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-xl transition-all transform hover:scale-105 text-left group"
    >
      <div className="relative overflow-hidden">
        <img
          src={course.image_url}
          alt={course.title}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
        />
        {enrollment.completed && (
          <div className="absolute top-4 right-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
            <Award size={16} />
            <span>Completed</span>
          </div>
        )}
        {!enrollment.completed && enrollment.progress_percentage > 0 && (
          <div className="absolute bottom-0 left-0 right-0 bg-gray-900 bg-opacity-75 p-2">
            <div className="flex items-center justify-between text-white text-sm mb-1">
              <span>{enrollment.progress_percentage}% Complete</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full transition-all"
                style={{ width: `${enrollment.progress_percentage}%` }}
              ></div>
            </div>
          </div>
        )}
      </div>
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-2">
          <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">
            {course.level}
          </span>
        </div>
        <h3 className="font-bold text-xl text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
          {course.title}
        </h3>
        <p className="text-gray-600 mb-4 line-clamp-2">{course.description}</p>
        <div className="text-sm text-gray-500 mb-4">
          by {course.instructor_name}
        </div>
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center space-x-1 text-gray-600">
            <Clock size={16} />
            <span className="text-sm">{course.duration_hours}h</span>
          </div>
          <span className="text-blue-600 font-semibold flex items-center space-x-1 group-hover:translate-x-1 transition-transform">
            <PlayCircle size={16} />
            <span>
              {enrollment.completed
                ? 'Review'
                : enrollment.progress_percentage > 0
                ? 'Continue'
                : 'Start'}
            </span>
          </span>
        </div>
      </div>
    </button>
  );
}
