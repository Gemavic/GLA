import { useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import Whiteboard from '../components/Whiteboard';
import {
  Send,
  Users,
  Download,
  Upload,
  FileText,
  X,
  Clock,
  Share2,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Minimize2,
  Menu,
  ExternalLink
} from 'lucide-react';

interface Session {
  id: string;
  title: string;
  description: string;
  tutor_id: string;
  scheduled_start: string;
  scheduled_end: string;
  status: string;
  max_participants: number;
  current_participants: number;
  whiteboard_enabled: boolean;
  chat_enabled: boolean;
  screen_share_enabled: boolean;
}

interface Participant {
  id: string;
  participant_id: string;
  participant_name: string;
  role: string;
  status: string;
  joined_at: string;
}

interface ChatMessage {
  id: string;
  sender_id: string;
  sender_name: string;
  message: string;
  created_at: string;
}

interface Material {
  id: string;
  title: string;
  description: string;
  file_url: string;
  material_type: string;
  file_size: number;
}

export default function TutorSessionPage() {
  const { user } = useAuth();
  const [session, setSession] = useState<Session | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'materials' | 'participants'>('chat');
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isInstructor, setIsInstructor] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [hasJoined, setHasJoined] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const screenShareRef = useRef<HTMLVideoElement>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    initializeSession();
  }, [user]);

  useEffect(() => {
    if (hasJoined) {
      fetchSessionData();
      const interval = setInterval(fetchSessionData, 3000);
      return () => clearInterval(interval);
    }
  }, [hasJoined]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  useEffect(() => {
    return () => {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const initializeSession = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    const sessionId = localStorage.getItem('currentTutorSession');
    if (!sessionId) {
      setLoading(false);
      return;
    }

    try {
      const { data: sessionData, error: sessionError } = await supabase
        .from('tutor_sessions')
        .select('*')
        .eq('id', sessionId)
        .maybeSingle();

      if (sessionError || !sessionData) {
        console.error('Session fetch error:', sessionError);
        setLoading(false);
        return;
      }

      setSession(sessionData);

      const [adminCheck, tutorProfileCheck] = await Promise.all([
        supabase.from('admin_users').select('id').eq('user_id', user.id).maybeSingle(),
        supabase.from('tutor_profiles').select('id, user_id').eq('user_id', user.id).maybeSingle()
      ]);

      const userIsAdmin = !adminCheck.error && adminCheck.data !== null;
      const userIsTutor = sessionData.tutor_id === user.id ||
        (tutorProfileCheck.data && sessionData.tutor_profile_id === tutorProfileCheck.data.id);

      setIsAdmin(userIsAdmin);
      setIsInstructor(userIsTutor || userIsAdmin);

      const { data: existingParticipant } = await supabase
        .from('session_participants')
        .select('id')
        .eq('session_id', sessionId)
        .eq('participant_id', user.id)
        .maybeSingle();

      if (!existingParticipant) {
        const role = userIsTutor ? 'tutor' : userIsAdmin ? 'admin' : 'student';
        const { error: joinError } = await supabase.from('session_participants').insert({
          session_id: sessionId,
          participant_id: user.id,
          participant_name: user.email?.split('@')[0] || 'Anonymous',
          role: role,
          status: 'active',
          joined_at: new Date().toISOString()
        });

        if (joinError) {
          console.error('Error joining session:', joinError);
        } else {
          await supabase
            .from('tutor_sessions')
            .update({ current_participants: (sessionData.current_participants || 0) + 1 })
            .eq('id', sessionId);
        }
      }

      setHasJoined(true);
      setLoading(false);
    } catch (error) {
      console.error('Error initializing session:', error);
      setLoading(false);
    }
  };

  const fetchSessionData = async () => {
    const sessionId = localStorage.getItem('currentTutorSession');
    if (!sessionId) return;

    try {
      const [sessionData, participantData, messageData, materialData] = await Promise.all([
        supabase.from('tutor_sessions').select('*').eq('id', sessionId).maybeSingle(),
        supabase.from('session_participants').select('*').eq('session_id', sessionId).order('joined_at', { ascending: true }),
        supabase.from('session_chat_messages').select('*').eq('session_id', sessionId).order('created_at', { ascending: true }),
        supabase.from('study_materials').select('*').eq('session_id', sessionId)
      ]);

      if (!sessionData.error && sessionData.data) {
        setSession(sessionData.data);
      }

      if (!participantData.error && participantData.data) {
        setParticipants(participantData.data);
      }

      if (!messageData.error && messageData.data) {
        setChatMessages(messageData.data);
      }

      if (!materialData.error && materialData.data) {
        setMaterials(materialData.data);
      }
    } catch (error) {
      console.error('Error fetching session data:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !session || !user) return;

    try {
      const messageToSend = newMessage;
      setNewMessage('');

      const { error } = await supabase.from('session_chat_messages').insert({
        session_id: session.id,
        sender_id: user.id,
        sender_name: user.email?.split('@')[0] || 'Anonymous',
        message: messageToSend,
        message_type: 'text',
        created_at: new Date().toISOString()
      });

      if (error) {
        console.error('Error sending message:', error);
        setNewMessage(messageToSend);
      } else {
        await fetchSessionData();
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const downloadMaterial = (material: Material) => {
    const a = document.createElement('a');
    a.href = material.file_url;
    a.download = material.title;
    a.target = '_blank';
    a.click();
  };

  const startScreenShare = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { cursor: 'always' } as MediaTrackConstraints,
        audio: false
      });

      screenStreamRef.current = stream;
      setIsScreenSharing(true);

      if (screenShareRef.current) {
        screenShareRef.current.srcObject = stream;
      }

      stream.getVideoTracks()[0].onended = () => {
        stopScreenShare();
      };
    } catch (error) {
      console.error('Error starting screen share:', error);
    }
  };

  const stopScreenShare = () => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(track => track.stop());
      screenStreamRef.current = null;
    }
    setIsScreenSharing(false);
  };

  const toggleScreenShare = () => {
    if (isScreenSharing) {
      stopScreenShare();
    } else {
      startScreenShare();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading tutor session...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center bg-white rounded-xl shadow-lg p-8 max-w-md">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-blue-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Sign In Required</h2>
          <p className="text-gray-600">Please sign in to join this tutor session</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center bg-white rounded-xl shadow-lg p-8 max-w-md">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Video className="w-8 h-8 text-gray-400" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">No Session Found</h2>
          <p className="text-gray-600">The session may have ended or doesn't exist</p>
        </div>
      </div>
    );
  }

  const timeRemaining = new Date(session.scheduled_end).getTime() - Date.now();
  const minutesRemaining = Math.max(0, Math.floor(timeRemaining / 60000));

  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-6 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">{session.title}</h1>
              {isInstructor && (
                <span className="px-2 py-0.5 bg-white bg-opacity-20 rounded text-xs font-semibold">
                  {isAdmin ? 'Admin' : 'Instructor'}
                </span>
              )}
            </div>
            <p className="text-blue-100 text-sm mt-1">{session.description}</p>
          </div>
          <div className="flex items-center gap-4 text-right">
            <div className="text-center">
              <div className="text-3xl font-bold">{minutesRemaining}</div>
              <div className="text-blue-100 text-sm">minutes left</div>
            </div>
            <div className="w-px h-12 bg-white opacity-20"></div>
            <div className="text-center">
              <div className="text-2xl font-bold">{session.current_participants}/{session.max_participants}</div>
              <div className="text-blue-100 text-sm">participants</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex gap-4 p-4 overflow-hidden">
        {/* Whiteboard / Screen Share Area */}
        <div className="flex-1 flex flex-col gap-4">
          {isScreenSharing && (
            <div className="bg-black rounded-xl shadow-lg overflow-hidden border border-gray-200 flex-1 relative">
              <div className="absolute top-3 left-3 z-10 flex items-center gap-2 px-3 py-1.5 bg-green-500 text-white rounded-full text-sm font-medium">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                Screen Sharing Active
              </div>
              <video
                ref={screenShareRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain"
              />
            </div>
          )}
          {session.whiteboard_enabled && !isScreenSharing && (
            <Whiteboard sessionId={session.id} isInstructor={isInstructor} />
          )}
          {!session.whiteboard_enabled && !isScreenSharing && (
            <div className="flex-1 bg-white rounded-xl shadow-lg border border-gray-200 flex items-center justify-center">
              <div className="text-center text-gray-500">
                <Video className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">Session Content Area</p>
                <p className="text-sm mt-1">Whiteboard is not enabled for this session</p>
              </div>
            </div>
          )}

          {/* Controls */}
          <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="text-sm font-bold text-blue-600">{user?.email?.charAt(0).toUpperCase() || 'U'}</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{isInstructor ? 'Session Controls' : 'Your Controls'}</p>
                  <p className="text-sm text-gray-600">
                    {isInstructor ? `Status: ${session.status}` : `Joined as ${isAdmin ? 'Admin' : 'Student'}`}
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={`p-3 rounded-lg transition-all ${
                    isMuted
                      ? 'bg-red-100 text-red-600'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  title={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>
                <button
                  onClick={() => setIsVideoOff(!isVideoOff)}
                  className={`p-3 rounded-lg transition-all ${
                    isVideoOff
                      ? 'bg-red-100 text-red-600'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  title={isVideoOff ? 'Enable Video' : 'Disable Video'}
                >
                  {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                </button>
                {isInstructor && (
                  <>
                    <button
                      onClick={() => setShowUploadModal(true)}
                      className="p-3 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 transition-all"
                      title="Upload Material"
                    >
                      <Upload className="w-5 h-5" />
                    </button>
                    {session.screen_share_enabled && (
                      <button
                        onClick={toggleScreenShare}
                        className={`p-3 rounded-lg transition-all ${
                          isScreenSharing
                            ? 'bg-green-100 text-green-600 ring-2 ring-green-500'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                        title={isScreenSharing ? 'Stop Sharing' : 'Share Screen'}
                      >
                        <Share2 className="w-5 h-5" />
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 flex flex-col gap-4 overflow-hidden">
          {/* Tabs */}
          <div className="flex gap-2 bg-white rounded-xl shadow-lg p-2 border border-gray-200">
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex-1 py-2 px-3 rounded-lg font-medium transition-all ${
                activeTab === 'chat'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Chat
            </button>
            <button
              onClick={() => setActiveTab('materials')}
              className={`flex-1 py-2 px-3 rounded-lg font-medium transition-all ${
                activeTab === 'materials'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Materials
            </button>
            <button
              onClick={() => setActiveTab('participants')}
              className={`flex-1 py-2 px-3 rounded-lg font-medium transition-all flex items-center justify-center gap-1 ${
                activeTab === 'participants'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Users className="w-4 h-4" />
              {participants.length}
            </button>
          </div>

          {/* Chat Tab */}
          {activeTab === 'chat' && (
            <div className="flex-1 flex flex-col bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
              {session.chat_enabled ? (
                <>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {chatMessages.length === 0 ? (
                      <div className="text-center text-gray-400 py-8">
                        <p>No messages yet</p>
                        <p className="text-sm mt-1">Start the conversation!</p>
                      </div>
                    ) : (
                      chatMessages.map((msg) => (
                        <div key={msg.id} className="flex gap-2">
                          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-bold text-blue-600">{msg.sender_name.charAt(0).toUpperCase()}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-gray-700">{msg.sender_name}</p>
                            <p className="text-sm text-gray-700 break-words">{msg.message}</p>
                            <p className="text-xs text-gray-400 mt-0.5">
                              {new Date(msg.created_at).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  <div className="border-t border-gray-200 p-3">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                        placeholder="Type message..."
                        className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        onClick={sendMessage}
                        disabled={!newMessage.trim()}
                        className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center p-4">
                  <div className="text-center text-gray-400">
                    <Send className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="font-medium">Chat Disabled</p>
                    <p className="text-sm mt-1">Chat is not enabled for this session</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Materials Tab */}
          {activeTab === 'materials' && (
            <div className="flex-1 flex flex-col bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {materials.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">
                    <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No materials shared yet</p>
                  </div>
                ) : (
                  materials.map((material) => (
                    <div
                      key={material.id}
                      className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm text-gray-900 truncate">{material.title}</p>
                          <p className="text-xs text-gray-600 mt-0.5">
                            {(material.file_size / 1024 / 1024).toFixed(2)} MB
                          </p>
                          {material.description && (
                            <p className="text-xs text-gray-600 mt-1 truncate">{material.description}</p>
                          )}
                        </div>
                        <button
                          onClick={() => downloadMaterial(material)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded transition-all"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Participants Tab */}
          {activeTab === 'participants' && (
            <div className="flex-1 flex flex-col bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {participants.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">
                    <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No participants yet</p>
                  </div>
                ) : (
                  participants.map((participant) => (
                    <div
                      key={participant.id}
                      className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-cyan-400 flex items-center justify-center text-white text-sm font-bold">
                            {participant.participant_name.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm text-gray-900 truncate">
                              {participant.participant_name}
                            </p>
                            <p className="text-xs text-gray-600">
                              {participant.role === 'student' ? 'Student' : 'Instructor'}
                            </p>
                          </div>
                        </div>
                        <div
                          className={`w-2 h-2 rounded-full ${
                            participant.status === 'active' ? 'bg-green-500' : 'bg-gray-400'
                          }`}
                        />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Upload Material</h2>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 font-medium mb-1">Click to upload or drag and drop</p>
              <p className="text-sm text-gray-500">PDF, documents, or images</p>
              <input type="file" className="hidden" />
            </div>
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
