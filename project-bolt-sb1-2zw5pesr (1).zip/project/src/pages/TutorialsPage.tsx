import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  BookOpen,
  GraduationCap,
  Award,
  School,
  BookCheck,
  FileText,
  BookMarked,
  Target,
  Users,
  Clock,
  MapPin,
  ArrowRight,
  Zap,
  TrendingUp
} from 'lucide-react';

interface TutorialProgram {
  id: string;
  name: string;
  full_name: string;
  description: string;
  target_audience: string;
  duration: string;
  level: string;
  region: string;
  icon: string;
  color: string;
  is_active: boolean;
}

interface TutorialsPageProps {
  onNavigate: (page: string, courseSlug?: string, programId?: string) => void;
}

const iconMap: Record<string, any> = {
  BookOpen,
  GraduationCap,
  Award,
  School,
  BookCheck,
  FileText,
  BookMarked,
  Target,
};

const colorMap: Record<string, { gradient: string; headerGradient: string; text: string; iconBg: string; buttonGradient: string; buttonHover: string }> = {
  blue: {
    gradient: 'bg-gradient-to-br from-blue-50 via-cyan-50 to-blue-100',
    headerGradient: 'bg-gradient-to-r from-blue-500 to-cyan-500',
    text: 'text-blue-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-blue-500 to-cyan-500',
    buttonHover: 'hover:from-blue-600 hover:to-cyan-600'
  },
  purple: {
    gradient: 'bg-gradient-to-br from-violet-50 via-fuchsia-50 to-violet-100',
    headerGradient: 'bg-gradient-to-r from-violet-500 to-fuchsia-500',
    text: 'text-violet-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-violet-500 to-fuchsia-500',
    buttonHover: 'hover:from-violet-600 hover:to-fuchsia-600'
  },
  green: {
    gradient: 'bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-100',
    headerGradient: 'bg-gradient-to-r from-emerald-500 to-teal-500',
    text: 'text-emerald-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-emerald-500 to-teal-500',
    buttonHover: 'hover:from-emerald-600 hover:to-teal-600'
  },
  orange: {
    gradient: 'bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100',
    headerGradient: 'bg-gradient-to-r from-orange-500 to-amber-500',
    text: 'text-orange-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-orange-500 to-amber-500',
    buttonHover: 'hover:from-orange-600 hover:to-amber-600'
  },
  red: {
    gradient: 'bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100',
    headerGradient: 'bg-gradient-to-r from-rose-500 to-pink-500',
    text: 'text-rose-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-rose-500 to-pink-500',
    buttonHover: 'hover:from-rose-600 hover:to-pink-600'
  },
  teal: {
    gradient: 'bg-gradient-to-br from-teal-50 via-cyan-50 to-teal-100',
    headerGradient: 'bg-gradient-to-r from-teal-500 to-cyan-500',
    text: 'text-teal-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-teal-500 to-cyan-500',
    buttonHover: 'hover:from-teal-600 hover:to-cyan-600'
  },
  indigo: {
    gradient: 'bg-gradient-to-br from-indigo-50 via-blue-50 to-indigo-100',
    headerGradient: 'bg-gradient-to-r from-indigo-500 to-blue-500',
    text: 'text-indigo-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-indigo-500 to-blue-500',
    buttonHover: 'hover:from-indigo-600 hover:to-blue-600'
  },
  yellow: {
    gradient: 'bg-gradient-to-br from-yellow-50 via-amber-50 to-yellow-100',
    headerGradient: 'bg-gradient-to-r from-yellow-500 to-amber-500',
    text: 'text-yellow-700',
    iconBg: 'bg-white',
    buttonGradient: 'bg-gradient-to-r from-yellow-500 to-amber-500',
    buttonHover: 'hover:from-yellow-600 hover:to-amber-600'
  },
};

const levelBadgeMap: Record<string, { bg: string; text: string }> = {
  foundation: { bg: 'bg-blue-100', text: 'text-blue-800' },
  intermediate: { bg: 'bg-yellow-100', text: 'text-yellow-800' },
  advanced: { bg: 'bg-red-100', text: 'text-red-800' },
};

export default function TutorialsPage({ onNavigate }: TutorialsPageProps) {
  const [programs, setPrograms] = useState<TutorialProgram[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRegion, setSelectedRegion] = useState<string>('All');

  useEffect(() => {
    fetchPrograms();
  }, []);

  const fetchPrograms = async () => {
    try {
      const { data, error } = await supabase
        .from('hybrid_solution_tracks')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setPrograms(data || []);
    } catch (error) {
      console.error('Error fetching programs:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPrograms = selectedRegion === 'All'
    ? programs
    : programs.filter(p => p.region === selectedRegion || p.region === 'Both');

  const regions = ['All', 'Nigeria', 'International'];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading programs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Professional Hybrid Solution
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-4">
            Our Guided Hybrid Track combines structured curriculum with personalized coaching.
          </p>
          <p className="text-gray-700 max-w-3xl mx-auto">
            Choose your learning mode to fit your week — leverage both Prep Classes (live/recorded curriculum) and Tutorial Programs (1:1 coaching, portfolio reviews, project troubleshooting) for measurable skill gains aligned with industry standards.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {regions.map((region) => (
            <button
              key={region}
              onClick={() => setSelectedRegion(region)}
              className={`px-6 py-2 rounded-full font-medium transition-all transform ${
                selectedRegion === region
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white shadow-lg scale-105'
                  : 'bg-white text-gray-700 hover:bg-gray-100 shadow hover:scale-105'
              }`}
            >
              {region}
            </button>
          ))}
        </div>

        {filteredPrograms.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No programs found for the selected region.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPrograms.map((program) => {
              const Icon = iconMap[program.icon] || BookOpen;
              const colors = colorMap[program.color] || colorMap.blue;
              const levelBadge = levelBadgeMap[program.level];

              return (
                <div
                  key={program.id}
                  className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 border border-gray-200"
                >
                  <div className={`${colors.gradient} p-6 relative`}>
                    <div className="flex items-start justify-between mb-4">
                      <div className={`p-3 rounded-lg ${colors.iconBg} shadow-md ${colors.text}`}>
                        <Icon className="w-8 h-8" />
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${levelBadge.bg} ${levelBadge.text}`}>
                        {program.level.charAt(0).toUpperCase() + program.level.slice(1)}
                      </span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-1">
                      {program.name}
                    </h3>
                    <p className="text-sm text-gray-700 font-medium">
                      {program.full_name}
                    </p>
                  </div>

                  <div className="p-6">
                    <p className="text-gray-700 mb-6 leading-relaxed">
                      {program.description}
                    </p>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-sm text-gray-600">
                        <Users className="w-5 h-5 mr-3 text-gray-400" />
                        <span>{program.target_audience}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="w-5 h-5 mr-3 text-gray-400" />
                        <span>Duration: {program.duration}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="w-5 h-5 mr-3 text-gray-400" />
                        <span>Region: {program.region}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigate('tutorialProgram', undefined, program.id)}
                      className={`w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-semibold text-white ${colors.buttonGradient} ${colors.buttonHover} shadow-md transition-all transform hover:scale-105`}
                    >
                      View Sessions
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-16 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl shadow-lg p-8 border border-blue-200">
          <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">
            Why the Integrated Model is the Professional Standard
          </h2>
          <p className="text-center text-gray-600 mb-8">Mirrors how corporate L&D and university professional academies operate</p>
          <div className="grid md:grid-cols-3 gap-8 mt-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">HyFlex Capability</h3>
              <p className="text-gray-600 text-sm">
                Students choose the mode that fits their week — combine live prep classes with recorded access and personalized 1:1 coaching sessions
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">ROI Evidence</h3>
              <p className="text-gray-600 text-sm">
                Measurable skill gains tracked through projects, portfolio reviews, and assessments — not just attendance metrics
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-teal-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Industry Alignment</h3>
              <p className="text-gray-600 text-sm">
                Our approach mirrors corporate training and university professional academies, positioning you for the future of learning
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
