/*
  # Create Tutor Profiles and Applications System

  1. New Tables
    - `tutor_profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `display_name` (text)
      - `bio` (text)
      - `expertise` (text array)
      - `qualifications` (text)
      - `experience_years` (integer)
      - `hourly_rate` (decimal)
      - `status` (text: pending, approved, rejected, suspended)
      - `applied_at` (timestamp)
      - `reviewed_at` (timestamp)
      - `reviewed_by` (uuid)
      - `rejection_reason` (text)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `admin_users`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `role` (text: super_admin, admin, moderator)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Users can read their own tutor profile
    - Users can insert their own tutor application
    - Admins can update tutor profiles (approve/reject)
    - Only admins can read all tutor profiles
*/

-- Create tutor_profiles table
CREATE TABLE IF NOT EXISTS tutor_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  bio text,
  expertise text[] DEFAULT '{}',
  qualifications text,
  experience_years integer DEFAULT 0,
  hourly_rate decimal(10,2) DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'suspended')),
  applied_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id),
  rejection_reason text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin', 'admin', 'moderator')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_tutor_profiles_user_id ON tutor_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_tutor_profiles_status ON tutor_profiles(status);
CREATE INDEX IF NOT EXISTS idx_admin_users_user_id ON admin_users(user_id);

-- Enable RLS
ALTER TABLE tutor_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Tutor profiles policies
CREATE POLICY "Users can view their own tutor profile"
  ON tutor_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own tutor application"
  ON tutor_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own pending profile"
  ON tutor_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'pending')
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all tutor profiles"
  ON tutor_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can update any tutor profile"
  ON tutor_profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = auth.uid()
    )
  );

-- Admin users policies
CREATE POLICY "Admins can view admin list"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can check if they are admin"
  ON admin_users FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Update tutor_sessions to reference tutor_profiles
ALTER TABLE tutor_sessions 
  ADD COLUMN IF NOT EXISTS tutor_profile_id uuid REFERENCES tutor_profiles(id);

-- Function to check if user is approved tutor
CREATE OR REPLACE FUNCTION is_approved_tutor(check_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tutor_profiles
    WHERE user_id = check_user_id
    AND status = 'approved'
    AND is_active = true
  );
$$;

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(check_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM admin_users
    WHERE user_id = check_user_id
  );
$$;