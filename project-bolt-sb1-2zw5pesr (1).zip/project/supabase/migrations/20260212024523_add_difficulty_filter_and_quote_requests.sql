/*
  # Add Quote Request System and Course Difficulty Filtering

  1. Changes
    - Add constraint to courses.level for standardized difficulty levels
    - Create `quote_requests` table for tutorial session pricing inquiries
    - Add `hide_pricing` flag to tutorial_sessions
    
  2. New Tables
    - `quote_requests`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - Student requesting quote
      - `session_id` (uuid) - Tutorial session
      - `student_name` (text) - Student's full name
      - `student_email` (text) - Contact email
      - `student_phone` (text, optional) - Contact phone
      - `message` (text) - Additional information/questions
      - `status` (text) - pending, responded, closed
      - `created_at` (timestamptz)
      - `responded_at` (timestamptz)
      
  3. Security
    - Enable RLS on quote_requests
    - Users can create and view their own quote requests
    - Admin access for responding to quotes
*/

-- Add check constraint to courses level if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'courses_level_check'
  ) THEN
    ALTER TABLE courses 
    ADD CONSTRAINT courses_level_check 
    CHECK (level IN ('Beginner', 'Intermediate', 'Advanced'));
  END IF;
END $$;

-- Add hide_pricing flag to tutorial_sessions
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tutorial_sessions' AND column_name = 'hide_pricing'
  ) THEN
    ALTER TABLE tutorial_sessions 
    ADD COLUMN hide_pricing boolean DEFAULT true;
  END IF;
END $$;

-- Update all existing tutorial sessions to hide pricing
UPDATE tutorial_sessions SET hide_pricing = true WHERE hide_pricing IS NULL;

-- Create quote_requests table
CREATE TABLE IF NOT EXISTS quote_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  session_id uuid NOT NULL REFERENCES tutorial_sessions(id) ON DELETE CASCADE,
  student_name text NOT NULL,
  student_email text NOT NULL,
  student_phone text DEFAULT '',
  message text DEFAULT '',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'responded', 'closed')),
  admin_response text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  responded_at timestamptz
);

-- Enable RLS on quote_requests
ALTER TABLE quote_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies for quote_requests
CREATE POLICY "Users can view own quote requests"
  ON quote_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can create quote requests"
  ON quote_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pending quote requests"
  ON quote_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'pending')
  WITH CHECK (auth.uid() = user_id AND status = 'pending');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_quote_requests_user_id ON quote_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_quote_requests_session_id ON quote_requests(session_id);
CREATE INDEX IF NOT EXISTS idx_quote_requests_status ON quote_requests(status);
CREATE INDEX IF NOT EXISTS idx_courses_level ON courses(level);