/*
  # Add NABTEB Programs
  
  1. New Programs
    - NABTEB O/L (National Business and Technical Examinations Board - Ordinary Level)
      - Technical and vocational education certification
      - Equivalent to WAEC/NECO for technical subjects
      - Duration: 1-3 years
      - Target: Nigerian secondary school students (SS1-SS3)
      - Color: cyan
      
    - NABTEB A/L (National Business and Technical Examinations Board - Advanced Level)
      - Advanced technical and vocational certification
      - Direct entry qualification for polytechnics and universities
      - Duration: 1-2 years
      - Target: Nigerian students seeking advanced technical certification
      - Color: violet
  
  2. Tutorial Sessions
    - NABTEB O/L Technical Session (May/June 2026)
      - Technical subjects including Applied Electricity, Data Processing, Technical Drawing
    - NABTEB O/L Business Session (May/June 2026)
      - Business subjects including Commerce, Book Keeping, Office Practice
    - NABTEB A/L Science & Technology Session (2026/2027)
      - Advanced technical subjects for polytechnic/university entry
    - NABTEB A/L Business Studies Session (2026/2027)
      - Advanced business studies for higher institution entry
  
  3. Security
    - All tables already have RLS enabled
    - Policies already configured for authenticated users
*/

-- Insert NABTEB O/L Program
INSERT INTO tutorial_programs (name, full_name, description, target_audience, duration, level, region, icon, color) VALUES
  (
    'NABTEB O/L',
    'National Business and Technical Examinations Board - Ordinary Level',
    'Comprehensive preparation for NABTEB Ordinary Level examinations. Specialized in technical and vocational education covering Business, Engineering, and Applied Sciences subjects with practical skills development.',
    'Nigerian secondary school students (SS1-SS3) pursuing technical/vocational education',
    '1-3 years',
    'intermediate',
    'Nigeria',
    'Wrench',
    'cyan'
  ),
  (
    'NABTEB A/L',
    'National Business and Technical Examinations Board - Advanced Level',
    'Advanced preparation for NABTEB A Level examinations. Intensive technical and vocational training program for students seeking direct entry into polytechnics and universities, with focus on specialized technical subjects.',
    'Nigerian students seeking advanced technical certification and direct entry',
    '1-2 years',
    'advanced',
    'Nigeria',
    'Cog',
    'violet'
  )
ON CONFLICT DO NOTHING;

-- Insert NABTEB Tutorial Sessions
INSERT INTO tutorial_sessions (program_id, title, description, subjects, schedule, price, currency, max_students, start_date, end_date) VALUES
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NABTEB O/L' LIMIT 1),
    'NABTEB O/L Technical Stream - May/June 2026',
    'Complete NABTEB O Level preparation for Technical subjects. Covers Applied Electricity, Data Processing, Technical Drawing, and core subjects with practical demonstrations and hands-on training.',
    ARRAY['Applied Electricity', 'Data Processing', 'Technical Drawing', 'Mathematics', 'English Language', 'Physics'],
    'Weekdays 4:00 PM - 7:00 PM, Saturdays 10:00 AM - 2:00 PM',
    65000,
    'NGN',
    30,
    '2026-02-01',
    '2026-05-31'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NABTEB O/L' LIMIT 1),
    'NABTEB O/L Business Stream - May/June 2026',
    'Comprehensive NABTEB O Level preparation for Business subjects. Covers Commerce, Book Keeping, Office Practice, Economics with practical business skills and exam strategies.',
    ARRAY['Commerce', 'Book Keeping', 'Office Practice', 'Economics', 'Mathematics', 'English Language'],
    'Monday, Wednesday, Friday 3:30 PM - 6:30 PM, Saturdays 9:00 AM - 1:00 PM',
    62000,
    'NGN',
    35,
    '2026-02-01',
    '2026-05-31'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NABTEB A/L' LIMIT 1),
    'NABTEB A/L Science & Technology - 2026/2027',
    'Advanced NABTEB preparation for Science and Technology students. Intensive study covering Applied Physics, Applied Chemistry, Applied Mathematics, and Computer Science for direct entry qualification.',
    ARRAY['Applied Physics', 'Applied Chemistry', 'Applied Mathematics', 'Computer Science', 'Technical English'],
    'Monday to Friday 9:00 AM - 3:00 PM',
    150000,
    'NGN',
    25,
    '2026-09-01',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NABTEB A/L' LIMIT 1),
    'NABTEB A/L Business Studies - 2026/2027',
    'Advanced NABTEB Business Studies program. Covers Advanced Accounting, Business Management, Marketing, and Economics for direct entry into higher institutions.',
    ARRAY['Advanced Accounting', 'Business Management', 'Marketing', 'Economics', 'Business Statistics'],
    'Monday to Thursday 2:00 PM - 6:00 PM, Saturdays 10:00 AM - 3:00 PM',
    145000,
    'NGN',
    28,
    '2026-09-01',
    '2027-06-30'
  )
ON CONFLICT DO NOTHING;