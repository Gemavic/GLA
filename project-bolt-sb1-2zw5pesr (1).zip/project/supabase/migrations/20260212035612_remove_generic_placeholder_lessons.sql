/*
  # Remove Generic Placeholder Lessons

  ## Changes
  This migration removes lessons containing generic programming-related placeholder content
  that doesn't match the actual course subject matter.

  ## Problem
  - 50 lessons across multiple courses contain the same generic template
  - Content includes phrases like "Write clean, maintainable code", "Share on GitHub", "Deploy solution"
  - These lessons appear in non-programming courses (French, Spanish, Business, etc.)
  - Creates confusion as content doesn't match the course topic

  ## Solution
  - Delete all lessons with the generic placeholder content
  - Courses will retain their properly written, topic-specific lessons
  - Improves course quality and learner experience

  ## Affected Courses
  - Language courses (French, Spanish)
  - Business courses (Marketing, Finance, Entrepreneurship)
  - Design courses (Graphic Design, Video Editing)
  - Many others with mismatched content
*/

-- Delete lessons with generic placeholder content
DELETE FROM lessons
WHERE content LIKE '%Write clean, maintainable code%'
  AND content LIKE '%Share on GitHub%'
  AND content LIKE '%Deploy solution%'
  AND content LIKE '%Fundamental principles%Best practices%Industry standards%';
