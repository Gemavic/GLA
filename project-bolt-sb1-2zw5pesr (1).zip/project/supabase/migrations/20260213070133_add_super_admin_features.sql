/*
  # Super Admin Features - Audit Logs and Admin Management

  1. New Tables
    - `admin_audit_logs` - Tracks all admin actions for accountability
      - `id` (uuid, primary key)
      - `admin_id` (uuid, references auth.users)
      - `action` (text) - The action performed
      - `target_type` (text) - Type of target (tutor, admin, session, etc.)
      - `target_id` (uuid) - ID of the affected record
      - `details` (jsonb) - Additional details about the action
      - `ip_address` (text) - IP address of the admin
      - `created_at` (timestamptz)

  2. Schema Changes
    - Add `deleted_at` column to tutor_profiles for soft deletion
    - Add `deleted_by` column to track who deleted the tutor

  3. Security
    - Enable RLS on admin_audit_logs
    - Only super_admin can view all audit logs
    - Regular admins can only see their own actions
*/

-- Create admin audit logs table
CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES auth.users(id),
  action text NOT NULL,
  target_type text NOT NULL,
  target_id uuid,
  details jsonb DEFAULT '{}',
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- Add soft delete columns to tutor_profiles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutor_profiles' AND column_name = 'deleted_at'
  ) THEN
    ALTER TABLE tutor_profiles ADD COLUMN deleted_at timestamptz;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutor_profiles' AND column_name = 'deleted_by'
  ) THEN
    ALTER TABLE tutor_profiles ADD COLUMN deleted_by uuid REFERENCES auth.users(id);
  END IF;
END $$;

-- Create index for faster audit log queries
CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_admin_id ON admin_audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_created_at ON admin_audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_target_type ON admin_audit_logs(target_type);
CREATE INDEX IF NOT EXISTS idx_tutor_profiles_deleted_at ON tutor_profiles(deleted_at);

-- Enable RLS
ALTER TABLE admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Super admin can view all audit logs
CREATE POLICY "Super admin can view all audit logs"
  ON admin_audit_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = auth.uid()
      AND admin_users.role = 'super_admin'
    )
  );

-- Regular admins can view only their own audit logs
CREATE POLICY "Admins can view own audit logs"
  ON admin_audit_logs FOR SELECT
  TO authenticated
  USING (
    admin_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = auth.uid()
      AND admin_users.role = 'admin'
    )
  );

-- All admins can insert audit logs
CREATE POLICY "Admins can insert audit logs"
  ON admin_audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = auth.uid()
    )
  );

-- Function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  p_action text,
  p_target_type text,
  p_target_id uuid DEFAULT NULL,
  p_details jsonb DEFAULT '{}'
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_log_id uuid;
BEGIN
  INSERT INTO admin_audit_logs (admin_id, action, target_type, target_id, details)
  VALUES (auth.uid(), p_action, p_target_type, p_target_id, p_details)
  RETURNING id INTO v_log_id;
  
  RETURN v_log_id;
END;
$$;

-- Function for super admin to manage other admins
CREATE OR REPLACE FUNCTION manage_admin_user(
  p_target_user_id uuid,
  p_new_role text DEFAULT NULL,
  p_remove boolean DEFAULT false
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_role text;
  v_target_role text;
  v_result jsonb;
BEGIN
  -- Check if caller is super_admin
  SELECT role INTO v_caller_role
  FROM admin_users
  WHERE user_id = auth.uid();
  
  IF v_caller_role IS NULL OR v_caller_role != 'super_admin' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Only super_admin can manage other admins');
  END IF;
  
  -- Cannot modify own account
  IF p_target_user_id = auth.uid() THEN
    RETURN jsonb_build_object('success', false, 'error', 'Cannot modify your own admin account');
  END IF;
  
  -- Get target's current role
  SELECT role INTO v_target_role
  FROM admin_users
  WHERE user_id = p_target_user_id;
  
  IF p_remove THEN
    -- Remove admin
    DELETE FROM admin_users WHERE user_id = p_target_user_id;
    
    -- Log the action
    PERFORM log_admin_action(
      'REMOVE_ADMIN',
      'admin',
      p_target_user_id,
      jsonb_build_object('previous_role', v_target_role)
    );
    
    RETURN jsonb_build_object('success', true, 'message', 'Admin removed successfully');
  ELSIF p_new_role IS NOT NULL THEN
    -- Update role
    IF p_new_role NOT IN ('admin', 'super_admin') THEN
      RETURN jsonb_build_object('success', false, 'error', 'Invalid role. Must be admin or super_admin');
    END IF;
    
    UPDATE admin_users SET role = p_new_role WHERE user_id = p_target_user_id;
    
    -- Log the action
    PERFORM log_admin_action(
      'UPDATE_ADMIN_ROLE',
      'admin',
      p_target_user_id,
      jsonb_build_object('previous_role', v_target_role, 'new_role', p_new_role)
    );
    
    RETURN jsonb_build_object('success', true, 'message', 'Admin role updated successfully');
  END IF;
  
  RETURN jsonb_build_object('success', false, 'error', 'No action specified');
END;
$$;

-- Function for super admin to delete tutor profiles
CREATE OR REPLACE FUNCTION delete_tutor_profile(p_tutor_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_role text;
  v_tutor_name text;
BEGIN
  -- Check if caller is super_admin
  SELECT role INTO v_caller_role
  FROM admin_users
  WHERE user_id = auth.uid();
  
  IF v_caller_role IS NULL OR v_caller_role != 'super_admin' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Only super_admin can delete tutor profiles');
  END IF;
  
  -- Get tutor name for logging
  SELECT full_name INTO v_tutor_name
  FROM tutor_profiles
  WHERE id = p_tutor_id AND deleted_at IS NULL;
  
  IF v_tutor_name IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Tutor not found or already deleted');
  END IF;
  
  -- Soft delete the tutor
  UPDATE tutor_profiles
  SET deleted_at = now(), deleted_by = auth.uid()
  WHERE id = p_tutor_id;
  
  -- Log the action
  PERFORM log_admin_action(
    'DELETE_TUTOR',
    'tutor',
    p_tutor_id,
    jsonb_build_object('tutor_name', v_tutor_name)
  );
  
  RETURN jsonb_build_object('success', true, 'message', 'Tutor profile deleted successfully');
END;
$$;

-- Function to add new admin (super_admin only)
CREATE OR REPLACE FUNCTION add_admin_user(
  p_user_id uuid,
  p_role text DEFAULT 'admin'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller_role text;
BEGIN
  -- Check if caller is super_admin
  SELECT role INTO v_caller_role
  FROM admin_users
  WHERE user_id = auth.uid();
  
  IF v_caller_role IS NULL OR v_caller_role != 'super_admin' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Only super_admin can add new admins');
  END IF;
  
  IF p_role NOT IN ('admin', 'super_admin') THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid role. Must be admin or super_admin');
  END IF;
  
  -- Check if user already exists as admin
  IF EXISTS (SELECT 1 FROM admin_users WHERE user_id = p_user_id) THEN
    RETURN jsonb_build_object('success', false, 'error', 'User is already an admin');
  END IF;
  
  -- Add admin
  INSERT INTO admin_users (user_id, role) VALUES (p_user_id, p_role);
  
  -- Log the action
  PERFORM log_admin_action(
    'ADD_ADMIN',
    'admin',
    p_user_id,
    jsonb_build_object('role', p_role)
  );
  
  RETURN jsonb_build_object('success', true, 'message', 'Admin added successfully');
END;
$$;