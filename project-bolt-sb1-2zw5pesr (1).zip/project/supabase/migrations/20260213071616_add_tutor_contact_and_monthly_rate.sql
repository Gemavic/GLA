/*
  # Add Tutor Contact Info and Change to Monthly Rate

  1. Schema Changes
    - Add `email` column to tutor_profiles for tutor contact email
    - Add `phone` column to tutor_profiles for tutor phone number
    - Rename `hourly_rate` to `monthly_rate` for monthly fee in Naira
    - Add `full_name` column if not exists for tutor's legal name

  2. Notes
    - Monthly rate is stored in NGN (Nigerian Naira)
    - Email and phone allow admins to contact tutors directly
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutor_profiles' AND column_name = 'email'
  ) THEN
    ALTER TABLE tutor_profiles ADD COLUMN email text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutor_profiles' AND column_name = 'phone'
  ) THEN
    ALTER TABLE tutor_profiles ADD COLUMN phone text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutor_profiles' AND column_name = 'full_name'
  ) THEN
    ALTER TABLE tutor_profiles ADD COLUMN full_name text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutor_profiles' AND column_name = 'monthly_rate'
  ) THEN
    ALTER TABLE tutor_profiles ADD COLUMN monthly_rate numeric DEFAULT 0;
  END IF;
END $$;

COMMENT ON COLUMN tutor_profiles.email IS 'Tutor contact email address';
COMMENT ON COLUMN tutor_profiles.phone IS 'Tutor phone number';
COMMENT ON COLUMN tutor_profiles.monthly_rate IS 'Monthly tutoring fee in Nigerian Naira (NGN)';