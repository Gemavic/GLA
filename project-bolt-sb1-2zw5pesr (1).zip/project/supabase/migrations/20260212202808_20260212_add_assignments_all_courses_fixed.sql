/*
  # Add Comprehensive Assignments for All Courses

  1. Add 1-2 additional assignments per course
  2. Practical, hands-on projects
  3. Varying difficulty levels
  4. Clear instructions and rubrics
*/

WITH course_list AS (
  SELECT 
    c.id,
    c.title
  FROM courses c
  WHERE c.published = true
)

INSERT INTO assignments (course_id, title, description, instructions, due_date, total_points, submission_type, status)
SELECT 
  cl.id,
  CASE gs.num
    WHEN 1 THEN cl.title || ' - Practical Project'
    WHEN 2 THEN cl.title || ' - Capstone Project'
  END,
  CASE gs.num
    WHEN 1 THEN 'Apply core concepts from ' || cl.title || ' to build a working solution.'
    WHEN 2 THEN 'Complete a comprehensive capstone project demonstrating mastery.'
  END,
  CASE gs.num
    WHEN 1 THEN 'Build a solution that demonstrates understanding of key concepts. Include code, documentation, and test results.'
    WHEN 2 THEN 'Complete a comprehensive project. Submit source code, documentation, and deployment guide.'
  END,
  now() + interval '21 days',
  CASE gs.num WHEN 1 THEN 100 ELSE 150 END,
  'both',
  'published'
FROM course_list cl
CROSS JOIN generate_series(1, 2) gs(num)
ON CONFLICT DO NOTHING;
