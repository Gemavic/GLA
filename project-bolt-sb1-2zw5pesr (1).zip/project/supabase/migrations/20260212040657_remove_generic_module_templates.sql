/*
  # Remove Generic Module Template Lessons

  ## Problem Identified
  During comprehensive content quality review, found 108 lessons across multiple courses 
  containing identical generic template content with no course-specific information.

  ## Template Content Pattern
  These lessons have titles like "Module X - Core Concepts", "Module X - Practical Application", 
  "Module X - Advanced Topics" and contain only generic filler text:
  - "This module covers essential concepts and practical applications"
  - "Core concepts, Best practices, Industry standards"
  - "Real-world examples, Hands-on exercises"
  - Generic 767-character template with no actual educational value

  ## Affected Courses (22 courses total)
  - Mobile App Development with React Native (18 generic lessons)
  - Natural Language Processing (18 generic lessons)
  - Network Security Fundamentals (18 generic lessons)
  - Graphic Design Pro (18 generic lessons)
  - UI/UX Design Fundamentals (18 generic lessons)
  - SEO Mastery Course (18 generic lessons)
  - Docker & Kubernetes Essentials (18 generic lessons)
  - AWS Cloud Practitioner (18 generic lessons)
  - Adobe Photoshop Complete (18 generic lessons)
  - SQL & Database Design (18 generic lessons)
  - And 12 more courses with 9-15 generic lessons each

  ## Solution
  Delete all 108 generic template lessons to improve course quality.
  Courses will retain their properly written, topic-specific lessons.

  ## Impact
  - Removes low-quality filler content
  - Improves learner experience
  - Maintains only genuine educational content
  - Affected courses will have fewer but higher quality lessons
*/

-- Delete all generic module template lessons
DELETE FROM lessons
WHERE content LIKE '%This module covers essential concepts and practical applications%'
  AND content LIKE '%Core concepts%Best practices%Industry standards%'
  AND (
    title LIKE 'Module % - Core Concepts'
    OR title LIKE 'Module % - Practical Application'
    OR title LIKE 'Module % - Advanced Topics'
  );
