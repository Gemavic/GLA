/*
  # Tutor Platform RLS Policies Only

  Security policies for tutor sessions, materials, and assignments
*/

-- RLS Policies for tutor_sessions (check if not exists first)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'tutor_sessions' AND policyname = 'Tutors create sessions'
  ) THEN
    CREATE POLICY "Tutors create sessions"
      ON tutor_sessions FOR INSERT
      TO authenticated
      WITH CHECK (tutor_id = auth.uid());
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'tutor_sessions' AND policyname = 'View active sessions'
  ) THEN
    CREATE POLICY "View active sessions"
      ON tutor_sessions FOR SELECT
      TO authenticated, anon
      USING (is_active = true);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'tutor_sessions' AND policyname = 'Tutors update own sessions'
  ) THEN
    CREATE POLICY "Tutors update own sessions"
      ON tutor_sessions FOR UPDATE
      TO authenticated
      USING (tutor_id = auth.uid())
      WITH CHECK (tutor_id = auth.uid());
  END IF;
END $$;
