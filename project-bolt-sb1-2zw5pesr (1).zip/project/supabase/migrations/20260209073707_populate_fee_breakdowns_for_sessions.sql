/*
  # Populate Fee Breakdowns for Tutorial Sessions

  1. Updates
    - Add detailed fee breakdowns for all tutorial sessions
    - Fee structures vary by program type (JUPEB, IJMB, WAEC, NECO, JAMB, Cambridge, GCE)
    - Includes registration, acceptance, textbook, tuition, examination, and optional hostel fees
    
  2. Fee Structure Examples
    - JUPEB: ₦240,000-245,000 total (Registration, Acceptance, Textbook, Tuition, Exam)
    - IJMB: ₦175,000 total
    - Cambridge: ₦110,000-115,000 total
    - GCE O/L: ₦75,000-85,000 total
    - GCE A/L: ₦85,000-90,000 total
    - WAEC: ₦52,000-58,000 total
    - NECO: ₦52,000-55,000 total
    - JAMB: ₦33,000 total
    
  3. Notes
    - All fees subject to change based on economic conditions
    - Hostel accommodation is optional
*/

-- Update JUPEB sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 20000,
  'acceptance', 20000,
  'textbook', 30000,
  'tuition', 170000,
  'examination', 100000,
  'hostel', 60000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'JUPEB')
  AND fee_breakdown IS NULL;

-- Update IJMB sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 15000,
  'acceptance', 15000,
  'textbook', 25000,
  'tuition', 100000,
  'examination', 70000,
  'hostel', 50000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'IJMB')
  AND fee_breakdown IS NULL;

-- Update Cambridge A Level sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 10000,
  'acceptance', 10000,
  'textbook', 35000,
  'tuition', 85000,
  'examination', 90000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'Cambridge AS/A Level')
  AND fee_breakdown IS NULL;

-- Update GCE O Level sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 8000,
  'acceptance', 7000,
  'textbook', 20000,
  'tuition', 60000,
  'examination', 45000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'GCE O/L')
  AND fee_breakdown IS NULL;

-- Update GCE A Level sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 8000,
  'acceptance', 7000,
  'textbook', 25000,
  'tuition', 65000,
  'examination', 50000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'GCE A/L')
  AND fee_breakdown IS NULL;

-- Update WAEC sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 5000,
  'textbook', 15000,
  'tuition', 45000,
  'examination', 35000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'WAEC')
  AND fee_breakdown IS NULL;

-- Update NECO sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 5000,
  'textbook', 15000,
  'tuition', 42000,
  'examination', 33000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'NECO')
  AND fee_breakdown IS NULL;

-- Update JAMB sessions with detailed fee breakdown
UPDATE tutorial_sessions
SET fee_breakdown = jsonb_build_object(
  'registration', 3000,
  'textbook', 8000,
  'tuition', 20000,
  'examination', 12000
)
WHERE program_id IN (SELECT id FROM tutorial_programs WHERE name = 'JAMB UTME')
  AND fee_breakdown IS NULL;