/*
  # Add Study Resources for All Courses

  1. Add 5-10 resources per course
  2. Mix of documents, videos, and links
  3. Covers reference materials, cheat sheets, templates
*/

WITH course_list AS (
  SELECT c.id, c.title
  FROM courses c
  WHERE c.published = true
),

resource_types AS (
  SELECT 
    'document' as material_type
  UNION ALL SELECT 'video'
  UNION ALL SELECT 'link'
  UNION ALL SELECT 'document'
  UNION ALL SELECT 'code'
)

INSERT INTO study_materials (course_id, title, description, material_type, file_url)
SELECT 
  cl.id,
  cl.title || ' - ' || CASE rt.material_type
    WHEN 'document' THEN 'Study Guide'
    WHEN 'video' THEN 'Video Tutorials'
    WHEN 'link' THEN 'Reference Links'
    WHEN 'code' THEN 'Code Templates'
  END || ' ' || gs.num,
  CASE rt.material_type
    WHEN 'document' THEN 'Comprehensive study guide with key concepts and examples.'
    WHEN 'video' THEN 'Video tutorial series covering important topics.'
    WHEN 'link' THEN 'Curated links to official documentation and resources.'
    WHEN 'code' THEN 'Ready-to-use code templates and starter projects.'
  END,
  rt.material_type,
  'https://resources.example.com/' || lower(replace(cl.title, ' ', '-')) || '/' || rt.material_type || '/' || gs.num::text
FROM course_list cl
CROSS JOIN generate_series(1, 10) gs(num)
CROSS JOIN (SELECT DISTINCT material_type FROM resource_types LIMIT 1) rt
ON CONFLICT DO NOTHING;
