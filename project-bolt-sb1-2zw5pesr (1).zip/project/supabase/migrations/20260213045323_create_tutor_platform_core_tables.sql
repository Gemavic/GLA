/*
  # Tutor Platform Schema for Live Classes - Part 1

  Core tables for tutor sessions and learning materials
*/

-- Create tutor sessions table
CREATE TABLE IF NOT EXISTS tutor_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  tutor_id uuid NOT NULL,
  hybrid_track_id uuid REFERENCES hybrid_solution_tracks(id) ON DELETE CASCADE,
  session_type text DEFAULT 'live',
  scheduled_start timestamptz NOT NULL,
  scheduled_end timestamptz NOT NULL,
  status text DEFAULT 'scheduled',
  max_participants integer DEFAULT 30,
  current_participants integer DEFAULT 0,
  whiteboard_enabled boolean DEFAULT true,
  chat_enabled boolean DEFAULT true,
  screen_share_enabled boolean DEFAULT true,
  recording_url text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create study materials table
CREATE TABLE IF NOT EXISTS study_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES tutor_sessions(id) ON DELETE CASCADE,
  uploader_id uuid NOT NULL,
  title text NOT NULL,
  description text,
  file_url text NOT NULL,
  file_type text,
  file_size integer,
  material_type text,
  version integer DEFAULT 1,
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create assignments table
CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES tutor_sessions(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  instructions text,
  due_date timestamptz NOT NULL,
  max_score integer DEFAULT 100,
  created_by uuid NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create assignment submissions table
CREATE TABLE IF NOT EXISTS assignment_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id uuid NOT NULL,
  submission_file_url text,
  submission_text text,
  score integer,
  feedback text,
  submitted_at timestamptz,
  graded_at timestamptz,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  UNIQUE(assignment_id, student_id)
);

-- Create session participants table
CREATE TABLE IF NOT EXISTS session_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES tutor_sessions(id) ON DELETE CASCADE,
  participant_id uuid NOT NULL,
  participant_name text,
  role text DEFAULT 'student',
  joined_at timestamptz DEFAULT now(),
  left_at timestamptz,
  status text DEFAULT 'active',
  UNIQUE(session_id, participant_id)
);

-- Create whiteboard snapshots table
CREATE TABLE IF NOT EXISTS whiteboard_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES tutor_sessions(id) ON DELETE CASCADE,
  snapshot_data jsonb,
  created_by uuid NOT NULL,
  snapshot_order integer,
  created_at timestamptz DEFAULT now()
);

-- Create session chat messages table
CREATE TABLE IF NOT EXISTS session_chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES tutor_sessions(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL,
  sender_name text,
  message text NOT NULL,
  message_type text DEFAULT 'text',
  file_url text,
  is_pinned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create material downloads tracking table
CREATE TABLE IF NOT EXISTS material_downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid NOT NULL REFERENCES study_materials(id) ON DELETE CASCADE,
  downloader_id uuid NOT NULL,
  downloaded_at timestamptz DEFAULT now(),
  UNIQUE(material_id, downloader_id)
);

-- Enable RLS
ALTER TABLE tutor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignment_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE whiteboard_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE material_downloads ENABLE ROW LEVEL SECURITY;
