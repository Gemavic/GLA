/*
  # Complete Partially Filled Courses - Part 2

  1. Continue Machine Learning A-Z (Modules 5-8)
  2. Complete remaining Node.js Backend Development modules
  3. Complete remaining UI/UX Design Fundamentals modules

  Focus: Unsupervised Learning, Model Evaluation, Deep Learning, Deployment
*/

-- Continue Machine Learning A-Z
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'machine-learning-a-z';
  
  -- Module 5: Unsupervised Learning
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 5;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'K-Means Clustering', 'Partitioning data into clusters', 
  E'# K-Means Clustering\n\n```python\nfrom sklearn.cluster import KMeans\nimport matplotlib.pyplot as plt\nimport numpy as np\n\n# Sample data\nfrom sklearn.datasets import make_blobs\nX, _ = make_blobs(n_samples=300, centers=4, random_state=42)\n\n# Elbow method to find optimal k\ninertias = []\nK_range = range(1, 11)\nfor k in K_range:\n    kmeans = KMeans(n_clusters=k, random_state=42)\n    kmeans.fit(X)\n    inertias.append(kmeans.inertia_)\n\nplt.plot(K_range, inertias, marker=''o'')\nplt.xlabel(''Number of Clusters'')\nplt.ylabel(''Inertia'')\nplt.title(''Elbow Method'')\nplt.show()\n\n# Fit K-Means\nkmeans = KMeans(n_clusters=4, random_state=42)\nclusters = kmeans.fit_predict(X)\n\n# Visualize\nplt.scatter(X[:, 0], X[:, 1], c=clusters, cmap=''viridis'')\nplt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], \n           marker=''X'', s=200, c=''red'', label=''Centroids'')\nplt.legend()\nplt.show()\n```',
  1, 75, ARRAY['Implement K-Means clustering', 'Find optimal cluster count', 'Visualize clusters']),
  
  (v_course_id, v_module_id, 'Hierarchical Clustering', 'Tree-based clustering', 
  E'# Hierarchical Clustering\n\n```python\nfrom sklearn.cluster import AgglomerativeClustering\nfrom scipy.cluster.hierarchy import dendrogram, linkage\nimport matplotlib.pyplot as plt\n\n# Hierarchical clustering\nhc = AgglomerativeClustering(n_clusters=4, linkage=''ward'')\nclusters = hc.fit_predict(X)\n\n# Visualize clusters\nplt.scatter(X[:, 0], X[:, 1], c=clusters, cmap=''viridis'')\nplt.title(''Hierarchical Clustering'')\nplt.show()\n\n# Dendrogram\nlinked = linkage(X, method=''ward'')\nplt.figure(figsize=(12, 6))\ndendrogram(linked)\nplt.title(''Dendrogram'')\nplt.xlabel(''Sample Index'')\nplt.ylabel(''Distance'')\nplt.show()\n```',
  2, 70, ARRAY['Implement hierarchical clustering', 'Create dendrograms', 'Choose linkage methods']),
  
  (v_course_id, v_module_id, 'Dimensionality Reduction', 'PCA and t-SNE', 
  E'# Dimensionality Reduction\n\n```python\nfrom sklearn.decomposition import PCA\nfrom sklearn.manifold import TSNE\nimport matplotlib.pyplot as plt\n\n# PCA\npca = PCA(n_components=2)\nX_pca = pca.fit_transform(X)\n\n# Explained variance\nprint(''Explained Variance Ratio:'', pca.explained_variance_ratio_)\nprint(''Cumulative Variance:'', pca.explained_variance_ratio_.cumsum())\n\n# Visualize PCA\nplt.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap=''viridis'')\nplt.xlabel(''First Principal Component'')\nplt.ylabel(''Second Principal Component'')\nplt.title(''PCA Visualization'')\nplt.colorbar()\nplt.show()\n\n# t-SNE\ntsne = TSNE(n_components=2, random_state=42)\nX_tsne = tsne.fit_transform(X)\n\nplt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=y, cmap=''viridis'')\nplt.title(''t-SNE Visualization'')\nplt.colorbar()\nplt.show()\n```',
  3, 80, ARRAY['Apply PCA', 'Use t-SNE for visualization', 'Reduce feature dimensionality']);

  -- Module 6: Model Evaluation and Selection
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 6;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Cross-Validation', 'Robust model evaluation', 
  E'# Cross-Validation Techniques\n\n```python\nfrom sklearn.model_selection import cross_val_score, KFold, StratifiedKFold\nfrom sklearn.ensemble import RandomForestClassifier\n\nmodel = RandomForestClassifier(n_estimators=100, random_state=42)\n\n# K-Fold Cross-Validation\nkfold = KFold(n_splits=5, shuffle=True, random_state=42)\nscores = cross_val_score(model, X, y, cv=kfold, scoring=''accuracy'')\nprint(f''Accuracy: {scores.mean():.3f} (+/- {scores.std():.3f})'')\n\n# Stratified K-Fold (for imbalanced datasets)\nskfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)\nscores = cross_val_score(model, X, y, cv=skfold, scoring=''accuracy'')\nprint(f''Stratified Accuracy: {scores.mean():.3f} (+/- {scores.std():.3f})'')\n\n# Multiple metrics\nfrom sklearn.model_selection import cross_validate\nscoring = [''accuracy'', ''precision'', ''recall'', ''f1'']\nscores = cross_validate(model, X, y, cv=5, scoring=scoring)\nfor metric in scoring:\n    print(f''{metric}: {scores[f\"test_{metric}\"].mean():.3f}'')\n```',
  1, 75, ARRAY['Implement cross-validation', 'Use stratified sampling', 'Evaluate multiple metrics']),
  
  (v_course_id, v_module_id, 'Hyperparameter Tuning', 'Grid Search and Random Search', 
  E'# Hyperparameter Optimization\n\n```python\nfrom sklearn.model_selection import GridSearchCV, RandomizedSearchCV\nfrom sklearn.ensemble import RandomForestClassifier\nimport numpy as np\n\n# Grid Search\nparam_grid = {\n    ''n_estimators'': [50, 100, 200],\n    ''max_depth'': [5, 10, 15, None],\n    ''min_samples_split'': [2, 5, 10],\n    ''min_samples_leaf'': [1, 2, 4]\n}\n\nrf = RandomForestClassifier(random_state=42)\ngrid_search = GridSearchCV(\n    rf, param_grid, cv=5, scoring=''accuracy'', n_jobs=-1, verbose=1\n)\ngrid_search.fit(X_train, y_train)\n\nprint(''Best Parameters:'', grid_search.best_params_)\nprint(''Best Score:'', grid_search.best_score_)\n\n# Random Search (faster for large parameter spaces)\nparam_dist = {\n    ''n_estimators'': np.arange(50, 300, 50),\n    ''max_depth'': [None] + list(np.arange(5, 30, 5)),\n    ''min_samples_split'': np.arange(2, 11),\n    ''min_samples_leaf'': np.arange(1, 5)\n}\n\nrandom_search = RandomizedSearchCV(\n    rf, param_dist, n_iter=50, cv=5, random_state=42, n_jobs=-1\n)\nrandom_search.fit(X_train, y_train)\n\nprint(''Best Parameters:'', random_search.best_params_)\nprint(''Best Score:'', random_search.best_score_)\n```',
  2, 85, ARRAY['Tune hyperparameters', 'Use Grid Search', 'Apply Random Search']),
  
  (v_course_id, v_module_id, 'Model Comparison and Selection', 'Choosing the best model', 
  E'# Model Comparison\n\n```python\nfrom sklearn.linear_model import LogisticRegression\nfrom sklearn.tree import DecisionTreeClassifier\nfrom sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier\nfrom sklearn.svm import SVC\nfrom sklearn.model_selection import cross_val_score\nimport pandas as pd\n\nmodels = {\n    ''Logistic Regression'': LogisticRegression(),\n    ''Decision Tree'': DecisionTreeClassifier(),\n    ''Random Forest'': RandomForestClassifier(),\n    ''Gradient Boosting'': GradientBoostingClassifier(),\n    ''SVM'': SVC()\n}\n\nresults = []\nfor name, model in models.items():\n    scores = cross_val_score(model, X, y, cv=5, scoring=''accuracy'')\n    results.append({\n        ''Model'': name,\n        ''Mean Accuracy'': scores.mean(),\n        ''Std Dev'': scores.std()\n    })\n\nresults_df = pd.DataFrame(results)\nresults_df = results_df.sort_values(''Mean Accuracy'', ascending=False)\nprint(results_df)\n\n# Visualize comparison\nimport matplotlib.pyplot as plt\nplt.barh(results_df[''Model''], results_df[''Mean Accuracy''])\nplt.xlabel(''Accuracy'')\nplt.title(''Model Comparison'')\nplt.tight_layout()\nplt.show()\n```',
  3, 70, ARRAY['Compare multiple models', 'Select best performing model', 'Visualize model performance']);

  -- Module 7: Introduction to Deep Learning
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 7;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Neural Networks Basics', 'Understanding neural networks', 
  E'# Neural Network Fundamentals\n\n```python\nfrom sklearn.neural_network import MLPClassifier\nfrom sklearn.preprocessing import StandardScaler\n\n# Scale data\nscaler = StandardScaler()\nX_train_scaled = scaler.fit_transform(X_train)\nX_test_scaled = scaler.transform(X_test)\n\n# Create neural network\nmlp = MLPClassifier(\n    hidden_layer_sizes=(100, 50),  # 2 hidden layers\n    activation=''relu'',\n    solver=''adam'',\n    max_iter=500,\n    random_state=42\n)\n\n# Train\nmlp.fit(X_train_scaled, y_train)\n\n# Evaluate\ntrain_score = mlp.score(X_train_scaled, y_train)\ntest_score = mlp.score(X_test_scaled, y_test)\nprint(f''Training Accuracy: {train_score:.3f}'')\nprint(f''Test Accuracy: {test_score:.3f}'')\n\n# Visualize training loss\nimport matplotlib.pyplot as plt\nplt.plot(mlp.loss_curve_)\nplt.xlabel(''Iteration'')\nplt.ylabel(''Loss'')\nplt.title(''Training Loss Curve'')\nplt.show()\n```',
  1, 90, ARRAY['Build neural networks', 'Train deep learning models', 'Monitor training progress']),
  
  (v_course_id, v_module_id, 'Deep Learning with TensorFlow', 'Introduction to TensorFlow', 
  E'# TensorFlow Basics\n\n```python\nimport tensorflow as tf\nfrom tensorflow import keras\nfrom sklearn.model_selection import train_test_split\n\n# Prepare data\nX_train, X_val, y_train, y_val = train_test_split(\n    X_train_scaled, y_train, test_size=0.2, random_state=42\n)\n\n# Build model\nmodel = keras.Sequential([\n    keras.layers.Dense(64, activation=''relu'', input_shape=(X_train.shape[1],)),\n    keras.layers.Dropout(0.3),\n    keras.layers.Dense(32, activation=''relu''),\n    keras.layers.Dropout(0.3),\n    keras.layers.Dense(1, activation=''sigmoid'')\n])\n\n# Compile\nmodel.compile(\n    optimizer=''adam'',\n    loss=''binary_crossentropy'',\n    metrics=[''accuracy'']\n)\n\n# Train\nhistory = model.fit(\n    X_train, y_train,\n    epochs=50,\n    batch_size=32,\n    validation_data=(X_val, y_val),\n    verbose=1\n)\n\n# Plot training history\nimport matplotlib.pyplot as plt\nplt.plot(history.history[''accuracy''], label=''train'')\nplt.plot(history.history[''val_accuracy''], label=''validation'')\nplt.xlabel(''Epoch'')\nplt.ylabel(''Accuracy'')\nplt.legend()\nplt.show()\n```',
  2, 100, ARRAY['Use TensorFlow', 'Build keras models', 'Train neural networks']);

  -- Module 8: Model Deployment
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 8;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Model Serialization', 'Saving and loading models', 
  E'# Model Persistence\n\n```python\nimport joblib\nimport pickle\nfrom sklearn.ensemble import RandomForestClassifier\n\n# Train model\nmodel = RandomForestClassifier(n_estimators=100)\nmodel.fit(X_train, y_train)\n\n# Save with joblib (recommended for sklearn)\njoblib.dump(model, ''model.joblib'')\n\n# Load model\nloaded_model = joblib.load(''model.joblib'')\n\n# Use loaded model\npredictions = loaded_model.predict(X_test)\n\n# Save with pickle\nwith open(''model.pkl'', ''wb'') as f:\n    pickle.dump(model, f)\n\n# Load with pickle\nwith open(''model.pkl'', ''rb'') as f:\n    loaded_model = pickle.load(f)\n\n# For TensorFlow/Keras\nimport tensorflow as tf\ntf_model = tf.keras.models.Sequential([...])\ntf_model.save(''my_model.h5'')\nloaded_tf_model = tf.keras.models.load_model(''my_model.h5'')\n```',
  1, 60, ARRAY['Save trained models', 'Load models for prediction', 'Choose serialization methods']),
  
  (v_course_id, v_module_id, 'Building ML APIs with Flask', 'Creating prediction APIs', 
  E'# Flask ML API\n\n```python\nfrom flask import Flask, request, jsonify\nimport joblib\nimport numpy as np\n\napp = Flask(__name__)\n\n# Load model at startup\nmodel = joblib.load(''model.joblib'')\nscaler = joblib.load(''scaler.joblib'')\n\n@app.route(''/predict'', methods=[''POST''])\ndef predict():\n    try:\n        # Get data from request\n        data = request.get_json()\n        features = np.array(data[''features'']).reshape(1, -1)\n        \n        # Scale features\n        features_scaled = scaler.transform(features)\n        \n        # Make prediction\n        prediction = model.predict(features_scaled)[0]\n        probability = model.predict_proba(features_scaled)[0].tolist()\n        \n        return jsonify({\n            ''prediction'': int(prediction),\n            ''probability'': probability,\n            ''status'': ''success''\n        })\n    except Exception as e:\n        return jsonify({\n            ''error'': str(e),\n            ''status'': ''error''\n        }), 400\n\n@app.route(''/health'', methods=[''GET''])\ndef health():\n    return jsonify({''status'': ''healthy''})\n\nif __name__ == ''__main__'':\n    app.run(debug=True, host=''0.0.0.0'', port=5000)\n```',
  2, 90, ARRAY['Create ML APIs', 'Deploy models with Flask', 'Handle prediction requests']),
  
  (v_course_id, v_module_id, 'ML Project Best Practices', 'Production-ready ML systems', 
  E'# ML Best Practices\n\n## Project Structure\n\n```\nml_project/\n├── data/\n│   ├── raw/\n│   └── processed/\n├── notebooks/\n│   ├── exploration.ipynb\n│   └── modeling.ipynb\n├── src/\n│   ├── data_preprocessing.py\n│   ├── feature_engineering.py\n│   ├── model_training.py\n│   └── model_evaluation.py\n├── models/\n│   └── trained_model.joblib\n├── tests/\n│   └── test_model.py\n├── api/\n│   └── app.py\n├── requirements.txt\n└── README.md\n```\n\n## Data Versioning\n\n```python\n# Track data versions\nimport hashlib\nimport json\n\ndef get_data_hash(df):\n    return hashlib.md5(pd.util.hash_pandas_object(df).values).hexdigest()\n\ndata_version = {\n    ''hash'': get_data_hash(df),\n    ''rows'': len(df),\n    ''columns'': list(df.columns),\n    ''timestamp'': pd.Timestamp.now().isoformat()\n}\n\nwith open(''data_version.json'', ''w'') as f:\n    json.dump(data_version, f)\n```\n\n## Model Monitoring\n\n```python\nimport logging\n\nlogging.basicConfig(level=logging.INFO)\nlogger = logging.getLogger(__name__)\n\ndef monitor_predictions(y_true, y_pred):\n    accuracy = accuracy_score(y_true, y_pred)\n    logger.info(f''Model Accuracy: {accuracy:.3f}'')\n    \n    if accuracy < 0.7:\n        logger.warning(''Model performance degraded!'')\n```',
  3, 75, ARRAY['Structure ML projects', 'Version data and models', 'Monitor model performance']);

END $$;

-- Complete Node.js Backend Development (Modules 3-6)
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'nodejs-backend-development';
  
  -- Module 3: Database Integration
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 3;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'PostgreSQL with Node.js', 'Relational database integration', 
  E'# PostgreSQL Integration\n\n```javascript\nconst { Pool } = require(''pg'');\n\nconst pool = new Pool({\n  host: ''localhost'',\n  port: 5432,\n  database: ''mydb'',\n  user: ''postgres'',\n  password: ''password''\n});\n\n// Query\nasync function getUsers() {\n  const result = await pool.query(''SELECT * FROM users'');\n  return result.rows;\n}\n\n// Parameterized query\nasync function getUserById(id) {\n  const result = await pool.query(\n    ''SELECT * FROM users WHERE id = $1'',\n    [id]\n  );\n  return result.rows[0];\n}\n\n// Transaction\nasync function createOrderWithItems(order, items) {\n  const client = await pool.connect();\n  try {\n    await client.query(''BEGIN'');\n    \n    const orderResult = await client.query(\n      ''INSERT INTO orders (user_id, total) VALUES ($1, $2) RETURNING id'',\n      [order.userId, order.total]\n    );\n    \n    const orderId = orderResult.rows[0].id;\n    \n    for (const item of items) {\n      await client.query(\n        ''INSERT INTO order_items (order_id, product_id, quantity) VALUES ($1, $2, $3)'',\n        [orderId, item.productId, item.quantity]\n      );\n    }\n    \n    await client.query(''COMMIT'');\n    return orderId;\n  } catch (e) {\n    await client.query(''ROLLBACK'');\n    throw e;\n  } finally {\n    client.release();\n  }\n}\n```',
  1, 85, ARRAY['Connect to PostgreSQL', 'Execute parameterized queries', 'Handle database transactions']),
  
  (v_course_id, v_module_id, 'MongoDB with Node.js', 'NoSQL database operations', 
  E'# MongoDB Integration\n\n```javascript\nconst { MongoClient } = require(''mongodb'');\n\nconst client = new MongoClient(''mongodb://localhost:27017'');\n\nasync function main() {\n  await client.connect();\n  const db = client.db(''myapp'');\n  const users = db.collection(''users'');\n  \n  // Create\n  await users.insertOne({\n    name: ''Alice'',\n    email: ''alice@example.com'',\n    createdAt: new Date()\n  });\n  \n  // Read\n  const user = await users.findOne({ email: ''alice@example.com'' });\n  const allUsers = await users.find().toArray();\n  \n  // Update\n  await users.updateOne(\n    { email: ''alice@example.com'' },\n    { $set: { name: ''Alice Smith'' } }\n  );\n  \n  // Delete\n  await users.deleteOne({ email: ''alice@example.com'' });\n  \n  // Aggregation\n  const stats = await users.aggregate([\n    { $group: { _id: ''$country'', count: { $sum: 1 } } },\n    { $sort: { count: -1 } }\n  ]).toArray();\n}\n```',
  2, 80, ARRAY['Work with MongoDB', 'Perform CRUD operations', 'Use aggregation pipelines']);

END $$;
