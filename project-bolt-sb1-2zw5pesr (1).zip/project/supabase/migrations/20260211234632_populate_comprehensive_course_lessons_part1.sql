/*
  # Comprehensive Course Lessons - Part 1

  1. Courses Covered
    - Python for Data Science (remaining modules)
    - Node.js Backend Development
    - React Advanced
    - UI/UX Design Fundamentals
    - Digital Marketing Mastery

  2. Content Details
    - Complete lesson content for all modules
    - Learning objectives for each lesson
    - Code examples and practical exercises
*/

-- Python for Data Science (Modules 2-6)
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'python-for-data-science';
  
  -- Module 2: NumPy
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'NumPy Arrays', 'Creating and manipulating arrays', 
  E'# NumPy Arrays\n\n```python\nimport numpy as np\n\n# Creating arrays\narr1 = np.array([1, 2, 3, 4, 5])\narr2 = np.zeros((3, 4))  # 3x4 array of zeros\narr3 = np.ones((2, 3))   # 2x3 array of ones\narr4 = np.arange(0, 10, 2)  # [0, 2, 4, 6, 8]\narr5 = np.linspace(0, 1, 5)  # 5 equally spaced values\n\n# Array properties\nprint(arr1.shape)  # (5,)\nprint(arr1.dtype)  # int64\nprint(arr1.ndim)   # 1\nprint(arr1.size)   # 5\n```',
  1, 75, ARRAY['Create NumPy arrays', 'Understand array properties', 'Use array creation functions']),
  
  (v_course_id, v_module_id, 'Array Operations', 'Mathematical operations on arrays', 
  E'# Array Operations\n\n```python\nimport numpy as np\n\narr = np.array([1, 2, 3, 4, 5])\n\n# Arithmetic operations\nprint(arr + 10)  # Add 10 to each element\nprint(arr * 2)   # Multiply each by 2\nprint(arr ** 2)  # Square each element\n\n# Statistical operations\nprint(np.mean(arr))    # Average\nprint(np.median(arr))  # Median\nprint(np.std(arr))     # Standard deviation\nprint(np.sum(arr))     # Sum\nprint(np.min(arr))     # Minimum\nprint(np.max(arr))     # Maximum\n\n# Array operations\na = np.array([1, 2, 3])\nb = np.array([4, 5, 6])\nprint(a + b)  # [5, 7, 9]\nprint(a * b)  # [4, 10, 18]\nprint(np.dot(a, b))  # Dot product\n```',
  2, 70, ARRAY['Perform array arithmetic', 'Calculate statistics', 'Apply vectorized operations']),
  
  (v_course_id, v_module_id, 'Array Indexing and Slicing', 'Accessing array elements', 
  E'# Indexing and Slicing\n\n```python\nimport numpy as np\n\narr = np.array([10, 20, 30, 40, 50])\n\n# Indexing\nprint(arr[0])   # 10\nprint(arr[-1])  # 50\n\n# Slicing\nprint(arr[1:4])  # [20, 30, 40]\nprint(arr[:3])   # [10, 20, 30]\nprint(arr[::2])  # [10, 30, 50]\n\n# 2D arrays\narr2d = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])\nprint(arr2d[0, 1])  # 2\nprint(arr2d[1, :])  # [4, 5, 6]\nprint(arr2d[:, 1])  # [2, 5, 8]\n\n# Boolean indexing\nmask = arr > 25\nprint(arr[mask])  # [30, 40, 50]\n```',
  3, 65, ARRAY['Index arrays efficiently', 'Slice multi-dimensional arrays', 'Use boolean indexing']);

  -- Module 3: Pandas
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 3;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'DataFrames Basics', 'Working with tabular data', 
  E'# Pandas DataFrames\n\n```python\nimport pandas as pd\n\n# Creating DataFrames\ndf = pd.DataFrame({\n    ''name'': [''Alice'', ''Bob'', ''Charlie''],\n    ''age'': [25, 30, 35],\n    ''city'': [''NYC'', ''LA'', ''Chicago'']\n})\n\n# Basic info\nprint(df.head())  # First 5 rows\nprint(df.info())  # DataFrame info\nprint(df.describe())  # Statistics\n\n# Accessing data\nprint(df[''name''])  # Column\nprint(df.iloc[0])   # First row\nprint(df.loc[0, ''name''])  # Specific value\n```',
  1, 85, ARRAY['Create and manipulate DataFrames', 'Access DataFrame data', 'Get DataFrame information']),
  
  (v_course_id, v_module_id, 'Data Cleaning', 'Handling missing data and duplicates', 
  E'# Data Cleaning\n\n```python\nimport pandas as pd\nimport numpy as np\n\ndf = pd.DataFrame({\n    ''A'': [1, 2, np.nan, 4],\n    ''B'': [5, np.nan, 7, 8],\n    ''C'': [9, 10, 11, 12]\n})\n\n# Missing data\nprint(df.isnull())  # Check for nulls\nprint(df.dropna())  # Remove rows with nulls\nprint(df.fillna(0))  # Fill nulls with 0\nprint(df.fillna(df.mean()))  # Fill with mean\n\n# Duplicates\ndf_dup = pd.DataFrame({''A'': [1, 1, 2], ''B'': [1, 1, 2]})\nprint(df_dup.duplicated())  # Check duplicates\nprint(df_dup.drop_duplicates())  # Remove duplicates\n```',
  2, 90, ARRAY['Handle missing data', 'Remove duplicates', 'Clean data effectively']);

END $$;

-- Node.js Backend Development
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'nodejs-backend-development';
  
  -- Module 1: Node.js Fundamentals
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Node.js Core Concepts', 'Understanding the event loop and modules', 
  E'# Node.js Core Concepts\n\n## Event Loop\n\nNode.js is single-threaded but handles concurrency through the event loop.\n\n```javascript\nconsole.log(''Start'');\n\nsetTimeout(() => {\n  console.log(''Timeout'');\n}, 0);\n\nPromise.resolve().then(() => {\n  console.log(''Promise'');\n});\n\nconsole.log(''End'');\n// Output: Start, End, Promise, Timeout\n```\n\n## Modules\n\n```javascript\n// math.js\nfunction add(a, b) {\n  return a + b;\n}\n\nmodule.exports = { add };\n\n// app.js\nconst { add } = require(''./math'');\nconsole.log(add(2, 3));\n```',
  1, 70, ARRAY['Understand event loop', 'Work with modules', 'Grasp Node.js architecture']),
  
  (v_course_id, v_module_id, 'Asynchronous Programming', 'Callbacks, Promises, and Async/Await', 
  E'# Asynchronous Programming\n\n## Callbacks\n\n```javascript\nconst fs = require(''fs'');\n\nfs.readFile(''file.txt'', ''utf8'', (err, data) => {\n  if (err) {\n    console.error(err);\n    return;\n  }\n  console.log(data);\n});\n```\n\n## Promises\n\n```javascript\nconst fs = require(''fs'').promises;\n\nfs.readFile(''file.txt'', ''utf8'')\n  .then(data => console.log(data))\n  .catch(err => console.error(err));\n```\n\n## Async/Await\n\n```javascript\nasync function readFile() {\n  try {\n    const data = await fs.readFile(''file.txt'', ''utf8'');\n    console.log(data);\n  } catch (err) {\n    console.error(err);\n  }\n}\n```',
  2, 80, ARRAY['Use callbacks effectively', 'Work with Promises', 'Implement async/await patterns']);

  -- Module 2: Express.js
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Express Fundamentals', 'Building web applications with Express', 
  E'# Express.js Basics\n\n## Setup\n\n```javascript\nconst express = require(''express'');\nconst app = express();\n\napp.use(express.json());\napp.use(express.urlencoded({ extended: true }));\n\n// Routes\napp.get(''/'', (req, res) => {\n  res.send(''Hello World'');\n});\n\napp.get(''/api/users/:id'', (req, res) => {\n  const { id } = req.params;\n  res.json({ id, name: ''User'' });\n});\n\napp.post(''/api/users'', (req, res) => {\n  const user = req.body;\n  res.status(201).json(user);\n});\n\napp.listen(3000, () => {\n  console.log(''Server running on port 3000'');\n});\n```',
  1, 85, ARRAY['Create Express applications', 'Define routes', 'Handle requests and responses']),
  
  (v_course_id, v_module_id, 'Middleware and Routing', 'Advanced Express patterns', 
  E'# Middleware and Routing\n\n## Custom Middleware\n\n```javascript\n// Logging middleware\napp.use((req, res, next) => {\n  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);\n  next();\n});\n\n// Authentication middleware\nfunction authenticate(req, res, next) {\n  const token = req.headers.authorization;\n  if (!token) {\n    return res.status(401).json({ error: ''Unauthorized'' });\n  }\n  next();\n}\n\n// Use middleware on specific routes\napp.get(''/protected'', authenticate, (req, res) => {\n  res.json({ message: ''Protected resource'' });\n});\n```\n\n## Router\n\n```javascript\nconst userRouter = express.Router();\n\nuserRouter.get(''/'', (req, res) => {\n  res.json([{ id: 1, name: ''Alice'' }]);\n});\n\nuserRouter.get(''/:id'', (req, res) => {\n  res.json({ id: req.params.id });\n});\n\napp.use(''/api/users'', userRouter);\n```',
  2, 90, ARRAY['Create custom middleware', 'Use Express Router', 'Organize application structure']);

END $$;

-- UI/UX Design Fundamentals
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'ui-ux-design-fundamentals';
  
  -- Module 1: Design Thinking
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Introduction to Design Thinking', 'Understanding the design process', 
  E'# Design Thinking Process\n\n## Five Stages\n\n1. **Empathize**: Understand user needs\n2. **Define**: Frame the problem\n3. **Ideate**: Generate solutions\n4. **Prototype**: Build representations\n5. **Test**: Gather feedback\n\n## Empathy Mapping\n\nCreate user empathy maps with four quadrants:\n- **Says**: Direct quotes from users\n- **Thinks**: What users think\n- **Does**: User actions\n- **Feels**: Emotional states\n\n## User Research Methods\n\n- Interviews\n- Surveys\n- Observations\n- Usability testing\n- A/B testing',
  1, 75, ARRAY['Understand design thinking', 'Create empathy maps', 'Conduct user research']),
  
  (v_course_id, v_module_id, 'User Personas', 'Creating representative user profiles', 
  E'# Creating User Personas\n\n## What are Personas?\n\nUser personas are fictional characters representing user segments.\n\n## Persona Components\n\n1. **Demographics**: Age, location, occupation\n2. **Goals**: What they want to achieve\n3. **Pain Points**: Current frustrations\n4. **Behaviors**: How they interact\n5. **Motivations**: Why they use the product\n\n## Example Persona\n\n**Name**: Sarah, The Busy Professional\n- **Age**: 32\n- **Occupation**: Marketing Manager\n- **Goals**: Save time, stay organized\n- **Pain Points**: Too many tools, complex interfaces\n- **Quote**: "I need solutions that just work"',
  2, 70, ARRAY['Create user personas', 'Identify user goals', 'Understand user pain points']),
  
  (v_course_id, v_module_id, 'User Journey Mapping', 'Visualizing user experiences', 
  E'# User Journey Mapping\n\n## Components\n\n1. **Stages**: Steps in the journey\n2. **Actions**: What users do\n3. **Thoughts**: What users think\n4. **Emotions**: How users feel\n5. **Pain Points**: Where frustration occurs\n6. **Opportunities**: Improvement areas\n\n## Example Journey\n\n**Stage 1: Discovery**\n- Action: User searches for solution\n- Thought: "I need help with X"\n- Emotion: Hopeful\n- Pain Point: Too many options\n- Opportunity: Clearer value proposition\n\n**Stage 2: Evaluation**\n- Action: Compares products\n- Thought: "Which is best for me?"\n- Emotion: Confused\n- Pain Point: Unclear differences\n- Opportunity: Comparison guide',
  3, 80, ARRAY['Create journey maps', 'Identify touchpoints', 'Find improvement opportunities']);

  -- Module 2: Information Architecture
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Organizing Content', 'Structuring information effectively', 
  E'# Information Architecture\n\n## IA Principles\n\n1. **Organization**: Group related content\n2. **Labeling**: Clear, descriptive names\n3. **Navigation**: Easy to find content\n4. **Search**: Quick access to information\n\n## Content Organization Methods\n\n### Hierarchical\n```\nHome\n├── Products\n│   ├── Category A\n│   └── Category B\n├── About\n└── Contact\n```\n\n### Sequential\nStep 1 → Step 2 → Step 3 → Complete\n\n### Matrix\nUsers choose their own path based on multiple filters',
  1, 65, ARRAY['Organize content logically', 'Create site structures', 'Apply IA principles']),
  
  (v_course_id, v_module_id, 'Sitemaps and Navigation', 'Planning site structure', 
  E'# Sitemaps and Navigation\n\n## Creating Sitemaps\n\nVisual representation of site structure:\n\n```\nHomepage (Level 1)\n├── Products (Level 2)\n│   ├── Category A (Level 3)\n│   ├── Category B (Level 3)\n│   └── All Products (Level 3)\n├── About (Level 2)\n│   ├── Team (Level 3)\n│   └── Careers (Level 3)\n└── Contact (Level 2)\n```\n\n## Navigation Patterns\n\n1. **Top Navigation**: Horizontal menu\n2. **Sidebar**: Vertical menu\n3. **Hamburger**: Mobile menu\n4. **Breadcrumbs**: Show location\n5. **Footer**: Secondary links\n\n## Best Practices\n\n- Limit main nav to 5-7 items\n- Use clear labels\n- Maintain consistency\n- Show current location',
  2, 70, ARRAY['Create sitemaps', 'Design navigation systems', 'Apply navigation best practices']);

END $$;

-- Digital Marketing Mastery
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'digital-marketing-mastery';
  
  -- Module 1: Digital Marketing Foundations
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Digital Marketing Overview', 'Understanding the digital landscape', 
  E'# Digital Marketing Fundamentals\n\n## Key Channels\n\n1. **Search Engine Marketing (SEM)**\n   - SEO (Organic)\n   - PPC (Paid)\n\n2. **Social Media Marketing**\n   - Organic posts\n   - Paid advertising\n\n3. **Content Marketing**\n   - Blog posts\n   - Videos\n   - Podcasts\n\n4. **Email Marketing**\n   - Newsletters\n   - Automated campaigns\n\n5. **Affiliate Marketing**\n   - Partner programs\n\n## Marketing Funnel\n\n1. Awareness\n2. Interest\n3. Consideration\n4. Conversion\n5. Loyalty',
  1, 60, ARRAY['Understand digital marketing channels', 'Know the marketing funnel', 'Identify target audiences']),
  
  (v_course_id, v_module_id, 'Setting Marketing Goals', 'SMART goals and KPIs', 
  E'# Marketing Goals and KPIs\n\n## SMART Goals\n\n- **S**pecific: Clear and well-defined\n- **M**easurable: Quantifiable metrics\n- **A**chievable: Realistic targets\n- **R**elevant: Aligned with business\n- **T**ime-bound: Deadline attached\n\n## Example SMART Goal\n\n"Increase website traffic by 50% in 6 months through SEO and content marketing"\n\n## Key Performance Indicators (KPIs)\n\n### Traffic Metrics\n- Unique visitors\n- Page views\n- Bounce rate\n- Time on site\n\n### Conversion Metrics\n- Conversion rate\n- Cost per acquisition\n- ROI\n- Customer lifetime value',
  2, 55, ARRAY['Set SMART marketing goals', 'Define KPIs', 'Measure marketing success']);

END $$;
