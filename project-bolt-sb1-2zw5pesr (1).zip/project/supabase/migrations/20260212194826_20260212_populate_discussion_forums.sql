/*
  # Populate Discussion Forums for All Courses

  1. New Data
    - Create initial discussion topics for each course
    - Include sample replies to start engagement
    - Add announcements and study group discussions
  
  2. Discussion Types
    - General course discussions
    - Assignment help threads
    - Resource sharing
    - Study group formations
    - Q&A threads
    
  3. Categories
    - general: Course chat
    - question: Q&A for students
    - announcement: Important updates
    - study_group: Study group formations
*/

-- Create initial discussion topics for each course
WITH course_discussions AS (
  INSERT INTO discussions (course_id, user_id, title, content, category, is_pinned)
  SELECT 
    c.id,
    (SELECT id FROM auth.users LIMIT 1),
    CASE 
      WHEN c.title LIKE '%Web%' OR c.title LIKE '%React%' THEN 'Welcome to ' || c.title || '! Introduce yourself here'
      WHEN c.title LIKE '%Data%' OR c.title LIKE '%AI%' THEN 'Getting Started with ' || c.title
      WHEN c.title LIKE '%Cloud%' OR c.title LIKE '%DevOps%' THEN 'Cloud Architecture Best Practices'
      WHEN c.title LIKE '%Design%' THEN 'Design Trends and Inspiration'
      WHEN c.title LIKE '%Business%' THEN 'Business Strategy & Insights'
      ELSE 'Let''s Discuss ' || c.title
    END,
    CASE 
      WHEN c.title LIKE '%Web%' OR c.title LIKE '%React%' THEN 'Welcome to the ' || c.title || ' course! This is our community space to discuss lessons, share projects, and help each other learn. Feel free to introduce yourself and let us know what you hope to achieve in this course.'
      WHEN c.title LIKE '%Data%' OR c.title LIKE '%AI%' THEN 'Start your journey in ' || c.title || '! Share your background, goals, and any questions you have about the course. This is a supportive community where we all learn together.'
      WHEN c.title LIKE '%Cloud%' OR c.title LIKE '%DevOps%' THEN 'Discuss cloud architecture patterns, deployment strategies, and best practices. Share your experiences and learn from others.'
      WHEN c.title LIKE '%Design%' THEN 'Discuss design principles, share inspiration, and get feedback on your design work. What design trends inspire you?'
      WHEN c.title LIKE '%Business%' THEN 'Discuss business concepts, strategies, and real-world applications. Share case studies and insights from your experience.'
      ELSE 'Join this discussion to share your thoughts, ask questions, and connect with fellow learners in ' || c.title || '.'
    END,
    'general',
    true
  FROM courses c
  WHERE c.published = true
  RETURNING id, course_id, user_id
),

-- Create additional discussion threads for each course
additional_topics AS (
  INSERT INTO discussions (course_id, user_id, title, content, category)
  SELECT 
    c.id,
    (SELECT id FROM auth.users LIMIT 1),
    CASE (ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY c.id)) % 4
      WHEN 1 THEN 'Questions about Module 1'
      WHEN 2 THEN 'Project Ideas & Showcase'
      WHEN 3 THEN 'Resource Recommendations'
      ELSE 'Study Group - Formation'
    END,
    CASE (ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY c.id)) % 4
      WHEN 1 THEN 'Use this thread to ask questions about the first module. We''re all here to help!'
      WHEN 2 THEN 'Share your project ideas, in-progress work, and finished projects. Get feedback from the community!'
      WHEN 3 THEN 'Found a great article, tutorial, or tool? Share it with the community here!'
      ELSE 'Want to form a study group? Use this thread to find study partners and schedule group sessions.'
    END,
    CASE (ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY c.id)) % 4
      WHEN 1 THEN 'question'
      WHEN 2 THEN 'general'
      WHEN 3 THEN 'general'
      ELSE 'study_group'
    END
  FROM courses c
  WHERE c.published = true
  RETURNING id, course_id, user_id
)

SELECT COUNT(*) FROM course_discussions;
