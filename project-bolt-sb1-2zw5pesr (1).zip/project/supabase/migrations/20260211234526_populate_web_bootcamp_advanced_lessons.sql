/*
  # Complete Web Development Bootcamp - Advanced Module Lessons

  1. Content Coverage
    - JavaScript Fundamentals (Module 3)
    - Advanced JavaScript (Module 4)
    - Frontend Frameworks (Module 5)
    - Backend Development (Module 6)
    - Databases (Module 7)
    - Full Stack Projects (Module 8)

  2. Lesson Details
    - Comprehensive content with code examples
    - Learning objectives for each lesson
    - Progressive difficulty
    - Practical exercises included
*/

DO $$
DECLARE
  v_course_id uuid;
  v_module3_id uuid;
  v_module4_id uuid;
  v_module5_id uuid;
  v_module6_id uuid;
  v_module7_id uuid;
  v_module8_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'complete-web-development-bootcamp';
  
  -- Get module IDs
  SELECT id INTO v_module3_id FROM course_modules WHERE course_id = v_course_id AND order_index = 3;
  SELECT id INTO v_module4_id FROM course_modules WHERE course_id = v_course_id AND order_index = 4;
  SELECT id INTO v_module5_id FROM course_modules WHERE course_id = v_course_id AND order_index = 5;
  SELECT id INTO v_module6_id FROM course_modules WHERE course_id = v_course_id AND order_index = 6;
  SELECT id INTO v_module7_id FROM course_modules WHERE course_id = v_course_id AND order_index = 7;
  SELECT id INTO v_module8_id FROM course_modules WHERE course_id = v_course_id AND order_index = 8;

  -- Module 3: JavaScript Fundamentals
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module3_id, 'JavaScript Basics', 'Variables, data types, and operators', 
  E'# JavaScript Basics\n\n## Introduction to JavaScript\n\nJavaScript brings interactivity to web pages.\n\n```javascript\n// Variables\nlet name = "Alice";\nconst age = 25;\nvar city = "NYC";\n\n// Data Types\nlet number = 42;\nlet string = "Hello";\nlet boolean = true;\nlet array = [1, 2, 3];\nlet object = { key: "value" };\nlet nothing = null;\nlet notDefined = undefined;\n\n// Operators\nlet sum = 10 + 5;\nlet product = 10 * 5;\nlet comparison = 10 > 5;\nlet logical = true && false;\n```\n\n## Console and Debugging\n\n```javascript\nconsole.log("Hello World");\nconsole.error("Error message");\nconsole.warn("Warning");\nconsole.table([{name: "Alice", age: 25}]);\n```',
  1, 60, ARRAY['Understand JavaScript syntax', 'Work with variables and data types', 'Use operators and console methods']),
  
  (v_course_id, v_module3_id, 'DOM Manipulation', 'Selecting and modifying HTML elements', 
  E'# DOM Manipulation\n\n## Selecting Elements\n\n```javascript\n// By ID\nconst header = document.getElementById("header");\n\n// By Class\nconst items = document.getElementsByClassName("item");\n\n// By Tag\nconst paragraphs = document.getElementsByTagName("p");\n\n// Query Selector\nconst first = document.querySelector(".item");\nconst all = document.querySelectorAll(".item");\n```\n\n## Modifying Content\n\n```javascript\n// Text Content\nelement.textContent = "New text";\nelement.innerHTML = "<strong>Bold text</strong>";\n\n// Attributes\nelement.setAttribute("class", "active");\nelement.getAttribute("id");\nelement.removeAttribute("disabled");\n\n// Styles\nelement.style.color = "blue";\nelement.style.backgroundColor = "yellow";\n\n// Classes\nelement.classList.add("active");\nelement.classList.remove("hidden");\nelement.classList.toggle("open");\n```',
  2, 75, ARRAY['Select DOM elements', 'Modify element content and attributes', 'Manipulate CSS classes and styles']),
  
  (v_course_id, v_module3_id, 'Event Handling', 'Responding to user interactions', 
  E'# Event Handling\n\n## Adding Event Listeners\n\n```javascript\nconst button = document.querySelector("button");\n\n// Click event\nbutton.addEventListener("click", function() {\n  console.log("Button clicked!");\n});\n\n// Multiple event types\nelement.addEventListener("mouseover", handleHover);\nelement.addEventListener("mouseout", handleLeave);\nelement.addEventListener("keydown", handleKeyPress);\n\n// Event object\nbutton.addEventListener("click", function(event) {\n  console.log(event.target);\n  console.log(event.type);\n  event.preventDefault();\n});\n```\n\n## Form Events\n\n```javascript\nconst form = document.querySelector("form");\n\nform.addEventListener("submit", function(e) {\n  e.preventDefault();\n  const formData = new FormData(form);\n  console.log(Object.fromEntries(formData));\n});\n```',
  3, 70, ARRAY['Add event listeners', 'Handle user interactions', 'Work with event objects']),
  
  (v_course_id, v_module3_id, 'Arrays and Objects', 'Working with complex data structures', 
  E'# Arrays and Objects\n\n## Array Methods\n\n```javascript\nconst numbers = [1, 2, 3, 4, 5];\n\n// Map - transform elements\nconst doubled = numbers.map(n => n * 2);\n\n// Filter - select elements\nconst evens = numbers.filter(n => n % 2 === 0);\n\n// Reduce - combine elements\nconst sum = numbers.reduce((acc, n) => acc + n, 0);\n\n// Find\nconst found = numbers.find(n => n > 3);\n\n// Some and Every\nconst hasEven = numbers.some(n => n % 2 === 0);\nconst allPositive = numbers.every(n => n > 0);\n```\n\n## Object Manipulation\n\n```javascript\nconst person = {\n  name: "Alice",\n  age: 25,\n  greet() {\n    console.log(`Hello, I''m ${this.name}`);\n  }\n};\n\n// Destructuring\nconst { name, age } = person;\n\n// Spread operator\nconst updated = { ...person, city: "NYC" };\n\n// Object methods\nObject.keys(person);\nObject.values(person);\nObject.entries(person);\n```',
  4, 80, ARRAY['Use array methods effectively', 'Manipulate objects', 'Apply destructuring and spread operator']),
  
  (v_course_id, v_module3_id, 'Async JavaScript', 'Promises and async/await', 
  E'# Asynchronous JavaScript\n\n## Fetch API\n\n```javascript\n// GET request\nfetch("https://api.example.com/data")\n  .then(response => response.json())\n  .then(data => console.log(data))\n  .catch(error => console.error(error));\n\n// POST request\nfetch("https://api.example.com/data", {\n  method: "POST",\n  headers: {\n    "Content-Type": "application/json"\n  },\n  body: JSON.stringify({ name: "Alice" })\n});\n```\n\n## Async/Await\n\n```javascript\nasync function fetchData() {\n  try {\n    const response = await fetch("https://api.example.com/data");\n    const data = await response.json();\n    return data;\n  } catch (error) {\n    console.error("Error:", error);\n  }\n}\n\n// Using the function\nfetchData().then(data => console.log(data));\n```',
  5, 85, ARRAY['Work with Promises', 'Use async/await syntax', 'Handle API requests']);

  -- Module 4: Advanced JavaScript
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module4_id, 'ES6+ Features', 'Modern JavaScript syntax', 
  E'# ES6+ Modern JavaScript\n\n## Arrow Functions\n\n```javascript\n// Traditional\nfunction add(a, b) {\n  return a + b;\n}\n\n// Arrow function\nconst add = (a, b) => a + b;\nconst square = n => n * n;\nconst greet = () => console.log("Hello");\n```\n\n## Template Literals\n\n```javascript\nconst name = "Alice";\nconst age = 25;\nconst message = `Hello, I''m ${name} and I''m ${age} years old`;\n\nconst html = `\n  <div>\n    <h1>${name}</h1>\n    <p>Age: ${age}</p>\n  </div>\n`;\n```\n\n## Destructuring\n\n```javascript\n// Array destructuring\nconst [first, second, ...rest] = [1, 2, 3, 4, 5];\n\n// Object destructuring\nconst { name, age, city = "NYC" } = person;\n\n// Function parameters\nfunction greet({ name, age }) {\n  console.log(`${name} is ${age}`);\n}\n```',
  1, 75, ARRAY['Use ES6+ syntax features', 'Write concise arrow functions', 'Apply destructuring patterns']),
  
  (v_course_id, v_module4_id, 'Modules and Imports', 'Organizing code with modules', 
  E'# JavaScript Modules\n\n## Exporting\n\n```javascript\n// utils.js\nexport const add = (a, b) => a + b;\nexport const multiply = (a, b) => a * b;\n\nexport default function calculate() {\n  // ...\n}\n\n// Or export at end\nconst PI = 3.14159;\nexport { PI };\n```\n\n## Importing\n\n```javascript\n// Import default\nimport calculate from "./utils.js";\n\n// Import named exports\nimport { add, multiply } from "./utils.js";\n\n// Import all\nimport * as utils from "./utils.js";\n\n// Import and rename\nimport { add as sum } from "./utils.js";\n```',
  2, 60, ARRAY['Create and export modules', 'Import module functionality', 'Organize code effectively']),
  
  (v_course_id, v_module4_id, 'Object-Oriented JavaScript', 'Classes and prototypes', 
  E'# Object-Oriented Programming\n\n## Classes\n\n```javascript\nclass Person {\n  constructor(name, age) {\n    this.name = name;\n    this.age = age;\n  }\n\n  greet() {\n    return `Hello, I''m ${this.name}`;\n  }\n\n  get birthYear() {\n    return new Date().getFullYear() - this.age;\n  }\n}\n\nconst alice = new Person("Alice", 25);\n```\n\n## Inheritance\n\n```javascript\nclass Student extends Person {\n  constructor(name, age, major) {\n    super(name, age);\n    this.major = major;\n  }\n\n  study() {\n    return `${this.name} is studying ${this.major}`;\n  }\n}\n```',
  3, 80, ARRAY['Create classes and objects', 'Implement inheritance', 'Use getters and setters']),
  
  (v_course_id, v_module4_id, 'Error Handling', 'Managing errors gracefully', 
  E'# Error Handling\n\n## Try-Catch\n\n```javascript\ntry {\n  const data = JSON.parse(jsonString);\n  processData(data);\n} catch (error) {\n  console.error("Error:", error.message);\n} finally {\n  cleanup();\n}\n```\n\n## Custom Errors\n\n```javascript\nclass ValidationError extends Error {\n  constructor(message) {\n    super(message);\n    this.name = "ValidationError";\n  }\n}\n\nfunction validateAge(age) {\n  if (age < 0) {\n    throw new ValidationError("Age cannot be negative");\n  }\n}\n```',
  4, 65, ARRAY['Handle errors with try-catch', 'Create custom error types', 'Implement error recovery strategies']);

  -- Module 5: Frontend Frameworks (React focus)
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module5_id, 'Introduction to React', 'React fundamentals and setup', 
  E'# Introduction to React\n\n## What is React?\n\nReact is a JavaScript library for building user interfaces.\n\n## Creating a React App\n\n```bash\nnpx create-react-app my-app\ncd my-app\nnpm start\n```\n\n## First Component\n\n```jsx\nfunction Welcome() {\n  return <h1>Hello, React!</h1>;\n}\n\nexport default Welcome;\n```\n\n## JSX Basics\n\n```jsx\nfunction App() {\n  const name = "Alice";\n  const isLoggedIn = true;\n\n  return (\n    <div className="app">\n      <h1>Hello, {name}!</h1>\n      {isLoggedIn && <p>Welcome back!</p>}\n      <button onClick={() => console.log("Clicked!")}>Click Me</button>\n    </div>\n  );\n}\n```',
  1, 90, ARRAY['Understand React concepts', 'Create React components', 'Use JSX syntax']),
  
  (v_course_id, v_module5_id, 'React State and Props', 'Managing component data', 
  E'# State and Props\n\n## Props\n\n```jsx\nfunction Greeting({ name, age }) {\n  return <h1>Hello, {name}! You are {age} years old.</h1>;\n}\n\n// Usage\n<Greeting name="Alice" age={25} />\n```\n\n## State with useState\n\n```jsx\nimport { useState } from "react";\n\nfunction Counter() {\n  const [count, setCount] = useState(0);\n\n  return (\n    <div>\n      <p>Count: {count}</p>\n      <button onClick={() => setCount(count + 1)}>Increment</button>\n      <button onClick={() => setCount(count - 1)}>Decrement</button>\n      <button onClick={() => setCount(0)}>Reset</button>\n    </div>\n  );\n}\n```',
  2, 85, ARRAY['Pass props to components', 'Use useState hook', 'Manage component state']),
  
  (v_course_id, v_module5_id, 'React Effects and Lifecycle', 'Side effects and data fetching', 
  E'# useEffect Hook\n\n## Basic Usage\n\n```jsx\nimport { useState, useEffect } from "react";\n\nfunction DataFetcher() {\n  const [data, setData] = useState(null);\n  const [loading, setLoading] = useState(true);\n\n  useEffect(() => {\n    fetch("https://api.example.com/data")\n      .then(res => res.json())\n      .then(data => {\n        setData(data);\n        setLoading(false);\n      });\n  }, []); // Empty array = run once\n\n  if (loading) return <p>Loading...</p>;\n  return <div>{JSON.stringify(data)}</div>;\n}\n```\n\n## Cleanup\n\n```jsx\nuseEffect(() => {\n  const timer = setInterval(() => {\n    console.log("Tick");\n  }, 1000);\n\n  return () => clearInterval(timer);\n}, []);\n```',
  3, 80, ARRAY['Use useEffect for side effects', 'Fetch data in components', 'Implement cleanup functions']),
  
  (v_course_id, v_module5_id, 'Building React Applications', 'Complete React projects', 
  E'# Building with React\n\n## Project Structure\n\n```\nsrc/\n├── components/\n│   ├── Header.jsx\n│   ├── Footer.jsx\n│   └── Card.jsx\n├── pages/\n│   ├── Home.jsx\n│   └── About.jsx\n├── App.jsx\n└── index.jsx\n```\n\n## Complete Example\n\n```jsx\nimport { useState, useEffect } from "react";\n\nfunction TodoApp() {\n  const [todos, setTodos] = useState([]);\n  const [input, setInput] = useState("");\n\n  const addTodo = () => {\n    if (input.trim()) {\n      setTodos([...todos, { id: Date.now(), text: input, done: false }]);\n      setInput("");\n    }\n  };\n\n  const toggleTodo = (id) => {\n    setTodos(todos.map(todo =>\n      todo.id === id ? { ...todo, done: !todo.done } : todo\n    ));\n  };\n\n  return (\n    <div>\n      <input value={input} onChange={(e) => setInput(e.target.value)} />\n      <button onClick={addTodo}>Add</button>\n      <ul>\n        {todos.map(todo => (\n          <li key={todo.id} onClick={() => toggleTodo(todo.id)}>\n            {todo.done ? <s>{todo.text}</s> : todo.text}\n          </li>\n        ))}\n      </ul>\n    </div>\n  );\n}\n```',
  4, 120, ARRAY['Structure React applications', 'Build complete projects', 'Apply React best practices']);

  -- Module 6: Backend Development
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module6_id, 'Node.js Basics', 'Introduction to server-side JavaScript', 
  E'# Node.js Fundamentals\n\n## What is Node.js?\n\nNode.js is a JavaScript runtime for server-side applications.\n\n## Your First Server\n\n```javascript\nconst http = require("http");\n\nconst server = http.createServer((req, res) => {\n  res.writeHead(200, { "Content-Type": "text/html" });\n  res.end("<h1>Hello from Node.js!</h1>");\n});\n\nserver.listen(3000, () => {\n  console.log("Server running on port 3000");\n});\n```\n\n## Working with Files\n\n```javascript\nconst fs = require("fs");\n\n// Read file\nfs.readFile("data.txt", "utf8", (err, data) => {\n  if (err) throw err;\n  console.log(data);\n});\n\n// Write file\nfs.writeFile("output.txt", "Hello World", (err) => {\n  if (err) throw err;\n  console.log("File written!");\n});\n```',
  1, 75, ARRAY['Understand Node.js architecture', 'Create a basic server', 'Work with file system']),
  
  (v_course_id, v_module6_id, 'Express.js Framework', 'Building APIs with Express', 
  E'# Express.js\n\n## Setup\n\n```bash\nnpm init -y\nnpm install express\n```\n\n## Basic Server\n\n```javascript\nconst express = require("express");\nconst app = express();\n\napp.use(express.json());\n\napp.get("/", (req, res) => {\n  res.send("Hello World!");\n});\n\napp.get("/api/users", (req, res) => {\n  res.json([{ id: 1, name: "Alice" }]);\n});\n\napp.post("/api/users", (req, res) => {\n  const user = req.body;\n  res.status(201).json(user);\n});\n\napp.listen(3000, () => {\n  console.log("Server running on port 3000");\n});\n```\n\n## Middleware\n\n```javascript\napp.use((req, res, next) => {\n  console.log(`${req.method} ${req.url}`);\n  next();\n});\n```',
  2, 90, ARRAY['Create Express applications', 'Build RESTful APIs', 'Use middleware effectively']),
  
  (v_course_id, v_module6_id, 'Authentication and Security', 'Implementing user authentication', 
  E'# Authentication\n\n## JWT Authentication\n\n```javascript\nconst jwt = require("jsonwebtoken");\n\n// Generate token\nconst token = jwt.sign(\n  { userId: user.id },\n  "secret_key",\n  { expiresIn: "24h" }\n);\n\n// Verify token\nconst decoded = jwt.verify(token, "secret_key");\n```\n\n## Auth Middleware\n\n```javascript\nfunction authenticate(req, res, next) {\n  const token = req.headers.authorization?.split(" ")[1];\n  \n  if (!token) {\n    return res.status(401).json({ error: "Unauthorized" });\n  }\n  \n  try {\n    const decoded = jwt.verify(token, "secret_key");\n    req.userId = decoded.userId;\n    next();\n  } catch (error) {\n    res.status(401).json({ error: "Invalid token" });\n  }\n}\n\n// Protected route\napp.get("/api/profile", authenticate, (req, res) => {\n  // req.userId is available\n  res.json({ userId: req.userId });\n});\n```',
  3, 85, ARRAY['Implement JWT authentication', 'Create protected routes', 'Handle user sessions']),
  
  (v_course_id, v_module6_id, 'API Best Practices', 'Building production-ready APIs', 
  E'# API Best Practices\n\n## Error Handling\n\n```javascript\nclass AppError extends Error {\n  constructor(message, statusCode) {\n    super(message);\n    this.statusCode = statusCode;\n  }\n}\n\napp.use((err, req, res, next) => {\n  const statusCode = err.statusCode || 500;\n  res.status(statusCode).json({\n    error: err.message,\n    ...(process.env.NODE_ENV === "development" && { stack: err.stack })\n  });\n});\n```\n\n## Validation\n\n```javascript\nconst { body, validationResult } = require("express-validator");\n\napp.post("/api/users",\n  body("email").isEmail(),\n  body("password").isLength({ min: 6 }),\n  (req, res) => {\n    const errors = validationResult(req);\n    if (!errors.isEmpty()) {\n      return res.status(400).json({ errors: errors.array() });\n    }\n    // Process request\n  }\n);\n```',
  4, 80, ARRAY['Implement error handling', 'Validate request data', 'Follow REST best practices']);

  -- Module 7: Databases
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module7_id, 'SQL Fundamentals', 'Working with relational databases', 
  E'# SQL Basics\n\n## Creating Tables\n\n```sql\nCREATE TABLE users (\n  id SERIAL PRIMARY KEY,\n  name VARCHAR(100) NOT NULL,\n  email VARCHAR(100) UNIQUE NOT NULL,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n```\n\n## CRUD Operations\n\n```sql\n-- Create\nINSERT INTO users (name, email) VALUES (''Alice'', ''alice@example.com'');\n\n-- Read\nSELECT * FROM users WHERE email = ''alice@example.com'';\n\n-- Update\nUPDATE users SET name = ''Alice Smith'' WHERE id = 1;\n\n-- Delete\nDELETE FROM users WHERE id = 1;\n```\n\n## Joins\n\n```sql\nSELECT users.name, orders.total\nFROM users\nINNER JOIN orders ON users.id = orders.user_id;\n```',
  1, 90, ARRAY['Write SQL queries', 'Perform CRUD operations', 'Use JOIN clauses']),
  
  (v_course_id, v_module7_id, 'Database Integration', 'Connecting Node.js to databases', 
  E'# Database Integration with Node.js\n\n## Using PostgreSQL\n\n```javascript\nconst { Pool } = require("pg");\n\nconst pool = new Pool({\n  user: "dbuser",\n  host: "localhost",\n  database: "mydb",\n  password: "password",\n  port: 5432,\n});\n\n// Query\nasync function getUsers() {\n  const result = await pool.query("SELECT * FROM users");\n  return result.rows;\n}\n\n// Parameterized query\nasync function createUser(name, email) {\n  const result = await pool.query(\n    "INSERT INTO users (name, email) VALUES ($1, $2) RETURNING *",\n    [name, email]\n  );\n  return result.rows[0];\n}\n```',
  2, 85, ARRAY['Connect to databases', 'Execute queries from Node.js', 'Use parameterized queries']),
  
  (v_course_id, v_module7_id, 'NoSQL with MongoDB', 'Working with document databases', 
  E'# MongoDB Basics\n\n## Connecting to MongoDB\n\n```javascript\nconst { MongoClient } = require("mongodb");\n\nconst client = new MongoClient("mongodb://localhost:27017");\nawait client.connect();\n\nconst db = client.db("myapp");\nconst users = db.collection("users");\n```\n\n## CRUD Operations\n\n```javascript\n// Create\nawait users.insertOne({ name: "Alice", email: "alice@example.com" });\n\n// Read\nconst user = await users.findOne({ email: "alice@example.com" });\nconst allUsers = await users.find().toArray();\n\n// Update\nawait users.updateOne(\n  { email: "alice@example.com" },\n  { $set: { name: "Alice Smith" } }\n);\n\n// Delete\nawait users.deleteOne({ email: "alice@example.com" });\n```',
  3, 80, ARRAY['Work with MongoDB', 'Perform document operations', 'Understand NoSQL concepts']);

  -- Module 8: Full Stack Projects
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module8_id, 'Project Planning', 'Planning full-stack applications', 
  E'# Planning Your Project\n\n## Requirements Gathering\n\n1. Define user stories\n2. Create wireframes\n3. Design database schema\n4. Plan API endpoints\n5. Choose tech stack\n\n## Project Structure\n\n```\nproject/\n├── client/          # React frontend\n│   ├── public/\n│   └── src/\n├── server/          # Node.js backend\n│   ├── routes/\n│   ├── models/\n│   └── controllers/\n└── database/\n    └── migrations/\n```',
  1, 60, ARRAY['Plan full-stack projects', 'Design system architecture', 'Create project structure']),
  
  (v_course_id, v_module8_id, 'Building a Complete Application', 'E-commerce platform project', 
  E'# E-commerce Platform\n\n## Features\n\n- User authentication\n- Product catalog\n- Shopping cart\n- Checkout process\n- Order management\n- Admin panel\n\n## Tech Stack\n\n- Frontend: React + TailwindCSS\n- Backend: Node.js + Express\n- Database: PostgreSQL\n- Authentication: JWT\n\n## Implementation Steps\n\n1. Set up project structure\n2. Create database schema\n3. Build API endpoints\n4. Develop React components\n5. Implement authentication\n6. Add payment integration\n7. Deploy application',
  2, 240, ARRAY['Build complete full-stack applications', 'Integrate frontend and backend', 'Deploy production applications']),
  
  (v_course_id, v_module8_id, 'Testing and Deployment', 'Testing and deploying applications', 
  E'# Testing and Deployment\n\n## Testing\n\n```javascript\n// Jest test example\ntest("adds 1 + 2 to equal 3", () => {\n  expect(1 + 2).toBe(3);\n});\n\n// API test\ntest("GET /api/users returns users", async () => {\n  const response = await request(app).get("/api/users");\n  expect(response.status).toBe(200);\n  expect(Array.isArray(response.body)).toBe(true);\n});\n```\n\n## Deployment\n\n### Heroku\n```bash\nheroku create my-app\ngit push heroku main\n```\n\n### Vercel (Frontend)\n```bash\nnpm install -g vercel\nvercel\n```',
  3, 90, ARRAY['Write tests for applications', 'Deploy to production', 'Monitor deployed applications']);

END $$;
