/*
  # Create Tutorial Programs Schema

  1. New Tables
    - `tutorial_programs`
      - `id` (uuid, primary key)
      - `name` (text) - Program name (e.g., "GCE O/L")
      - `full_name` (text) - Full program name
      - `description` (text) - Program description
      - `target_audience` (text) - Who the program is for
      - `duration` (text) - Program duration
      - `level` (text) - Education level (foundation, intermediate, advanced)
      - `region` (text) - Target region (Nigeria, International, Both)
      - `icon` (text) - Icon identifier for display
      - `color` (text) - Color theme for the program
      - `is_active` (boolean) - Whether program is currently offered
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `tutorial_sessions`
      - `id` (uuid, primary key)
      - `program_id` (uuid, foreign key to tutorial_programs)
      - `title` (text) - Session title
      - `description` (text) - Session description
      - `subjects` (text[]) - Array of subjects covered
      - `schedule` (text) - Schedule information
      - `price` (numeric) - Session price
      - `currency` (text) - Currency (NGN, USD, etc.)
      - `max_students` (integer) - Maximum number of students
      - `enrolled_students` (integer) - Current enrollment count
      - `start_date` (date) - Session start date
      - `end_date` (date) - Session end date
      - `instructor_id` (uuid) - Reference to auth.users
      - `is_active` (boolean) - Whether session is accepting enrollments
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `tutorial_enrollments`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `session_id` (uuid, foreign key to tutorial_sessions)
      - `status` (text) - enrollment status (pending, active, completed, cancelled)
      - `enrolled_at` (timestamptz)
      - `completed_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public read access for programs and sessions
    - Authenticated users can enroll
    - Only enrolled users can view their enrollments
*/

-- Create tutorial_programs table
CREATE TABLE IF NOT EXISTS tutorial_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  full_name text NOT NULL,
  description text NOT NULL,
  target_audience text NOT NULL,
  duration text NOT NULL,
  level text NOT NULL CHECK (level IN ('foundation', 'intermediate', 'advanced')),
  region text NOT NULL CHECK (region IN ('Nigeria', 'International', 'Both')),
  icon text DEFAULT 'BookOpen',
  color text DEFAULT 'blue',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create tutorial_sessions table
CREATE TABLE IF NOT EXISTS tutorial_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id uuid NOT NULL REFERENCES tutorial_programs(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  subjects text[] DEFAULT '{}',
  schedule text NOT NULL,
  price numeric(10, 2) DEFAULT 0,
  currency text DEFAULT 'NGN',
  max_students integer DEFAULT 30,
  enrolled_students integer DEFAULT 0,
  start_date date,
  end_date date,
  instructor_id uuid REFERENCES auth.users(id),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create tutorial_enrollments table
CREATE TABLE IF NOT EXISTS tutorial_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  session_id uuid NOT NULL REFERENCES tutorial_sessions(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'completed', 'cancelled')),
  enrolled_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  UNIQUE(user_id, session_id)
);

-- Enable RLS
ALTER TABLE tutorial_programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE tutorial_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tutorial_enrollments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for tutorial_programs
CREATE POLICY "Anyone can view active tutorial programs"
  ON tutorial_programs FOR SELECT
  USING (is_active = true);

CREATE POLICY "Authenticated users can view all tutorial programs"
  ON tutorial_programs FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for tutorial_sessions
CREATE POLICY "Anyone can view active tutorial sessions"
  ON tutorial_sessions FOR SELECT
  USING (is_active = true);

-- RLS Policies for tutorial_enrollments
CREATE POLICY "Users can view own enrollments"
  ON tutorial_enrollments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can enroll in sessions"
  ON tutorial_enrollments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own enrollments"
  ON tutorial_enrollments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_tutorial_sessions_program_id ON tutorial_sessions(program_id);
CREATE INDEX IF NOT EXISTS idx_tutorial_enrollments_user_id ON tutorial_enrollments(user_id);
CREATE INDEX IF NOT EXISTS idx_tutorial_enrollments_session_id ON tutorial_enrollments(session_id);