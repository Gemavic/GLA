/*
  # Populate All Programming Courses

  1. Courses Covered
    - Django Web Framework (6 modules)
    - Vue.js 3 Complete Course (6 modules)
    - Advanced React & TypeScript (6 modules)

  2. Each module gets 3-5 comprehensive lessons
  3. Total: ~50+ new lessons with detailed content
*/

-- Django Web Framework
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'django-web-framework';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Django Setup and First Project', 'Getting started with Django',
  E'# Django Setup\n\n```bash\npip install django\ndjango-admin startproject myproject\ncd myproject\npython manage.py runserver\n```\n\n## Project Structure\n```\nmyproject/\n├── myproject/\n│   ├── __init__.py\n│   ├── settings.py\n│   ├── urls.py\n│   └── wsgi.py\n└── manage.py\n```\n\n## Create App\n```bash\npython manage.py startapp myapp\n```\n\n## First View\n```python\n# myapp/views.py\nfrom django.http import HttpResponse\n\ndef index(request):\n    return HttpResponse("Hello, Django!")\n\n# myapp/urls.py\nfrom django.urls import path\nfrom . import views\n\nurlpatterns = [\n    path('''', views.index, name=''index''),\n]\n```',
  1, 70, ARRAY['Setup Django', 'Create Django projects', 'Build first views']),
  
  (v_course_id, v_module_id, 'Models and Database', 'Working with Django ORM',
  E'# Django Models\n\n```python\nfrom django.db import models\n\nclass Post(models.Model):\n    title = models.CharField(max_length=200)\n    content = models.TextField()\n    created_at = models.DateTimeField(auto_now_add=True)\n    updated_at = models.DateTimeField(auto_now=True)\n    \n    def __str__(self):\n        return self.title\n\nclass Comment(models.Model):\n    post = models.ForeignKey(Post, on_delete=models.CASCADE)\n    author = models.CharField(max_length=100)\n    text = models.TextField()\n    created_at = models.DateTimeField(auto_now_add=True)\n```\n\n## Migrations\n```bash\npython manage.py makemigrations\npython manage.py migrate\n```\n\n## Query API\n```python\n# Create\npost = Post.objects.create(title="My Post", content="Content")\n\n# Read\nall_posts = Post.objects.all()\npost = Post.objects.get(id=1)\nfiltered = Post.objects.filter(title__contains="Django")\n\n# Update\npost.title = "Updated Title"\npost.save()\n\n# Delete\npost.delete()\n```',
  2, 85, ARRAY['Create Django models', 'Use Django ORM', 'Perform database operations']),
  
  (v_course_id, v_module_id, 'Templates and Views', 'Building dynamic pages',
  E'# Django Templates\n\n```python\n# views.py\nfrom django.shortcuts import render\nfrom .models import Post\n\ndef post_list(request):\n    posts = Post.objects.all().order_by(''-created_at'')\n    return render(request, ''posts/list.html'', {''posts'': posts})\n\ndef post_detail(request, pk):\n    post = Post.objects.get(pk=pk)\n    return render(request, ''posts/detail.html'', {''post'': post})\n```\n\n## Template\n```html\n<!-- templates/posts/list.html -->\n{% extends "base.html" %}\n\n{% block content %}\n  <h1>Blog Posts</h1>\n  {% for post in posts %}\n    <article>\n      <h2><a href="{% url ''post_detail'' post.pk %}">{{ post.title }}</a></h2>\n      <p>{{ post.content|truncatewords:30 }}</p>\n      <small>{{ post.created_at|date:"F d, Y" }}</small>\n    </article>\n  {% endfor %}\n{% endblock %}\n```',
  3, 80, ARRAY['Create Django templates', 'Render dynamic content', 'Use template tags']);
  
  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Forms and Validation', 'Handling user input',
  E'# Django Forms\n\n```python\nfrom django import forms\nfrom .models import Post\n\nclass PostForm(forms.ModelForm):\n    class Meta:\n        model = Post\n        fields = [''title'', ''content'']\n        widgets = {\n            ''content'': forms.Textarea(attrs={''rows'': 5})\n        }\n    \n    def clean_title(self):\n        title = self.cleaned_data.get(''title'')\n        if len(title) < 5:\n            raise forms.ValidationError("Title too short")\n        return title\n\n# views.py\ndef create_post(request):\n    if request.method == ''POST'':\n        form = PostForm(request.POST)\n        if form.is_valid():\n            post = form.save()\n            return redirect(''post_detail'', pk=post.pk)\n    else:\n        form = PostForm()\n    return render(request, ''posts/create.html'', {''form'': form})\n```',
  1, 75, ARRAY['Create Django forms', 'Validate user input', 'Handle form submissions']),
  
  (v_course_id, v_module_id, 'Authentication', 'User management',
  E'# Django Authentication\n\n```python\nfrom django.contrib.auth import authenticate, login, logout\nfrom django.contrib.auth.decorators import login_required\n\ndef user_login(request):\n    if request.method == ''POST'':\n        username = request.POST[''username'']\n        password = request.POST[''password'']\n        user = authenticate(request, username=username, password=password)\n        if user is not None:\n            login(request, user)\n            return redirect(''home'')\n    return render(request, ''login.html'')\n\n@login_required\ndef profile(request):\n    return render(request, ''profile.html'')\n\ndef user_logout(request):\n    logout(request)\n    return redirect(''home'')\n```',
  2, 80, ARRAY['Implement authentication', 'Protect views', 'Manage user sessions']);

END $$;

-- Vue.js 3 Complete Course
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'vuejs-3-complete-course';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Vue 3 Fundamentals', 'Getting started with Vue',
  E'# Vue 3 Basics\n\n```html\n<!DOCTYPE html>\n<html>\n<head>\n  <script src="https://unpkg.com/vue@3"></script>\n</head>\n<body>\n  <div id="app">\n    <h1>{{ message }}</h1>\n    <button @click="count++">Count: {{ count }}</button>\n  </div>\n\n  <script>\n    const { createApp } = Vue;\n    \n    createApp({\n      data() {\n        return {\n          message: ''Hello Vue 3!'',\n          count: 0\n        }\n      }\n    }).mount(''#app'');\n  </script>\n</body>\n</html>\n```\n\n## With Vite\n```bash\nnpm create vite@latest my-vue-app -- --template vue\ncd my-vue-app\nnpm install\nnpm run dev\n```',
  1, 65, ARRAY['Setup Vue 3', 'Create Vue applications', 'Use reactive data']),
  
  (v_course_id, v_module_id, 'Components and Props', 'Building reusable components',
  E'# Vue Components\n\n```vue\n<template>\n  <div class="user-card">\n    <h3>{{ user.name }}</h3>\n    <p>{{ user.email }}</p>\n    <button @click="$emit(''follow'', user.id)">Follow</button>\n  </div>\n</template>\n\n<script>\nexport default {\n  props: {\n    user: {\n      type: Object,\n      required: true\n    }\n  },\n  emits: [''follow'']\n}\n</script>\n\n<!-- Parent Component -->\n<template>\n  <UserCard\n    v-for="user in users"\n    :key="user.id"\n    :user="user"\n    @follow="handleFollow"\n  />\n</template>\n\n<script>\nimport UserCard from ''./UserCard.vue'';\n\nexport default {\n  components: { UserCard },\n  data() {\n    return {\n      users: []\n    }\n  },\n  methods: {\n    handleFollow(userId) {\n      console.log(''Following'', userId);\n    }\n  }\n}\n</script>\n```',
  2, 75, ARRAY['Create Vue components', 'Pass props', 'Emit events']),
  
  (v_course_id, v_module_id, 'Composition API', 'Modern Vue 3 patterns',
  E'# Composition API\n\n```vue\n<template>\n  <div>\n    <p>Count: {{ count }}</p>\n    <button @click="increment">Increment</button>\n    <p>Double: {{ double }}</p>\n  </div>\n</template>\n\n<script setup>\nimport { ref, computed, watch } from ''vue'';\n\nconst count = ref(0);\n\nconst double = computed(() => count.value * 2);\n\nconst increment = () => {\n  count.value++;\n};\n\nwatch(count, (newValue, oldValue) => {\n  console.log(`Count changed from ${oldValue} to ${newValue}`);\n});\n</script>\n```',
  3, 80, ARRAY['Use Composition API', 'Work with reactive references', 'Create computed properties']);
  
  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Vue Router', 'Client-side routing',
  E'# Vue Router Setup\n\n```bash\nnpm install vue-router@4\n```\n\n```javascript\n// router/index.js\nimport { createRouter, createWebHistory } from ''vue-router'';\nimport Home from ''../views/Home.vue'';\nimport About from ''../views/About.vue'';\n\nconst routes = [\n  { path: ''/'', name: ''Home'', component: Home },\n  { path: ''/about'', name: ''About'', component: About },\n  { path: ''/user/:id'', name: ''User'', component: () => import(''../views/User.vue'') }\n];\n\nconst router = createRouter({\n  history: createWebHistory(),\n  routes\n});\n\nexport default router;\n```\n\n## Navigation\n```vue\n<template>\n  <nav>\n    <router-link to="/">Home</router-link>\n    <router-link :to="{name: ''About''}">About</router-link>\n  </nav>\n  <router-view />\n</template>\n```',
  1, 70, ARRAY['Setup Vue Router', 'Create routes', 'Navigate between views']),
  
  (v_course_id, v_module_id, 'State Management with Pinia', 'Global state management',
  E'# Pinia Store\n\n```bash\nnpm install pinia\n```\n\n```javascript\n// stores/counter.js\nimport { defineStore } from ''pinia'';\n\nexport const useCounterStore = defineStore(''counter'', {\n  state: () => ({\n    count: 0,\n    name: ''Counter''\n  }),\n  getters: {\n    doubleCount: (state) => state.count * 2\n  },\n  actions: {\n    increment() {\n      this.count++;\n    },\n    async fetchData() {\n      const response = await fetch(''/api/data'');\n      this.data = await response.json();\n    }\n  }\n});\n```\n\n## Using in Components\n```vue\n<script setup>\nimport { useCounterStore } from ''@/stores/counter'';\n\nconst counter = useCounterStore();\n</script>\n\n<template>\n  <p>{{ counter.count }}</p>\n  <p>{{ counter.doubleCount }}</p>\n  <button @click="counter.increment">Increment</button>\n</template>\n```',
  2, 85, ARRAY['Setup Pinia', 'Create stores', 'Manage global state']);

END $$;

-- Advanced React & TypeScript
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'advanced-react-typescript';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'TypeScript with React', 'Type-safe React applications',
  E'# React with TypeScript\n\n```tsx\ninterface User {\n  id: number;\n  name: string;\n  email: string;\n}\n\ninterface UserCardProps {\n  user: User;\n  onDelete: (id: number) => void;\n}\n\nconst UserCard: React.FC<UserCardProps> = ({ user, onDelete }) => {\n  return (\n    <div className="user-card">\n      <h3>{user.name}</h3>\n      <p>{user.email}</p>\n      <button onClick={() => onDelete(user.id)}>Delete</button>\n    </div>\n  );\n};\n\n// With hooks\nconst UserList: React.FC = () => {\n  const [users, setUsers] = useState<User[]>([]);\n  const [loading, setLoading] = useState<boolean>(true);\n  \n  useEffect(() => {\n    fetchUsers().then(data => {\n      setUsers(data);\n      setLoading(false);\n    });\n  }, []);\n  \n  const handleDelete = (id: number) => {\n    setUsers(users.filter(u => u.id !== id));\n  };\n  \n  if (loading) return <div>Loading...</div>;\n  \n  return (\n    <div>\n      {users.map(user => (\n        <UserCard key={user.id} user={user} onDelete={handleDelete} />\n      ))}\n    </div>\n  );\n};\n```',
  1, 80, ARRAY['Use TypeScript with React', 'Type React components', 'Work with typed hooks']),
  
  (v_course_id, v_module_id, 'Advanced Hooks', 'Custom hooks and patterns',
  E'# Custom Hooks\n\n```tsx\n// useFetch hook\ninterface FetchState<T> {\n  data: T | null;\n  loading: boolean;\n  error: Error | null;\n}\n\nfunction useFetch<T>(url: string): FetchState<T> {\n  const [state, setState] = useState<FetchState<T>>({\n    data: null,\n    loading: true,\n    error: null\n  });\n  \n  useEffect(() => {\n    let cancelled = false;\n    \n    fetch(url)\n      .then(res => res.json())\n      .then(data => {\n        if (!cancelled) {\n          setState({ data, loading: false, error: null });\n        }\n      })\n      .catch(error => {\n        if (!cancelled) {\n          setState({ data: null, loading: false, error });\n        }\n      });\n    \n    return () => {\n      cancelled = true;\n    };\n  }, [url]);\n  \n  return state;\n}\n\n// Usage\nconst UserList = () => {\n  const { data, loading, error } = useFetch<User[]>(''/api/users'');\n  \n  if (loading) return <div>Loading...</div>;\n  if (error) return <div>Error: {error.message}</div>;\n  \n  return (\n    <div>\n      {data?.map(user => <UserCard key={user.id} user={user} />)}\n    </div>\n  );\n};\n```',
  2, 85, ARRAY['Create custom hooks', 'Manage complex state', 'Implement hook patterns']),
  
  (v_course_id, v_module_id, 'Context and useReducer', 'Advanced state management',
  E'# Context with Reducer\n\n```tsx\ntype Action = \n  | { type: ''ADD_TODO''; payload: string }\n  | { type: ''TOGGLE_TODO''; payload: number }\n  | { type: ''DELETE_TODO''; payload: number };\n\ninterface State {\n  todos: Todo[];\n}\n\nconst todoReducer = (state: State, action: Action): State => {\n  switch (action.type) {\n    case ''ADD_TODO'':\n      return {\n        ...state,\n        todos: [...state.todos, {\n          id: Date.now(),\n          text: action.payload,\n          done: false\n        }]\n      };\n    case ''TOGGLE_TODO'':\n      return {\n        ...state,\n        todos: state.todos.map(todo =>\n          todo.id === action.payload\n            ? { ...todo, done: !todo.done }\n            : todo\n        )\n      };\n    case ''DELETE_TODO'':\n      return {\n        ...state,\n        todos: state.todos.filter(todo => todo.id !== action.payload)\n      };\n    default:\n      return state;\n  }\n};\n\nconst TodoContext = createContext<{\n  state: State;\n  dispatch: Dispatch<Action>;\n} | null>(null);\n\nconst TodoProvider: React.FC<{ children: ReactNode }> = ({ children }) => {\n  const [state, dispatch] = useReducer(todoReducer, { todos: [] });\n  \n  return (\n    <TodoContext.Provider value={{ state, dispatch }}>\n      {children}\n    </TodoContext.Provider>\n  );\n};\n```',
  3, 90, ARRAY['Use Context API', 'Implement useReducer', 'Manage application state']);

END $$;
