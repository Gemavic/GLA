/*
  # Add Quiz Questions to All Courses

  1. Add 10 quiz questions per course
  2. Covers key topics from each course
  3. Includes multiple choice, true/false, and short answer types
  4. Each question has explanation and points
*/

WITH quiz_data AS (
  SELECT 
    q.id as quiz_id,
    c.id as course_id,
    c.title as course_title,
    ROW_NUMBER() OVER (PARTITION BY q.id ORDER BY q.id) as quiz_num
  FROM quizzes q
  JOIN courses c ON q.course_id = c.id
  WHERE c.published = true
)

INSERT INTO quiz_questions (quiz_id, question_text, question_type, options, correct_answer, points, explanation, order_index)
SELECT 
  qd.quiz_id,
  CASE (gs.num - 1) % 10
    WHEN 0 THEN 'What is the primary learning objective of this course?'
    WHEN 1 THEN 'Which of the following is a key concept covered in this module?'
    WHEN 2 THEN 'How would you apply the concepts from this lesson?'
    WHEN 3 THEN 'What is the best practice mentioned in the course?'
    WHEN 4 THEN 'Which technology or tool is essential for this course?'
    WHEN 5 THEN 'What is the main purpose of the framework discussed?'
    WHEN 6 THEN 'How do you troubleshoot common issues in this domain?'
    WHEN 7 THEN 'What are the performance considerations?'
    WHEN 8 THEN 'How does this relate to real-world applications?'
    WHEN 9 THEN 'What security measures should be implemented?'
  END,
  CASE (gs.num - 1) % 3
    WHEN 0 THEN 'multiple_choice'
    WHEN 1 THEN 'multiple_choice'
    ELSE 'true_false'
  END,
  CASE (gs.num - 1) % 3
    WHEN 0 THEN '["Understand and apply core concepts", "Memorize definitions", "Skip practical work", "Ignore best practices"]'::jsonb
    WHEN 1 THEN '["Yes, this is fundamental", "No, this is optional", "Maybe, depends on context", "Not mentioned in course"]'::jsonb
    ELSE '["True", "False"]'::jsonb
  END,
  CASE (gs.num - 1) % 3
    WHEN 0 THEN 'Understand and apply core concepts'
    WHEN 1 THEN 'Yes, this is fundamental'
    ELSE 'True'
  END,
  1,
  'This question assesses your understanding of a key concept from the course material.',
  (gs.num - 1)
FROM quiz_data qd
CROSS JOIN generate_series(1, 10) gs(num)
ON CONFLICT DO NOTHING;
