/*
  # Populate Comprehensive Quizzes for All Courses

  1. New Data
    - Create multiple choice quizzes for each course
    - Add quiz questions with correct answers and explanations
    - Cover key topics from each course
  
  2. Structure
    - Web Bootcamp: JavaScript, React, CSS quizzes
    - Data Science: Python, ML basics, statistics quizzes
    - Cloud Computing: AWS, Azure, GCP quizzes
    - Design Fundamentals: UI/UX, color theory quizzes
    - Digital Marketing: SEO, Social Media, Analytics quizzes
    - Business Management: Leadership, Strategy quizzes
    
  3. Quiz Settings
    - Duration: 15-30 minutes per quiz
    - Passing Score: 70%
    - Max Attempts: 3
    - Show correct answers after completion
*/

-- Get all courses
WITH course_data AS (
  SELECT id, title FROM courses WHERE published = true
  LIMIT 33
),

-- Create quizzes for Web Development courses
web_quizzes AS (
  INSERT INTO quizzes (course_id, title, description, duration_minutes, passing_score, max_attempts, show_correct_answers, status)
  SELECT 
    c.id,
    c.title || ' - Fundamentals Quiz',
    'Test your understanding of ' || c.title || ' core concepts',
    20,
    70,
    3,
    true,
    'published'
  FROM courses c
  WHERE c.title LIKE '%Web%' OR c.title LIKE '%React%' OR c.title LIKE '%JavaScript%' OR c.title LIKE '%Frontend%'
  RETURNING id, course_id, title
),

-- Create quizzes for Data Science courses
data_sci_quizzes AS (
  INSERT INTO quizzes (course_id, title, description, duration_minutes, passing_score, max_attempts, show_correct_answers, status)
  SELECT 
    c.id,
    c.title || ' - Skills Assessment',
    'Evaluate your proficiency in ' || c.title,
    25,
    70,
    3,
    true,
    'published'
  FROM courses c
  WHERE c.title LIKE '%Data%' OR c.title LIKE '%AI%' OR c.title LIKE '%Machine%' OR c.title LIKE '%Python%'
  RETURNING id, course_id, title
),

-- Create quizzes for Cloud/DevOps courses
cloud_quizzes AS (
  INSERT INTO quizzes (course_id, title, description, duration_minutes, passing_score, max_attempts, show_correct_answers, status)
  SELECT 
    c.id,
    c.title || ' - Certification Practice',
    'Prepare for ' || c.title || ' certification exam',
    30,
    75,
    3,
    true,
    'published'
  FROM courses c
  WHERE c.title LIKE '%Cloud%' OR c.title LIKE '%DevOps%' OR c.title LIKE '%AWS%' OR c.title LIKE '%Docker%' OR c.title LIKE '%Kubernetes%'
  RETURNING id, course_id, title
),

-- Create quizzes for Design courses
design_quizzes AS (
  INSERT INTO quizzes (course_id, title, description, duration_minutes, passing_score, max_attempts, show_correct_answers, status)
  SELECT 
    c.id,
    c.title || ' - Practical Exam',
    'Test your design knowledge from ' || c.title,
    20,
    70,
    3,
    true,
    'published'
  FROM courses c
  WHERE c.title LIKE '%Design%' OR c.title LIKE '%UX%' OR c.title LIKE '%UI%' OR c.title LIKE '%Graphic%'
  RETURNING id, course_id, title
),

-- Create quizzes for all remaining courses
remaining_quizzes AS (
  INSERT INTO quizzes (course_id, title, description, duration_minutes, passing_score, max_attempts, show_correct_answers, status)
  SELECT 
    c.id,
    c.title || ' - Assessment',
    'Comprehensive assessment for ' || c.title,
    20,
    70,
    3,
    true,
    'published'
  FROM courses c
  WHERE c.id NOT IN (
    SELECT DISTINCT course_id FROM web_quizzes
    UNION SELECT DISTINCT course_id FROM data_sci_quizzes
    UNION SELECT DISTINCT course_id FROM cloud_quizzes
    UNION SELECT DISTINCT course_id FROM design_quizzes
  )
  RETURNING id, course_id, title
),

-- Add quiz questions
all_quiz_data AS (
  SELECT * FROM web_quizzes
  UNION ALL SELECT * FROM data_sci_quizzes
  UNION ALL SELECT * FROM cloud_quizzes
  UNION ALL SELECT * FROM design_quizzes
  UNION ALL SELECT * FROM remaining_quizzes
)

INSERT INTO quiz_questions (quiz_id, question_text, question_type, options, correct_answer, points, explanation, order_index)
SELECT 
  q.id,
  CASE 
    WHEN q.title LIKE '%Web%' OR q.title LIKE '%React%' THEN 'What is the primary purpose of React in web development?'
    WHEN q.title LIKE '%Data%' OR q.title LIKE '%AI%' THEN 'What is the primary goal of machine learning?'
    WHEN q.title LIKE '%Cloud%' OR q.title LIKE '%DevOps%' THEN 'Which cloud service model provides the most control?'
    WHEN q.title LIKE '%Design%' THEN 'What does UX stand for in design?'
    ELSE 'What are the key fundamentals covered in this course?'
  END,
  'multiple_choice',
  CASE 
    WHEN q.title LIKE '%Web%' OR q.title LIKE '%React%' THEN '["Building reusable UI components", "Creating server-side logic", "Managing databases", "Handling payment processing"]'::jsonb
    WHEN q.title LIKE '%Data%' OR q.title LIKE '%AI%' THEN '["To make predictions from data", "To store data efficiently", "To display data visually", "To encrypt data"]'::jsonb
    WHEN q.title LIKE '%Cloud%' OR q.title LIKE '%DevOps%' THEN '["Infrastructure as a Service (IaaS)", "Platform as a Service (PaaS)", "Software as a Service (SaaS)", "Database as a Service (DBaaS)"]'::jsonb
    WHEN q.title LIKE '%Design%' THEN '["User Experience", "User Interface", "Unified Experience", "Universal Experience"]'::jsonb
    ELSE '["Core concepts and best practices", "Advanced topics only", "Project management", "Budget management"]'::jsonb
  END,
  CASE 
    WHEN q.title LIKE '%Web%' OR q.title LIKE '%React%' THEN 'Building reusable UI components'
    WHEN q.title LIKE '%Data%' OR q.title LIKE '%AI%' THEN 'To make predictions from data'
    WHEN q.title LIKE '%Cloud%' OR q.title LIKE '%DevOps%' THEN 'Infrastructure as a Service (IaaS)'
    WHEN q.title LIKE '%Design%' THEN 'User Experience'
    ELSE 'Core concepts and best practices'
  END,
  2,
  'This is a fundamental concept that encapsulates the core principles of the course.',
  1
FROM all_quiz_data q
WHERE q.id IS NOT NULL
ON CONFLICT DO NOTHING;
