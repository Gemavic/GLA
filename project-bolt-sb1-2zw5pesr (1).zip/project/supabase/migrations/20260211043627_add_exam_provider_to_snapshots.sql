/*
  # Add Exam Provider Support to Progress Snapshots

  1. Changes
    - Add `exam_provider` column to `progress_snapshots` table
      - Stores which exam system was used (cambridge, waec, neco, jamb, nabteb, igcse)
      - Default value: 'cambridge' for backward compatibility
    
  2. Updates
    - Add index on exam_provider for efficient filtering
    - Add check constraint to ensure valid exam provider values

  3. Notes
    - Existing records will default to 'cambridge'
    - No data loss for existing progress snapshots
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'progress_snapshots' AND column_name = 'exam_provider'
  ) THEN
    ALTER TABLE progress_snapshots 
    ADD COLUMN exam_provider text DEFAULT 'cambridge' NOT NULL
    CHECK (exam_provider IN ('cambridge', 'waec', 'neco', 'jamb', 'nabteb', 'igcse'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_progress_snapshots_exam_provider 
ON progress_snapshots(exam_provider);

CREATE INDEX IF NOT EXISTS idx_progress_snapshots_user_provider 
ON progress_snapshots(user_id, exam_provider);