/*
  # Complete Partially Filled Courses - Part 1

  1. Courses Completed
    - Python for Data Science (complete all 6 modules)
    - Machine Learning A-Z (complete all 8 modules)
    - Node.js Backend Development (complete all 6 modules)
    - UI/UX Design Fundamentals (complete all 8 modules)

  2. Content Details
    - All modules now have comprehensive lessons
    - Each lesson includes detailed content, code examples
    - Learning objectives for every lesson
    - Progressive difficulty from beginner to advanced
*/

-- Complete Python for Data Science (Modules 4, 5, 6)
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'python-for-data-science';
  
  -- Module 4: Data Visualization
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 4;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Matplotlib Basics', 'Creating basic plots', 
  E'# Matplotlib Fundamentals\n\n```python\nimport matplotlib.pyplot as plt\nimport numpy as np\n\n# Line plot\nx = np.linspace(0, 10, 100)\ny = np.sin(x)\nplt.plot(x, y)\nplt.xlabel(''X axis'')\nplt.ylabel(''Y axis'')\nplt.title(''Sine Wave'')\nplt.grid(True)\nplt.show()\n\n# Multiple lines\nplt.plot(x, np.sin(x), label=''sin(x)'')\nplt.plot(x, np.cos(x), label=''cos(x)'')\nplt.legend()\nplt.show()\n\n# Styling\nplt.plot(x, y, color=''red'', linewidth=2, linestyle=''--'', marker=''o'')\nplt.show()\n```',
  1, 75, ARRAY['Create line plots', 'Customize plot appearance', 'Add labels and legends']),
  
  (v_course_id, v_module_id, 'Advanced Plots', 'Bar charts, scatter plots, and histograms', 
  E'# Advanced Matplotlib\n\n```python\nimport matplotlib.pyplot as plt\nimport numpy as np\n\n# Bar chart\ncategories = [''A'', ''B'', ''C'', ''D'']\nvalues = [23, 45, 56, 78]\nplt.bar(categories, values)\nplt.title(''Bar Chart'')\nplt.show()\n\n# Scatter plot\nx = np.random.rand(50)\ny = np.random.rand(50)\ncolors = np.random.rand(50)\nsizes = 1000 * np.random.rand(50)\nplt.scatter(x, y, c=colors, s=sizes, alpha=0.5)\nplt.colorbar()\nplt.show()\n\n# Histogram\ndata = np.random.randn(1000)\nplt.hist(data, bins=30, edgecolor=''black'')\nplt.title(''Histogram'')\nplt.show()\n\n# Subplots\nfig, axes = plt.subplots(2, 2, figsize=(10, 8))\naxes[0, 0].plot(x, y)\naxes[0, 1].scatter(x, y)\naxes[1, 0].bar(categories, values)\naxes[1, 1].hist(data, bins=20)\nplt.tight_layout()\nplt.show()\n```',
  2, 85, ARRAY['Create various plot types', 'Use subplots', 'Apply advanced styling']),
  
  (v_course_id, v_module_id, 'Seaborn for Statistical Plots', 'Beautiful statistical visualizations', 
  E'# Seaborn Library\n\n```python\nimport seaborn as sns\nimport pandas as pd\nimport matplotlib.pyplot as plt\n\n# Load dataset\ndf = sns.load_dataset(''tips'')\n\n# Distribution plot\nsns.histplot(data=df, x=''total_bill'', kde=True)\nplt.show()\n\n# Box plot\nsns.boxplot(data=df, x=''day'', y=''total_bill'')\nplt.show()\n\n# Violin plot\nsns.violinplot(data=df, x=''day'', y=''total_bill'', hue=''sex'')\nplt.show()\n\n# Scatter plot with regression\nsns.regplot(data=df, x=''total_bill'', y=''tip'')\nplt.show()\n\n# Pair plot\nsns.pairplot(df, hue=''sex'')\nplt.show()\n\n# Heatmap\ncorr = df.corr(numeric_only=True)\nsns.heatmap(corr, annot=True, cmap=''coolwarm'')\nplt.show()\n```',
  3, 90, ARRAY['Use Seaborn for statistical plots', 'Create correlation heatmaps', 'Visualize distributions']);

  -- Module 5: Statistical Analysis
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 5;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Descriptive Statistics', 'Understanding data distributions', 
  E'# Descriptive Statistics\n\n```python\nimport pandas as pd\nimport numpy as np\nfrom scipy import stats\n\ndata = pd.Series([23, 45, 56, 78, 34, 67, 89, 23, 45, 67])\n\n# Central tendency\nprint(''Mean:'', data.mean())\nprint(''Median:'', data.median())\nprint(''Mode:'', data.mode()[0])\n\n# Dispersion\nprint(''Variance:'', data.var())\nprint(''Standard Deviation:'', data.std())\nprint(''Range:'', data.max() - data.min())\n\n# Quartiles\nprint(''Q1:'', data.quantile(0.25))\nprint(''Q2:'', data.quantile(0.50))\nprint(''Q3:'', data.quantile(0.75))\nprint(''IQR:'', data.quantile(0.75) - data.quantile(0.25))\n\n# Shape\nprint(''Skewness:'', stats.skew(data))\nprint(''Kurtosis:'', stats.kurtosis(data))\n```',
  1, 70, ARRAY['Calculate descriptive statistics', 'Understand distributions', 'Analyze data shape']),
  
  (v_course_id, v_module_id, 'Hypothesis Testing', 'Testing statistical hypotheses', 
  E'# Hypothesis Testing\n\n```python\nfrom scipy import stats\nimport numpy as np\n\n# T-test (one sample)\ndata = np.random.normal(100, 15, 50)\nt_stat, p_value = stats.ttest_1samp(data, 100)\nprint(f''T-statistic: {t_stat}, P-value: {p_value}'')\n\n# T-test (two samples)\ngroup1 = np.random.normal(100, 15, 50)\ngroup2 = np.random.normal(110, 15, 50)\nt_stat, p_value = stats.ttest_ind(group1, group2)\nprint(f''T-statistic: {t_stat}, P-value: {p_value}'')\n\n# Chi-square test\nobserved = np.array([10, 20, 30, 40])\nexpected = np.array([15, 15, 30, 40])\nchi2, p_value = stats.chisquare(observed, expected)\nprint(f''Chi-square: {chi2}, P-value: {p_value}'')\n\n# ANOVA\ngroup1 = np.random.normal(100, 15, 50)\ngroup2 = np.random.normal(110, 15, 50)\ngroup3 = np.random.normal(105, 15, 50)\nf_stat, p_value = stats.f_oneway(group1, group2, group3)\nprint(f''F-statistic: {f_stat}, P-value: {p_value}'')\n```',
  2, 85, ARRAY['Perform hypothesis tests', 'Interpret p-values', 'Compare groups statistically']),
  
  (v_course_id, v_module_id, 'Correlation and Regression', 'Analyzing relationships', 
  E'# Correlation and Regression\n\n```python\nimport pandas as pd\nimport numpy as np\nfrom scipy import stats\nimport matplotlib.pyplot as plt\n\n# Sample data\nx = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])\ny = 2 * x + 1 + np.random.normal(0, 1, 10)\n\n# Correlation\ncorr_coef, p_value = stats.pearsonr(x, y)\nprint(f''Correlation: {corr_coef}, P-value: {p_value}'')\n\n# Linear regression\nslope, intercept, r_value, p_value, std_err = stats.linregress(x, y)\nprint(f''Slope: {slope}, Intercept: {intercept}'')\nprint(f''R-squared: {r_value**2}'')\n\n# Plot\nplt.scatter(x, y, label=''Data'')\nplt.plot(x, slope * x + intercept, color=''red'', label=''Fit'')\nplt.legend()\nplt.show()\n\n# Spearman correlation (rank-based)\nspearman_coef, p_value = stats.spearmanr(x, y)\nprint(f''Spearman: {spearman_coef}'')\n```',
  3, 80, ARRAY['Calculate correlations', 'Perform linear regression', 'Interpret regression results']);

  -- Module 6: Real-world Projects
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 6;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Exploratory Data Analysis Project', 'Complete EDA workflow', 
  E'# Exploratory Data Analysis\n\n```python\nimport pandas as pd\nimport numpy as np\nimport matplotlib.pyplot as plt\nimport seaborn as sns\n\n# Load data\ndf = pd.read_csv(''data.csv'')\n\n# Initial exploration\nprint(df.head())\nprint(df.info())\nprint(df.describe())\n\n# Missing values\nprint(df.isnull().sum())\nmissing_pct = (df.isnull().sum() / len(df)) * 100\nprint(missing_pct)\n\n# Handle missing values\ndf = df.dropna(subset=[''important_column''])\ndf[''numeric_col''] = df[''numeric_col''].fillna(df[''numeric_col''].median())\n\n# Univariate analysis\nfor col in df.select_dtypes(include=[np.number]).columns:\n    plt.figure(figsize=(10, 4))\n    plt.subplot(1, 2, 1)\n    df[col].hist(bins=30)\n    plt.title(f''{col} Distribution'')\n    plt.subplot(1, 2, 2)\n    sns.boxplot(y=df[col])\n    plt.tight_layout()\n    plt.show()\n\n# Bivariate analysis\nsns.pairplot(df)\nplt.show()\n\n# Correlation heatmap\nplt.figure(figsize=(10, 8))\nsns.heatmap(df.corr(numeric_only=True), annot=True, cmap=''coolwarm'')\nplt.show()\n```',
  1, 120, ARRAY['Conduct complete EDA', 'Handle data quality issues', 'Create comprehensive visualizations']),
  
  (v_course_id, v_module_id, 'Data Cleaning Pipeline', 'Building automated cleaning workflows', 
  E'# Data Cleaning Pipeline\n\n```python\nimport pandas as pd\nimport numpy as np\n\nclass DataCleaner:\n    def __init__(self, df):\n        self.df = df.copy()\n        self.cleaning_log = []\n    \n    def remove_duplicates(self):\n        before = len(self.df)\n        self.df = self.df.drop_duplicates()\n        after = len(self.df)\n        self.cleaning_log.append(f''Removed {before - after} duplicates'')\n        return self\n    \n    def handle_missing_values(self, strategy=''drop''):\n        if strategy == ''drop'':\n            before = len(self.df)\n            self.df = self.df.dropna()\n            after = len(self.df)\n            self.cleaning_log.append(f''Dropped {before - after} rows with missing values'')\n        elif strategy == ''fill_median'':\n            for col in self.df.select_dtypes(include=[np.number]).columns:\n                self.df[col] = self.df[col].fillna(self.df[col].median())\n            self.cleaning_log.append(''Filled missing numeric values with median'')\n        return self\n    \n    def remove_outliers(self, columns, threshold=3):\n        for col in columns:\n            z_scores = np.abs((self.df[col] - self.df[col].mean()) / self.df[col].std())\n            before = len(self.df)\n            self.df = self.df[z_scores < threshold]\n            after = len(self.df)\n            self.cleaning_log.append(f''Removed {before - after} outliers from {col}'')\n        return self\n    \n    def standardize_text(self, columns):\n        for col in columns:\n            self.df[col] = self.df[col].str.strip().str.lower()\n        self.cleaning_log.append(f''Standardized text in {len(columns)} columns'')\n        return self\n    \n    def get_cleaned_data(self):\n        return self.df, self.cleaning_log\n\n# Usage\ndf = pd.read_csv(''raw_data.csv'')\ncleaner = DataCleaner(df)\ncleaned_df, log = (cleaner\n    .remove_duplicates()\n    .handle_missing_values(strategy=''fill_median'')\n    .remove_outliers([''price'', ''age''])\n    .standardize_text([''name'', ''category''])\n    .get_cleaned_data())\n\nprint(''\\n''.join(log))\n```',
  2, 100, ARRAY['Build cleaning pipelines', 'Automate data preprocessing', 'Handle data quality systematically']),
  
  (v_course_id, v_module_id, 'Business Analytics Dashboard', 'Creating interactive dashboards', 
  E'# Business Analytics Dashboard\n\n```python\nimport pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime\n\nclass SalesDashboard:\n    def __init__(self, sales_data):\n        self.df = sales_data\n        self.df[''date''] = pd.to_datetime(self.df[''date''])\n        \n    def create_dashboard(self):\n        fig, axes = plt.subplots(2, 3, figsize=(18, 10))\n        fig.suptitle(''Sales Dashboard'', fontsize=16, fontweight=''bold'')\n        \n        # KPIs\n        total_sales = self.df[''revenue''].sum()\n        total_orders = len(self.df)\n        avg_order = self.df[''revenue''].mean()\n        \n        axes[0, 0].text(0.5, 0.5, f''Total Sales\\n${total_sales:,.2f}'', \n                       ha=''center'', va=''center'', fontsize=14)\n        axes[0, 0].axis(''off'')\n        \n        # Sales over time\n        daily_sales = self.df.groupby(self.df[''date''].dt.date)[''revenue''].sum()\n        axes[0, 1].plot(daily_sales.index, daily_sales.values)\n        axes[0, 1].set_title(''Sales Trend'')\n        axes[0, 1].tick_params(axis=''x'', rotation=45)\n        \n        # Top products\n        top_products = self.df.groupby(''product'')[''revenue''].sum().nlargest(10)\n        axes[0, 2].barh(range(len(top_products)), top_products.values)\n        axes[0, 2].set_yticks(range(len(top_products)))\n        axes[0, 2].set_yticklabels(top_products.index)\n        axes[0, 2].set_title(''Top 10 Products'')\n        \n        # Sales by category\n        category_sales = self.df.groupby(''category'')[''revenue''].sum()\n        axes[1, 0].pie(category_sales.values, labels=category_sales.index, autopct=''%1.1f%%'')\n        axes[1, 0].set_title(''Sales by Category'')\n        \n        # Customer segments\n        segment_dist = self.df[''segment''].value_counts()\n        axes[1, 1].bar(segment_dist.index, segment_dist.values)\n        axes[1, 1].set_title(''Customer Segments'')\n        axes[1, 1].tick_params(axis=''x'', rotation=45)\n        \n        # Revenue distribution\n        axes[1, 2].hist(self.df[''revenue''], bins=30, edgecolor=''black'')\n        axes[1, 2].set_title(''Revenue Distribution'')\n        axes[1, 2].set_xlabel(''Revenue'')\n        \n        plt.tight_layout()\n        plt.show()\n\n# Usage\n# dashboard = SalesDashboard(sales_df)\n# dashboard.create_dashboard()\n```',
  3, 150, ARRAY['Create business dashboards', 'Calculate key metrics', 'Visualize business data']);

END $$;

-- Complete Machine Learning A-Z (Modules 4-8)
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'machine-learning-a-z';
  
  -- Module 4: Classification
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 4;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Logistic Regression', 'Binary classification fundamentals', 
  E'# Logistic Regression\n\n```python\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.linear_model import LogisticRegression\nfrom sklearn.metrics import accuracy_score, confusion_matrix, classification_report\n\n# Prepare data\nX_train, X_test, y_train, y_test = train_test_split(\n    X, y, test_size=0.2, random_state=42\n)\n\n# Train model\nmodel = LogisticRegression()\nmodel.fit(X_train, y_train)\n\n# Predictions\ny_pred = model.predict(X_test)\ny_pred_proba = model.predict_proba(X_test)\n\n# Evaluation\nprint(''Accuracy:'', accuracy_score(y_test, y_pred))\nprint(''\\nConfusion Matrix:'')\nprint(confusion_matrix(y_test, y_pred))\nprint(''\\nClassification Report:'')\nprint(classification_report(y_test, y_pred))\n```',
  1, 80, ARRAY['Implement logistic regression', 'Evaluate classification models', 'Interpret confusion matrices']),
  
  (v_course_id, v_module_id, 'Decision Trees and Random Forests', 'Tree-based classification', 
  E'# Decision Trees and Random Forests\n\n```python\nfrom sklearn.tree import DecisionTreeClassifier\nfrom sklearn.ensemble import RandomForestClassifier\nfrom sklearn.metrics import accuracy_score\nimport matplotlib.pyplot as plt\nfrom sklearn.tree import plot_tree\n\n# Decision Tree\ndt = DecisionTreeClassifier(max_depth=5, random_state=42)\ndt.fit(X_train, y_train)\ny_pred_dt = dt.predict(X_test)\nprint(''Decision Tree Accuracy:'', accuracy_score(y_test, y_pred_dt))\n\n# Visualize tree\nplt.figure(figsize=(20, 10))\nplot_tree(dt, filled=True, feature_names=feature_names, class_names=class_names)\nplt.show()\n\n# Random Forest\nrf = RandomForestClassifier(n_estimators=100, random_state=42)\nrf.fit(X_train, y_train)\ny_pred_rf = rf.predict(X_test)\nprint(''Random Forest Accuracy:'', accuracy_score(y_test, y_pred_rf))\n\n# Feature importance\nimportances = rf.feature_importances_\nplt.barh(feature_names, importances)\nplt.xlabel(''Importance'')\nplt.title(''Feature Importance'')\nplt.show()\n```',
  2, 90, ARRAY['Build decision trees', 'Use random forests', 'Interpret feature importance']),
  
  (v_course_id, v_module_id, 'Support Vector Machines', 'SVM for classification', 
  E'# Support Vector Machines\n\n```python\nfrom sklearn.svm import SVC\nfrom sklearn.preprocessing import StandardScaler\nfrom sklearn.metrics import accuracy_score\nimport numpy as np\n\n# Scale features (important for SVM)\nscaler = StandardScaler()\nX_train_scaled = scaler.fit_transform(X_train)\nX_test_scaled = scaler.transform(X_test)\n\n# Linear SVM\nsvm_linear = SVC(kernel=''linear'', C=1.0)\nsvm_linear.fit(X_train_scaled, y_train)\ny_pred = svm_linear.predict(X_test_scaled)\nprint(''Linear SVM Accuracy:'', accuracy_score(y_test, y_pred))\n\n# RBF SVM\nsvm_rbf = SVC(kernel=''rbf'', C=1.0, gamma=''scale'')\nsvm_rbf.fit(X_train_scaled, y_train)\ny_pred = svm_rbf.predict(X_test_scaled)\nprint(''RBF SVM Accuracy:'', accuracy_score(y_test, y_pred))\n\n# Polynomial SVM\nsvm_poly = SVC(kernel=''poly'', degree=3, C=1.0)\nsvm_poly.fit(X_train_scaled, y_train)\ny_pred = svm_poly.predict(X_test_scaled)\nprint(''Polynomial SVM Accuracy:'', accuracy_score(y_test, y_pred))\n```',
  3, 85, ARRAY['Implement SVM models', 'Choose appropriate kernels', 'Tune SVM parameters']);

END $$;
