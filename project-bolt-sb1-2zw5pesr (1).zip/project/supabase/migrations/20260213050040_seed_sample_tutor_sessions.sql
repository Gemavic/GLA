/*
  # Seed Sample Tutor Sessions

  Create sample live tutor sessions for testing and demonstration
*/

DO $$
DECLARE
  tutor_id uuid;
BEGIN
  -- Get or create a tutor user (using a known ID for demo)
  tutor_id := '00000000-0000-0000-0000-000000000001';

  -- Insert sample tutor sessions
  INSERT INTO tutor_sessions (
    id,
    title,
    description,
    tutor_id,
    session_type,
    scheduled_start,
    scheduled_end,
    status,
    max_participants,
    current_participants,
    whiteboard_enabled,
    chat_enabled,
    screen_share_enabled,
    is_active,
    created_at,
    updated_at
  ) VALUES
  (
    gen_random_uuid(),
    'Introduction to Advanced JavaScript',
    'Learn advanced JavaScript concepts including closures, async/await, and event loop. Perfect for intermediate developers looking to level up.',
    tutor_id,
    'live',
    NOW() + INTERVAL '30 minutes',
    NOW() + INTERVAL '90 minutes',
    'scheduled',
    25,
    8,
    true,
    true,
    true,
    true,
    NOW(),
    NOW()
  ),
  (
    gen_random_uuid(),
    'Web Development Best Practices',
    'Discover best practices for building scalable web applications with modern frameworks. Real-world examples included.',
    tutor_id,
    'live',
    NOW() - INTERVAL '15 minutes',
    NOW() + INTERVAL '45 minutes',
    'live',
    30,
    18,
    true,
    true,
    true,
    true,
    NOW(),
    NOW()
  ),
  (
    gen_random_uuid(),
    'React Hooks Deep Dive',
    'Master React Hooks with practical examples. Learn useState, useEffect, useContext, and custom hooks.',
    tutor_id,
    'live',
    NOW() + INTERVAL '2 hours',
    NOW() + INTERVAL '3 hours 30 minutes',
    'scheduled',
    20,
    0,
    true,
    true,
    true,
    true,
    NOW(),
    NOW()
  ),
  (
    gen_random_uuid(),
    'Database Design Fundamentals',
    'Learn how to design efficient databases. Covers normalization, indexing, and query optimization.',
    tutor_id,
    'live',
    NOW() + INTERVAL '4 hours',
    NOW() + INTERVAL '5 hours 30 minutes',
    'scheduled',
    25,
    5,
    true,
    true,
    false,
    true,
    NOW(),
    NOW()
  ),
  (
    gen_random_uuid(),
    'TypeScript Essentials',
    'Get up to speed with TypeScript. Static typing, interfaces, generics, and advanced types explained.',
    tutor_id,
    'live',
    NOW() - INTERVAL '2 hours',
    NOW() - INTERVAL '30 minutes',
    'completed',
    20,
    15,
    true,
    true,
    true,
    true,
    NOW(),
    NOW()
  );
END $$;
