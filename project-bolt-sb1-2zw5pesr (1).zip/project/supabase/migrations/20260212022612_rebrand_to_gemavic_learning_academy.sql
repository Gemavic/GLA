/*
  # Rebrand to Gemavic Learning Academy

  1. Updates
    - Update generate_course_certificate function to use new brand name
    - Change instructor name from "Gemavicedu Instructor" to "Gemavic Learning Academy Instructor"
    - Update verification URLs from gemavicedu.com to gemavic.academy
    
  2. Changes
    - Function: generate_course_certificate
    - Default values for instructor names
    - Verification URL pattern
*/

-- Update the generate_course_certificate function with new branding
CREATE OR REPLACE FUNCTION generate_course_certificate(
  p_user_id uuid,
  p_course_id uuid,
  p_student_name text,
  p_final_score numeric
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_cert_id uuid;
  v_course_title text;
  v_cert_number text;
BEGIN
  -- Get course title
  SELECT title INTO v_course_title FROM courses WHERE id = p_course_id;
  
  -- Generate unique certificate number
  v_cert_number := generate_certificate_number();
  
  -- Create certificate
  INSERT INTO certificates (
    user_id,
    course_id,
    certificate_number,
    student_name,
    course_title,
    completion_date,
    grade,
    final_score,
    instructor_name,
    verification_url
  )
  VALUES (
    p_user_id,
    p_course_id,
    v_cert_number,
    p_student_name,
    v_course_title,
    CURRENT_DATE,
    CASE 
      WHEN p_final_score >= 90 THEN 'A'
      WHEN p_final_score >= 80 THEN 'B'
      WHEN p_final_score >= 70 THEN 'C'
      WHEN p_final_score >= 60 THEN 'D'
      ELSE 'F'
    END,
    p_final_score,
    'Gemavic Learning Academy Instructor',
    'https://verify.gemavic.academy/' || v_cert_number
  )
  RETURNING id INTO v_cert_id;
  
  -- Create notification
  INSERT INTO notifications (
    user_id,
    title,
    message,
    type,
    priority,
    action_url,
    action_label
  )
  VALUES (
    p_user_id,
    'Certificate Available!',
    'Congratulations! Your certificate for ' || v_course_title || ' is ready to download.',
    'success',
    'high',
    '/certificates/' || v_cert_id,
    'Download Certificate'
  );
  
  RETURN v_cert_id;
END;
$$;
