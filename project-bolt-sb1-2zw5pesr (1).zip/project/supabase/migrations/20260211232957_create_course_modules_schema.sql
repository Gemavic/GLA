/*
  # Enhanced Course Curriculum Schema

  1. New Tables
    - `course_modules`
      - `id` (uuid, primary key)
      - `course_id` (uuid, foreign key to courses)
      - `title` (text) - Module title
      - `description` (text) - Module description
      - `order_index` (integer) - Order in course
      - `duration_hours` (integer) - Module duration
      - `created_at` (timestamptz)

  2. Changes to Existing Tables
    - Add `module_id` to lessons table to organize lessons under modules
    - Add `prerequisites` field to lessons for learning paths
    - Add `learning_objectives` field to lessons
    - Add `quiz_questions` JSONB field to lessons for assessments

  3. Security
    - Enable RLS on `course_modules` table
    - Add policies for public read access
    - Add policies for authenticated users to track progress
*/

-- Create course_modules table
CREATE TABLE IF NOT EXISTS course_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  order_index integer NOT NULL,
  duration_hours integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE course_modules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view course modules"
  ON course_modules FOR SELECT
  TO public
  USING (true);

-- Add new fields to lessons table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'lessons' AND column_name = 'module_id'
  ) THEN
    ALTER TABLE lessons ADD COLUMN module_id uuid REFERENCES course_modules(id) ON DELETE CASCADE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'lessons' AND column_name = 'learning_objectives'
  ) THEN
    ALTER TABLE lessons ADD COLUMN learning_objectives text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'lessons' AND column_name = 'prerequisites'
  ) THEN
    ALTER TABLE lessons ADD COLUMN prerequisites text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'lessons' AND column_name = 'quiz_questions'
  ) THEN
    ALTER TABLE lessons ADD COLUMN quiz_questions jsonb DEFAULT '[]';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'lessons' AND column_name = 'resources'
  ) THEN
    ALTER TABLE lessons ADD COLUMN resources jsonb DEFAULT '[]';
  END IF;
END $$;

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_course_modules_course_id ON course_modules(course_id);
CREATE INDEX IF NOT EXISTS idx_lessons_module_id ON lessons(module_id);
