/*
  # Populate Study Resources for All Courses

  1. New Data
    - Add downloadable resources for each course
    - Include study guides, code templates, templates
    - Add links to external resources
  
  2. Resource Types
    - Documents: Study guides, checklists, templates
    - Code: Source code examples, starter templates
    - Links: Recommended articles, documentation
    - Presentations: Lecture slides, tutorials
    
  3. Content
    - 3-5 resources per course
    - Varying types to support different learning styles
*/

WITH course_modules AS (
  SELECT cm.id, cm.course_id, cm.title as module_title, c.title as course_title
  FROM course_modules cm
  JOIN courses c ON cm.course_id = c.id
  WHERE c.published = true
  ORDER BY c.id, cm.order_index
  LIMIT 100
)

INSERT INTO study_materials (course_id, module_id, title, description, material_type)
SELECT 
  DISTINCT cm.course_id,
  cm.id,
  CASE (ROW_NUMBER() OVER (PARTITION BY cm.course_id ORDER BY cm.id)) % 5
    WHEN 1 THEN 'Comprehensive Study Guide - ' || cm.module_title
    WHEN 2 THEN 'Code Templates & Starters - ' || cm.module_title
    WHEN 3 THEN 'Quick Reference Checklists'
    WHEN 4 THEN 'Video Tutorials Compilation'
    ELSE 'Advanced Examples & Patterns'
  END,
  CASE (ROW_NUMBER() OVER (PARTITION BY cm.course_id ORDER BY cm.id)) % 5
    WHEN 1 THEN 'Complete study guide covering all topics in ' || cm.module_title || '. Includes key concepts, examples, and practice questions.'
    WHEN 2 THEN 'Ready-to-use code templates and starter projects for ' || cm.module_title || '. Customize and extend for your projects.'
    WHEN 3 THEN 'Handy checklists and quick reference guides for common tasks and concepts.'
    WHEN 4 THEN 'Curated video tutorials from top instructors covering ' || cm.module_title || ' in depth.'
    ELSE 'Advanced code examples and design patterns used in production applications.'
  END,
  CASE (ROW_NUMBER() OVER (PARTITION BY cm.course_id ORDER BY cm.id)) % 5
    WHEN 1 THEN 'document'
    WHEN 2 THEN 'code'
    WHEN 3 THEN 'document'
    WHEN 4 THEN 'video'
    ELSE 'code'
  END
FROM course_modules cm
ON CONFLICT DO NOTHING;
