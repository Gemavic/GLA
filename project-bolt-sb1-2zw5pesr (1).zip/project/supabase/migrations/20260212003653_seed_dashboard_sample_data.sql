/*
  # Seed Sample Data for Student Dashboard

  1. Sample Data
    - Sample assignments for courses
    - Sample quizzes with questions
    - Sample calendar events
    - Sample announcements
    - Sample achievements
    - Sample study materials

  2. Purpose
    - Provide realistic demo data
    - Enable dashboard testing
    - Show full functionality
*/

-- Sample Assignments
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  -- Get a few course IDs
  FOR v_course_id IN
    SELECT id FROM courses WHERE published = true ORDER BY RANDOM() LIMIT 5
  LOOP
    -- Get first module for this course
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id ORDER BY order_index LIMIT 1;
    
    -- Create assignments
    INSERT INTO assignments (course_id, module_id, title, description, instructions, due_date, total_points)
    VALUES
    (v_course_id, v_module_id, 'Week 1 Project', 'Build a practical project demonstrating the concepts learned', 
     E'Requirements:\n1. Implement core functionality\n2. Write tests\n3. Document your code\n4. Submit via GitHub',
     now() + interval '7 days', 100),
    (v_course_id, v_module_id, 'Assignment: Core Concepts', 'Complete the exercises on core concepts',
     E'Complete all exercises in the workbook and submit your answers.',
     now() + interval '5 days', 50),
    (v_course_id, v_module_id, 'Final Project', 'Comprehensive final project',
     E'Apply everything you''ve learned to build a complete solution.',
     now() + interval '30 days', 200);
  END LOOP;
END $$;

-- Sample Quizzes
DO $$
DECLARE
  v_course_id uuid;
  v_quiz_id uuid;
  v_lesson_id uuid;
BEGIN
  FOR v_course_id IN
    SELECT id FROM courses WHERE published = true ORDER BY RANDOM() LIMIT 5
  LOOP
    -- Get a lesson for this course
    SELECT id INTO v_lesson_id FROM lessons WHERE course_id = v_course_id ORDER BY RANDOM() LIMIT 1;
    
    -- Create quiz
    INSERT INTO quizzes (course_id, lesson_id, title, description, duration_minutes, passing_score)
    VALUES
    (v_course_id, v_lesson_id, 'Module Quiz', 'Test your understanding of the module concepts', 30, 70)
    RETURNING id INTO v_quiz_id;
    
    -- Add quiz questions
    INSERT INTO quiz_questions (quiz_id, question_text, question_type, options, correct_answer, points)
    VALUES
    (v_quiz_id, 'What is the main concept covered in this module?', 'multiple_choice',
     '["Option A", "Option B", "Option C", "Option D"]'::jsonb, 'Option A', 10),
    (v_quiz_id, 'True or False: This concept is important for best practices.', 'true_false',
     '["True", "False"]'::jsonb, 'True', 10),
    (v_quiz_id, 'Explain the key principle in your own words.', 'short_answer',
     NULL, NULL, 20);
  END LOOP;
END $$;

-- Sample Calendar Events
DO $$
DECLARE
  v_course_id uuid;
  v_event_date timestamptz;
BEGIN
  FOR v_course_id IN
    SELECT id FROM courses WHERE published = true ORDER BY RANDOM() LIMIT 5
  LOOP
    -- Create various types of events
    FOR i IN 0..6 LOOP
      v_event_date := now() + (i || ' days')::interval + (RANDOM() * 12 || ' hours')::interval;
      
      INSERT INTO calendar_events (course_id, title, description, event_type, start_time, end_time, meeting_link)
      VALUES
      (v_course_id, 
       CASE 
         WHEN i % 3 = 0 THEN 'Live Q&A Session'
         WHEN i % 3 = 1 THEN 'Office Hours'
         ELSE 'Guest Speaker Webinar'
       END,
       'Join us for an interactive session',
       CASE 
         WHEN i % 3 = 0 THEN 'meeting'
         WHEN i % 3 = 1 THEN 'office_hours'
         ELSE 'class'
       END,
       v_event_date,
       v_event_date + interval '1 hour',
       'https://meet.gemavicedu.com/' || substr(md5(random()::text), 1, 8));
    END LOOP;
  END LOOP;
END $$;

-- Sample Announcements
DO $$
DECLARE
  v_course_id uuid;
BEGIN
  FOR v_course_id IN
    SELECT id FROM courses WHERE published = true ORDER BY RANDOM() LIMIT 5
  LOOP
    INSERT INTO announcements (course_id, title, content, priority, is_pinned)
    VALUES
    (v_course_id, 'Welcome to the Course!', 
     'We''re excited to have you in this course. Check out the syllabus and reach out if you have any questions.',
     'high', true),
    (v_course_id, 'New Study Materials Available',
     'Additional resources have been added to help you succeed. Check the Resources tab.',
     'normal', false),
    (v_course_id, 'Important: Assignment Deadline Extended',
     'Due to popular request, the deadline for Assignment 1 has been extended by 3 days.',
     'urgent', true);
  END LOOP;
END $$;

-- Sample Study Materials
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  FOR v_course_id IN
    SELECT id FROM courses WHERE published = true ORDER BY RANDOM() LIMIT 5
  LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id ORDER BY order_index LIMIT 1;
    
    INSERT INTO study_materials (course_id, module_id, title, description, material_type, file_url)
    VALUES
    (v_course_id, v_module_id, 'Course Syllabus', 'Complete course syllabus and schedule', 'document',
     'https://example.com/syllabus.pdf'),
    (v_course_id, v_module_id, 'Lecture Slides', 'Presentation slides from lectures', 'presentation',
     'https://example.com/slides.pdf'),
    (v_course_id, v_module_id, 'Code Examples', 'Sample code and templates', 'code',
     'https://github.com/example/code'),
    (v_course_id, v_module_id, 'Recommended Reading', 'Additional learning resources', 'link',
     'https://example.com/resources');
  END LOOP;
END $$;

-- Create sample achievements for demonstration
-- Note: These will need actual user_id to work, but structure is ready
CREATE TABLE IF NOT EXISTS achievement_types (
  type_name text PRIMARY KEY,
  title text NOT NULL,
  description text NOT NULL,
  badge_icon text DEFAULT 'award',
  badge_color text DEFAULT '#3b82f6'
);

INSERT INTO achievement_types (type_name, title, description, badge_icon, badge_color)
VALUES
('course_completion', 'Course Complete', 'Completed an entire course', 'award', '#10b981'),
('quiz_master', 'Quiz Master', 'Scored 100% on a quiz', 'target', '#f59e0b'),
('discussion_contributor', 'Active Contributor', 'Posted 10+ helpful discussion replies', 'message-square', '#8b5cf6'),
('assignment_excellence', 'Assignment Excellence', 'Received perfect score on assignment', 'star', '#f59e0b'),
('perfect_attendance', 'Perfect Attendance', 'Attended all live sessions', 'calendar-check', '#3b82f6'),
('streak', 'Learning Streak', 'Logged in for 7 consecutive days', 'flame', '#ef4444')
ON CONFLICT (type_name) DO NOTHING;
