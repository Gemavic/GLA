/*
  # Seed Tutorial Programs Data

  1. Data Insertion
    - Insert educational programs for Nigerian and international students
    - Programs include: GCE O/L, GCE A/L, Cambridge AS/A/L, JUPEB, IJMB, WAEC, NECO, JAMB
    - Sample tutorial sessions for each program

  2. Programs Added
    - GCE O/L (General Certificate of Education Ordinary Level)
    - GCE A/L (General Certificate of Education Advanced Level)
    - Cambridge AS/A Level
    - JUPEB (Joint Universities Preliminary Examinations Board)
    - IJMB (Interim Joint Matriculation Board)
    - WAEC (West African Examinations Council)
    - NECO (National Examinations Council)
    - JAMB (Joint Admissions and Matriculation Board)
*/

-- Insert Tutorial Programs
INSERT INTO tutorial_programs (name, full_name, description, target_audience, duration, level, region, icon, color) VALUES
  (
    'GCE O/L',
    'General Certificate of Education Ordinary Level',
    'Comprehensive preparation for GCE Ordinary Level examinations. This program covers all major subjects including Mathematics, English Language, Sciences, and Humanities, providing students with a strong foundation for advanced studies.',
    'International students aged 14-16 seeking O Level certification',
    '1-2 years',
    'foundation',
    'International',
    'BookOpen',
    'blue'
  ),
  (
    'GCE A/L',
    'General Certificate of Education Advanced Level',
    'Advanced preparation for GCE A Level examinations. Intensive study program for students pursuing university admission, covering specialized subjects in Sciences, Arts, and Commerce streams.',
    'International students aged 16-18 preparing for university',
    '2 years',
    'advanced',
    'International',
    'GraduationCap',
    'purple'
  ),
  (
    'Cambridge AS/A Level',
    'Cambridge Advanced Subsidiary and Advanced Level',
    'World-class Cambridge International AS and A Level preparation. Recognized globally by universities and employers, this program develops deep subject knowledge and independent thinking skills.',
    'International students seeking globally recognized qualifications',
    '2 years',
    'advanced',
    'International',
    'Award',
    'green'
  ),
  (
    'JUPEB',
    'Joint Universities Preliminary Examinations Board',
    'Direct entry program into 200 level of Nigerian universities. Accredited by JUPEB, this intensive one-year program is recognized by all Nigerian universities and offers students an alternative route to university admission.',
    'Nigerian students seeking direct entry into 200 level',
    '1 year',
    'advanced',
    'Nigeria',
    'School',
    'orange'
  ),
  (
    'IJMB',
    'Interim Joint Matriculation Board',
    'Fast-track program for direct entry into 200 level of Nigerian universities. Approved by ABU and recognized nationwide, IJMB offers students an accelerated path to university education.',
    'Nigerian students seeking direct university entry',
    '9 months',
    'advanced',
    'Nigeria',
    'BookCheck',
    'red'
  ),
  (
    'WAEC',
    'West African Examinations Council',
    'Complete preparation for WAEC/SSCE examinations. Covers all subjects required for secondary school certification in West Africa, with focus on understanding concepts and exam techniques.',
    'West African students in SS1-SS3',
    '1-3 years',
    'intermediate',
    'Nigeria',
    'FileText',
    'teal'
  ),
  (
    'NECO',
    'National Examinations Council',
    'Thorough preparation for NECO examinations. Comprehensive coverage of SSCE syllabus with emphasis on practical applications and exam strategies for success.',
    'Nigerian secondary school students',
    '1-3 years',
    'intermediate',
    'Nigeria',
    'BookMarked',
    'indigo'
  ),
  (
    'JAMB UTME',
    'Joint Admissions and Matriculation Board - UTME',
    'Intensive coaching for JAMB UTME (Unified Tertiary Matriculation Examination). Focused preparation covering Use of English and three relevant subjects for university admission.',
    'Nigerian students seeking university admission',
    '3-6 months',
    'intermediate',
    'Nigeria',
    'Target',
    'yellow'
  )
ON CONFLICT DO NOTHING;

-- Insert Sample Tutorial Sessions
INSERT INTO tutorial_sessions (program_id, title, description, subjects, schedule, price, currency, max_students, start_date, end_date) VALUES
  (
    (SELECT id FROM tutorial_programs WHERE name = 'GCE O/L' LIMIT 1),
    'GCE O/L Science Stream - 2026 Cohort',
    'Complete preparation for GCE O Level Science subjects including Mathematics, Physics, Chemistry, and Biology. Experienced instructors with proven track record.',
    ARRAY['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English Language'],
    'Monday to Friday, 3:00 PM - 6:00 PM WAT',
    85000,
    'NGN',
    25,
    '2026-03-01',
    '2027-02-28'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'Cambridge AS/A Level' LIMIT 1),
    'Cambridge A Level Sciences - March 2026',
    'Comprehensive Cambridge A Level preparation for Sciences. Covers Physics, Chemistry, Mathematics, and Further Mathematics with past paper practice.',
    ARRAY['Physics', 'Chemistry', 'Mathematics', 'Further Mathematics'],
    'Weekdays 4:00 PM - 7:00 PM, Saturdays 10:00 AM - 2:00 PM',
    120000,
    'NGN',
    20,
    '2026-03-15',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'JUPEB' LIMIT 1),
    'JUPEB Science Programme 2026/2027',
    'JUPEB direct entry program for Science students. Covers Physics, Chemistry, Biology/Mathematics, and Use of English. Guaranteed progression to 200 level.',
    ARRAY['Physics', 'Chemistry', 'Biology', 'Mathematics', 'Use of English'],
    'Monday to Friday, 9:00 AM - 4:00 PM',
    250000,
    'NGN',
    30,
    '2026-09-01',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'IJMB' LIMIT 1),
    'IJMB Science - 2026 Session',
    'Intensive IJMB program for Science students. Full coverage of Physics, Chemistry, Mathematics/Biology with mock exams and past questions.',
    ARRAY['Physics', 'Chemistry', 'Mathematics', 'Biology'],
    'Monday to Saturday, 8:00 AM - 3:00 PM',
    180000,
    'NGN',
    35,
    '2026-10-01',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'WAEC' LIMIT 1),
    'WAEC/SSCE Preparation - May/June 2026',
    'Complete WAEC preparation for all subjects. Expert tutors, comprehensive materials, and regular mock examinations.',
    ARRAY['Mathematics', 'English Language', 'Physics', 'Chemistry', 'Biology', 'Economics', 'Geography'],
    'Weekdays 4:00 PM - 7:00 PM, Saturdays 10:00 AM - 4:00 PM',
    60000,
    'NGN',
    40,
    '2026-02-01',
    '2026-05-15'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'JAMB UTME' LIMIT 1),
    'JAMB UTME 2026 - Science Class',
    'Intensive JAMB UTME preparation. Focus on Use of English, Mathematics, Physics, and Chemistry. Includes CBT practice sessions.',
    ARRAY['Use of English', 'Mathematics', 'Physics', 'Chemistry'],
    'Weekdays 5:00 PM - 8:00 PM, Sundays 2:00 PM - 5:00 PM',
    35000,
    'NGN',
    50,
    '2026-01-15',
    '2026-04-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'GCE A/L' LIMIT 1),
    'GCE A Level Commerce - 2026',
    'GCE A Level preparation for Commerce students. Covers Accounting, Economics, Business Studies, and Mathematics.',
    ARRAY['Accounting', 'Economics', 'Business Studies', 'Mathematics'],
    'Monday, Wednesday, Friday 4:00 PM - 7:00 PM',
    95000,
    'NGN',
    20,
    '2026-03-01',
    '2027-11-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NECO' LIMIT 1),
    'NECO SSCE Preparation - June/July 2026',
    'Comprehensive NECO examination preparation. Experienced teachers, quality materials, and regular assessments to ensure success.',
    ARRAY['Mathematics', 'English Language', 'Physics', 'Chemistry', 'Biology', 'Further Mathematics'],
    'Tuesday, Thursday, Saturday 3:00 PM - 6:00 PM',
    55000,
    'NGN',
    35,
    '2026-02-15',
    '2026-06-30'
  )
ON CONFLICT DO NOTHING;