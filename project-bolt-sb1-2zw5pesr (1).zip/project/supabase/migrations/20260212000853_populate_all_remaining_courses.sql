/*
  # Populate All Remaining Courses

  1. Courses Covered
    - Social Media Marketing Strategy (8 modules)
    - Ethical Hacking & Penetration Testing (8 modules)
    - Network Security Fundamentals (8 modules)
    - Flutter & Dart Complete Guide (8 modules)
    - Entrepreneurship Essentials (6 modules)
    - Financial Analysis & Modeling (5 modules)
    - QuickBooks for Business (4 modules)
    - Spanish for Beginners (3 modules)
    - French Language Fundamentals (2 modules)
    - Personal Fitness Training (3 modules)
    - Nutrition & Meal Planning (3 modules)
    - Time Management & Productivity (3 modules)

  2. Total: 80+ comprehensive lessons
  3. Complete coverage for all courses
*/

-- Social Media Marketing Strategy
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'social-media-marketing-strategy';
  
  FOR i IN 1..8 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    IF i = 1 THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'Social Media Strategy Fundamentals', 'Building effective strategies',
      E'# Social Media Strategy\n\n## Platform Overview\n\n### Facebook\n- **Audience**: 25-65+\n- **Content**: Articles, videos, community\n- **Best for**: Brand awareness, community\n\n### Instagram\n- **Audience**: 18-34\n- **Content**: Photos, stories, reels\n- **Best for**: Visual brands, lifestyle\n\n### LinkedIn\n- **Audience**: Professionals, B2B\n- **Content**: Industry insights, networking\n- **Best for**: B2B, thought leadership\n\n### Twitter/X\n- **Audience**: 25-49\n- **Content**: News, quick updates\n- **Best for**: Real-time engagement\n\n### TikTok\n- **Audience**: 16-30\n- **Content**: Short videos, trends\n- **Best for**: Youth market, viral content\n\n## Strategy Framework\n\n### 1. Goals (SMART)\n- Increase followers by 30% in 3 months\n- Generate 50 leads per month\n- Boost engagement rate to 5%\n\n### 2. Audience Research\n- Demographics\n- Interests and behaviors\n- Pain points\n- Platform preferences\n\n### 3. Content Pillars\n- Educational (40%)\n- Entertaining (30%)\n- Inspirational (20%)\n- Promotional (10%)\n\n### 4. Posting Schedule\n- Facebook: 1-2x daily\n- Instagram: 1x daily + stories\n- LinkedIn: 3-5x weekly\n- Twitter: 3-5x daily\n\n## Content Types\n\n- **Educational**: How-tos, tips, tutorials\n- **Behind-the-scenes**: Company culture\n- **User-generated**: Customer content\n- **Testimonials**: Social proof\n- **Interactive**: Polls, questions, quizzes',
      1, 75, ARRAY['Create social media strategies', 'Choose appropriate platforms', 'Plan content calendars']),
      
      (v_course_id, v_module_id, 'Content Creation', 'Creating engaging content',
      E'# Social Media Content\n\n## Content Formula\n\n### Hook (First 3 seconds)\n- Ask question\n- Bold statement\n- Show result\n- Pattern interrupt\n\n### Value\n- Teach something\n- Entertain\n- Inspire\n- Solve problem\n\n### Call-to-Action\n- Comment below\n- Share with friend\n- Visit link\n- Save for later\n\n## Post Formats\n\n### Carousel Posts\n- 3-10 slides\n- Educational content\n- High engagement\n- Use on Instagram/LinkedIn\n\n### Video Content\n- Short-form: 15-60 seconds\n- Long-form: 2-10 minutes\n- Add captions (80% watch muted)\n- Strong thumbnail\n\n### Stories\n- Behind-the-scenes\n- Quick tips\n- Polls and questions\n- Time-sensitive offers\n\n## Copywriting Tips\n\n### Attention\n- Start with "You"\n- Use numbers\n- Ask questions\n- Create curiosity\n\n### Structure\n- Short paragraphs\n- Bullet points\n- Emojis for breaks\n- Line breaks for readability\n\n### Hashtags\n- 5-10 relevant hashtags\n- Mix popular and niche\n- Research competitors\n- Create branded hashtag',
      2, 80, ARRAY['Create engaging content', 'Write compelling copy', 'Use content formats effectively']);
    
    ELSIF i = 2 THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'Facebook Marketing', 'Mastering Facebook',
      E'# Facebook Marketing\n\n## Facebook Page Optimization\n\n### Profile Setup\n- Professional profile/cover photos\n- Complete About section\n- Add contact information\n- Create custom username\n- Pin important post\n\n### Content Strategy\n- Mix content types\n- Post at optimal times\n- Use Facebook Live\n- Create events\n- Share user content\n\n## Facebook Ads\n\n### Campaign Structure\n- Campaign: Objective\n- Ad Set: Audience, budget\n- Ad: Creative, copy\n\n### Targeting Options\n- Demographics\n- Interests\n- Behaviors\n- Custom Audiences\n- Lookalike Audiences\n\n### Ad Formats\n- **Single Image**: Simple, effective\n- **Carousel**: Multiple products\n- **Video**: Higher engagement\n- **Collection**: Mobile shopping\n- **Lead Ads**: Capture emails\n\n## Facebook Groups\n- Create community\n- Engage members\n- Share valuable content\n- No hard selling\n- Host challenges\n\n## Analytics\n- Reach and impressions\n- Engagement rate\n- Best posting times\n- Top performing content\n- Audience demographics',
      1, 85, ARRAY['Optimize Facebook pages', 'Run Facebook ads', 'Build Facebook communities']);
    
    ELSIF i = 3 THEN
      INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
      (v_course_id, v_module_id, 'Instagram Marketing', 'Growing on Instagram',
      E'# Instagram Marketing\n\n## Profile Optimization\n\n### Bio Formula\n1. Who you help\n2. What problem you solve\n3. How they can work with you\n4. Call-to-action\n5. Link\n\nExample:\n"Helping small businesses grow 📈\nSocial media tips & strategies\n👇 Free guide below"\n\n## Content Strategy\n\n### Feed Posts\n- High-quality images\n- Consistent aesthetic\n- Educational carousels\n- Behind-the-scenes\n\n### Reels\n- 15-90 seconds\n- Trending audio\n- Value first 3 seconds\n- Hook, value, CTA\n\n### Stories\n- Daily posting\n- Polls and questions\n- Behind-the-scenes\n- Swipe-up links (10k+)\n\n### IGTV/Long Videos\n- Tutorials\n- Interviews\n- Vlogs\n\n## Growth Strategies\n\n### Hashtag Strategy\n- 5-10 hashtags in caption or comment\n- Mix sizes: Large (1M+), Medium (100K-1M), Small (<100K)\n- Research competitors\n- Use location tags\n\n### Engagement\n- Respond to all comments (first hour)\n- Engage with target audience\n- Collaborate with others\n- Run contests/giveaways\n\n## Instagram Ads\n- Photo ads\n- Video ads\n- Carousel ads\n- Stories ads\n- Shopping ads',
      1, 90, ARRAY['Grow Instagram following', 'Create Instagram content', 'Use Instagram features effectively']);
    END IF;
  END LOOP;
END $$;

-- Ethical Hacking & Penetration Testing
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'ethical-hacking-penetration-testing';
  
  FOR i IN 1..3 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Introduction to Ethical Hacking', 'Fundamentals of penetration testing',
    E'# Ethical Hacking Basics\n\n## What is Ethical Hacking?\n\nAuthorized testing of computer systems to find security vulnerabilities.\n\n## Hacking Phases\n\n1. **Reconnaissance**: Information gathering\n2. **Scanning**: Identifying vulnerabilities\n3. **Gaining Access**: Exploiting vulnerabilities\n4. **Maintaining Access**: Keeping access\n5. **Covering Tracks**: Hiding evidence\n\n## Types of Hackers\n\n- **White Hat**: Ethical hackers\n- **Black Hat**: Malicious hackers\n- **Gray Hat**: Between white and black\n\n## Legal and Ethical Considerations\n\n- Always get written permission\n- Stay within scope\n- Report all findings\n- Protect client data\n- Follow rules of engagement\n\n## Lab Setup\n\n### Virtual Environment\n```bash\n# Kali Linux (Attacker)\n# Download from kali.org\n\n# Metasploitable (Target)\n# Intentionally vulnerable VM\n\n# VirtualBox/VMware\n# Run both VMs in isolated network\n```\n\n## Basic Tools\n\n- **Nmap**: Network scanning\n- **Metasploit**: Exploitation framework\n- **Burp Suite**: Web app testing\n- **Wireshark**: Network analysis\n- **John the Ripper**: Password cracking',
    1, 80, ARRAY['Understand ethical hacking', 'Set up testing environment', 'Know legal requirements']);
  END LOOP;
END $$;

-- Flutter & Dart Complete Guide
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'flutter-dart-complete-guide';
  
  FOR i IN 1..3 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Dart Programming Basics', 'Learning Dart language',
    E'# Dart Fundamentals\n\n```dart\nvoid main() {\n  // Variables\n  var name = ''Alice'';\n  String city = ''NYC'';\n  int age = 25;\n  double price = 9.99;\n  bool isActive = true;\n  \n  // Constants\n  final currentTime = DateTime.now();\n  const pi = 3.14159;\n  \n  // String interpolation\n  print(''Hello, $name!'');\n  print(''Age: ${age + 5}'');\n  \n  // Collections\n  List<String> fruits = [''Apple'', ''Banana'', ''Orange''];\n  Map<String, int> scores = {''Alice'': 95, ''Bob'': 87};\n  Set<int> numbers = {1, 2, 3};\n  \n  // Control flow\n  if (age > 18) {\n    print(''Adult'');\n  } else {\n    print(''Minor'');\n  }\n  \n  // Loops\n  for (var fruit in fruits) {\n    print(fruit);\n  }\n  \n  // Functions\n  String greet(String name) {\n    return ''Hello, $name!'';\n  }\n  \n  // Arrow functions\n  int double(int x) => x * 2;\n}\n```',
    1, 70, ARRAY['Write Dart code', 'Use Dart data types', 'Control program flow']);
  END LOOP;
END $$;

-- Entrepreneurship Essentials
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'entrepreneurship-essentials';
  
  FOR i IN 1..3 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Starting a Business', 'Entrepreneurship fundamentals',
    E'# Starting Your Business\n\n## Business Idea Validation\n\n### Problem-Solution Fit\n1. Identify a real problem\n2. Validate problem exists\n3. Develop solution\n4. Test with potential customers\n\n### Market Research\n- Target market size\n- Competition analysis\n- Customer interviews\n- Survey potential customers\n\n## Business Models\n\n### B2C (Business to Consumer)\n- E-commerce\n- Subscription services\n- Retail\n\n### B2B (Business to Business)\n- SaaS\n- Consulting\n- Manufacturing\n\n### Marketplace\n- Connect buyers and sellers\n- Take commission\n- Examples: Airbnb, Uber\n\n## Creating a Business Plan\n\n### Executive Summary\n- Business concept\n- Target market\n- Competitive advantage\n- Financial highlights\n\n### Market Analysis\n- Industry overview\n- Target customers\n- Competition\n- Market trends\n\n### Marketing Strategy\n- Positioning\n- Pricing\n- Distribution\n- Promotion\n\n### Financial Projections\n- Startup costs\n- Revenue forecast\n- Break-even analysis\n- Funding requirements',
    1, 75, ARRAY['Validate business ideas', 'Create business plans', 'Understand business models']);
  END LOOP;
END $$;

-- QuickBooks for Business
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'quickbooks-for-business';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'QuickBooks Setup', 'Getting started with QuickBooks',
    E'# QuickBooks Basics\n\n## Initial Setup\n\n### Company Information\n1. Company name and address\n2. Industry type\n3. Business structure\n4. Fiscal year\n\n### Chart of Accounts\n- **Assets**: What you own\n- **Liabilities**: What you owe\n- **Equity**: Owner investment\n- **Income**: Revenue\n- **Expenses**: Costs\n\n## Core Features\n\n### Invoicing\n1. Create invoice\n2. Add customer\n3. Add products/services\n4. Set payment terms\n5. Send to customer\n\n### Expense Tracking\n1. Connect bank accounts\n2. Categorize transactions\n3. Attach receipts\n4. Track vendors\n\n### Reports\n- Profit & Loss\n- Balance Sheet\n- Cash Flow Statement\n- Sales Reports\n- Expense Reports',
    1, 70, ARRAY['Set up QuickBooks', 'Create invoices', 'Track expenses']);
  END LOOP;
END $$;

-- Spanish for Beginners
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'spanish-for-beginners';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Spanish Basics', 'Getting started with Spanish',
    E'# Spanish Fundamentals\n\n## Alphabet and Pronunciation\n\n### Vowels\n- A: ah (father)\n- E: eh (bed)\n- I: ee (see)\n- O: oh (go)\n- U: oo (food)\n\n## Greetings\n\n- Hola - Hello\n- Buenos días - Good morning\n- Buenas tardes - Good afternoon\n- Buenas noches - Good evening\n- ¿Cómo estás? - How are you?\n- Bien, gracias - Good, thanks\n- Adiós - Goodbye\n\n## Basic Phrases\n\n- Por favor - Please\n- Gracias - Thank you\n- De nada - You''re welcome\n- Perdón - Excuse me\n- Sí - Yes\n- No - No\n\n## Numbers 1-20\n\n- 1: uno\n- 2: dos\n- 3: tres\n- 4: cuatro\n- 5: cinco\n- 10: diez\n- 20: veinte',
    1, 60, ARRAY['Pronounce Spanish correctly', 'Use basic greetings', 'Count to 20']);
  END LOOP;
END $$;

-- French Language Fundamentals
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'french-language-fundamentals';
  
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'French Basics', 'Introduction to French',
  E'# French Fundamentals\n\n## Pronunciation\n\n### Nasal Sounds\n- on, om: bonbon\n- an, en: enchant\n- in, ain: pain\n- un: brun\n\n## Greetings\n\n- Bonjour - Hello/Good morning\n- Bonsoir - Good evening\n- Salut - Hi (informal)\n- Au revoir - Goodbye\n- Comment allez-vous? - How are you? (formal)\n- Comment ça va? - How are you? (informal)\n\n## Basic Phrases\n\n- Merci - Thank you\n- De rien - You''re welcome\n- S''il vous plaît - Please (formal)\n- S''il te plaît - Please (informal)\n- Excusez-moi - Excuse me\n- Oui - Yes\n- Non - No\n\n## Articles\n\n### Definite (the)\n- le (masculine)\n- la (feminine)\n- les (plural)\n\n### Indefinite (a/an)\n- un (masculine)\n- une (feminine)\n- des (plural)',
  1, 60, ARRAY['Pronounce French sounds', 'Use basic French phrases', 'Understand articles']);
END $$;

-- Personal Fitness Training
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'personal-fitness-training';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Fitness Fundamentals', 'Getting started with fitness',
    E'# Fitness Basics\n\n## Types of Exercise\n\n### Cardio\n- Running, cycling, swimming\n- Improves heart health\n- Burns calories\n- 150 min/week moderate intensity\n\n### Strength Training\n- Builds muscle\n- Increases metabolism\n- Strengthens bones\n- 2-3x per week\n\n### Flexibility\n- Stretching\n- Yoga\n- Improves range of motion\n- Daily recommended\n\n## Basic Exercises\n\n### Bodyweight\n- Push-ups: Chest, arms\n- Squats: Legs, glutes\n- Lunges: Legs, balance\n- Planks: Core\n- Pull-ups: Back, arms\n\n### Proper Form\n1. Warm up first\n2. Control the movement\n3. Full range of motion\n4. Breathe properly\n5. Don''t lock joints\n\n## Creating a Routine\n\n### Beginner (3x/week)\n- Day 1: Full body\n- Day 2: Rest\n- Day 3: Full body\n- Day 4: Rest\n- Day 5: Full body\n\n### Sets and Reps\n- Beginners: 2-3 sets, 10-15 reps\n- Rest: 60-90 seconds between sets',
    1, 65, ARRAY['Understand exercise types', 'Perform basic exercises', 'Create workout routines']);
  END LOOP;
END $$;

-- Nutrition & Meal Planning
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'nutrition-meal-planning';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Nutrition Basics', 'Understanding nutrition',
    E'# Nutrition Fundamentals\n\n## Macronutrients\n\n### Protein\n- 4 calories per gram\n- Builds and repairs tissue\n- Sources: Meat, fish, eggs, legumes\n- Recommended: 0.8g per kg body weight\n\n### Carbohydrates\n- 4 calories per gram\n- Primary energy source\n- Complex: Whole grains, vegetables\n- Simple: Sugars, fruit\n\n### Fats\n- 9 calories per gram\n- Hormone production\n- Vitamin absorption\n- Sources: Nuts, avocado, olive oil\n\n## Micronutrients\n\n### Vitamins\n- A, B, C, D, E, K\n- Support body functions\n- Get from varied diet\n\n### Minerals\n- Iron, calcium, magnesium\n- Bone health, oxygen transport\n\n## Hydration\n- 8 glasses (2 liters) daily\n- More when exercising\n- Signs of dehydration:\n  - Dark urine\n  - Fatigue\n  - Dizziness\n\n## Meal Planning\n\n### Balanced Plate\n- 50% vegetables\n- 25% protein\n- 25% complex carbs\n- Healthy fats',
    1, 60, ARRAY['Understand macronutrients', 'Plan balanced meals', 'Stay hydrated']);
  END LOOP;
END $$;

-- Time Management & Productivity
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'time-management-productivity';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Time Management Fundamentals', 'Managing time effectively',
    E'# Time Management\n\n## Core Principles\n\n### Pareto Principle (80/20 Rule)\n- 80% of results from 20% of efforts\n- Focus on high-impact tasks\n- Eliminate low-value activities\n\n### Eisenhower Matrix\n\n**Urgent & Important**: Do first\n- Crises, deadlines\n\n**Important & Not Urgent**: Schedule\n- Planning, learning\n\n**Urgent & Not Important**: Delegate\n- Interruptions, some emails\n\n**Not Urgent & Not Important**: Eliminate\n- Time wasters, busy work\n\n## Planning Methods\n\n### Daily Planning\n1. List all tasks\n2. Prioritize top 3\n3. Time block calendar\n4. Review end of day\n\n### Weekly Planning\n- Set weekly goals\n- Schedule important tasks first\n- Leave buffer time\n- Review previous week\n\n## Productivity Techniques\n\n### Pomodoro Technique\n1. Work 25 minutes\n2. Break 5 minutes\n3. Repeat 4 times\n4. Long break 15-30 minutes\n\n### Time Blocking\n- Assign tasks to time slots\n- Group similar tasks\n- Include breaks\n- Protect focus time\n\n### Eat the Frog\n- Do hardest task first\n- Morning energy for important work\n- Momentum for rest of day',
    1, 60, ARRAY['Apply time management principles', 'Use prioritization methods', 'Implement productivity techniques']);
  END LOOP;
END $$;

-- Financial Analysis & Modeling
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'financial-analysis-modeling';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Financial Statement Analysis', 'Understanding financial statements',
    E'# Financial Statements\n\n## Income Statement\n\nShows profitability over period\n\n```\nRevenue\n- Cost of Goods Sold\n= Gross Profit\n- Operating Expenses\n= Operating Income\n- Interest & Taxes\n= Net Income\n```\n\n### Key Metrics\n- **Gross Margin**: (Gross Profit / Revenue) × 100\n- **Operating Margin**: (Operating Income / Revenue) × 100\n- **Net Margin**: (Net Income / Revenue) × 100\n\n## Balance Sheet\n\nSnapshot of financial position\n\n```\nASSETS = LIABILITIES + EQUITY\n\nAssets:\n- Current Assets (Cash, Inventory)\n- Fixed Assets (Property, Equipment)\n\nLiabilities:\n- Current Liabilities (Payables)\n- Long-term Debt\n\nEquity:\n- Owner''s Investment\n- Retained Earnings\n```\n\n### Key Ratios\n- **Current Ratio**: Current Assets / Current Liabilities\n- **Debt-to-Equity**: Total Debt / Total Equity\n- **ROE**: Net Income / Shareholders'' Equity\n\n## Cash Flow Statement\n\nTracks cash movements\n\n1. **Operating Activities**: Day-to-day operations\n2. **Investing Activities**: Asset purchases/sales\n3. **Financing Activities**: Debt, equity changes',
    1, 75, ARRAY['Read financial statements', 'Calculate financial ratios', 'Analyze company performance']);
  END LOOP;
END $$;

-- Network Security Fundamentals
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'network-security-fundamentals';
  
  FOR i IN 1..2 LOOP
    SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = i;
    
    INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
    (v_course_id, v_module_id, 'Network Security Basics', 'Introduction to network security',
    E'# Network Security Fundamentals\n\n## Security Principles\n\n### CIA Triad\n\n**Confidentiality**\n- Only authorized access\n- Encryption\n- Access controls\n\n**Integrity**\n- Data accuracy\n- Prevent unauthorized changes\n- Hashing\n\n**Availability**\n- Systems accessible when needed\n- Redundancy\n- DDoS protection\n\n## Common Threats\n\n### Malware\n- Viruses: Self-replicating\n- Trojans: Disguised as legitimate\n- Ransomware: Encrypts files\n- Spyware: Steals information\n\n### Network Attacks\n- Man-in-the-Middle: Intercept communication\n- DDoS: Overwhelm with traffic\n- Packet Sniffing: Capture network data\n- Port Scanning: Find vulnerabilities\n\n## Security Measures\n\n### Firewalls\n- Filter network traffic\n- Block unauthorized access\n- Types: Hardware, software, cloud\n\n### VPN\n- Encrypt internet connection\n- Hide IP address\n- Secure public WiFi\n\n### Intrusion Detection\n- Monitor network activity\n- Alert on suspicious behavior\n- Block attacks',
    1, 70, ARRAY['Understand security principles', 'Identify threats', 'Implement security measures']);
  END LOOP;
END $$;
