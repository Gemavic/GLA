/*
  # Curriculum for All Remaining Courses

  1. Courses Covered
    - Design: UI/UX, Figma, Photoshop, Graphic Design
    - Marketing: Digital Marketing, SEO, Social Media
    - Cloud & DevOps: AWS, Docker & Kubernetes
    - Cybersecurity: Ethical Hacking, Network Security
    - Mobile: React Native, Flutter & Dart
    - Business, Finance, Languages, Health, Personal Development, Photography

  2. Content Structure
    - Comprehensive modules for professional development
    - Industry-standard practices and tools
    - Project-based learning approach
*/

-- UI/UX Design Fundamentals
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'ui-ux-design-fundamentals';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Design Thinking and Research', 'User research, personas, and design thinking methodology', 1, 10),
  (v_course_id, 'Information Architecture', 'Organizing content and creating sitemaps', 2, 8),
  (v_course_id, 'Wireframing and Prototyping', 'Low and high-fidelity prototypes', 3, 12),
  (v_course_id, 'Visual Design Principles', 'Color theory, typography, and composition', 4, 10),
  (v_course_id, 'Interaction Design', 'Microinteractions, animations, and user flows', 5, 10),
  (v_course_id, 'Usability Testing', 'Testing methods and iterative design', 6, 8),
  (v_course_id, 'Responsive and Mobile Design', 'Designing for multiple devices', 7, 10),
  (v_course_id, 'Design Systems', 'Building scalable design systems', 8, 12);
END $$;

-- Figma UI Design
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'figma-ui-design';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Figma Basics', 'Interface, tools, and essential features', 1, 6),
  (v_course_id, 'Vector Design in Figma', 'Shapes, paths, and boolean operations', 2, 8),
  (v_course_id, 'Components and Variants', 'Reusable components and design systems', 3, 10),
  (v_course_id, 'Auto Layout Mastery', 'Responsive designs with Auto Layout', 4, 10),
  (v_course_id, 'Prototyping and Interactions', 'Interactive prototypes and user flows', 5, 12),
  (v_course_id, 'Collaboration and Handoff', 'Team workflows and developer handoff', 6, 6),
  (v_course_id, 'Advanced Techniques', 'Plugins, variables, and advanced features', 7, 10),
  (v_course_id, 'Complete UI Projects', 'Build mobile app and web interfaces', 8, 18);
END $$;

-- Adobe Photoshop Complete
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'adobe-photoshop-complete';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Photoshop Fundamentals', 'Interface, workspace, and basic tools', 1, 8),
  (v_course_id, 'Selections and Masking', 'Advanced selection and masking techniques', 2, 10),
  (v_course_id, 'Layers and Compositing', 'Layer management and photo compositing', 3, 12),
  (v_course_id, 'Color Correction', 'Color grading and adjustment techniques', 4, 10),
  (v_course_id, 'Retouching and Restoration', 'Photo retouching and restoration', 5, 12),
  (v_course_id, 'Text and Typography', 'Working with text and typography', 6, 8),
  (v_course_id, 'Digital Painting', 'Brushes and digital illustration', 7, 14),
  (v_course_id, 'Professional Projects', 'Complete real-world projects', 8, 16);
END $$;

-- Graphic Design Pro
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'graphic-design-pro';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Design Fundamentals', 'Principles, elements, and theory', 1, 10),
  (v_course_id, 'Typography Mastery', 'Type selection, pairing, and hierarchy', 2, 10),
  (v_course_id, 'Color Theory', 'Color psychology and application', 3, 8),
  (v_course_id, 'Logo Design', 'Creating memorable brand identities', 4, 14),
  (v_course_id, 'Brand Identity Systems', 'Complete brand identity development', 5, 16),
  (v_course_id, 'Print Design', 'Brochures, posters, and print materials', 6, 12),
  (v_course_id, 'Digital Design', 'Social media graphics and web assets', 7, 12),
  (v_course_id, 'Portfolio Development', 'Building a professional portfolio', 8, 10);
END $$;

-- Digital Marketing Mastery
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'digital-marketing-mastery';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Digital Marketing Foundations', 'Overview of digital marketing channels', 1, 8),
  (v_course_id, 'Content Marketing Strategy', 'Creating valuable content that converts', 2, 10),
  (v_course_id, 'Email Marketing', 'Building lists and effective campaigns', 3, 10),
  (v_course_id, 'Social Media Marketing', 'Organic and paid social strategies', 4, 12),
  (v_course_id, 'Search Engine Marketing', 'Google Ads and PPC campaigns', 5, 12),
  (v_course_id, 'Analytics and Tracking', 'Google Analytics and data-driven decisions', 6, 10),
  (v_course_id, 'Conversion Optimization', 'Landing pages and A/B testing', 7, 10),
  (v_course_id, 'Marketing Automation', 'Tools and workflows for scale', 8, 10);
END $$;

-- SEO Mastery Course
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'seo-mastery-course';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'SEO Fundamentals', 'How search engines work', 1, 6),
  (v_course_id, 'Keyword Research', 'Finding profitable keywords', 2, 10),
  (v_course_id, 'On-Page SEO', 'Optimizing content and HTML', 3, 12),
  (v_course_id, 'Technical SEO', 'Site speed, mobile, and structure', 4, 14),
  (v_course_id, 'Link Building', 'Building authority and backlinks', 5, 12),
  (v_course_id, 'Local SEO', 'Ranking in local search', 6, 8),
  (v_course_id, 'SEO Tools', 'Ahrefs, SEMrush, and analytics', 7, 10),
  (v_course_id, 'SEO Strategy', 'Complete SEO campaigns', 8, 10);
END $$;

-- Social Media Marketing Strategy
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'social-media-marketing-strategy';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Social Media Landscape', 'Platform overview and audience insights', 1, 6),
  (v_course_id, 'Content Strategy', 'Creating engaging social content', 2, 10),
  (v_course_id, 'Facebook and Instagram Marketing', 'Organic and paid strategies', 3, 12),
  (v_course_id, 'LinkedIn Marketing', 'B2B social selling', 4, 8),
  (v_course_id, 'Twitter and TikTok Strategies', 'Real-time and viral content', 5, 10),
  (v_course_id, 'Social Media Advertising', 'Running profitable ad campaigns', 6, 12),
  (v_course_id, 'Community Management', 'Building and engaging communities', 7, 8),
  (v_course_id, 'Social Media Analytics', 'Measuring ROI and performance', 8, 10);
END $$;

-- AWS Cloud Practitioner
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'aws-cloud-practitioner';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Cloud Computing Fundamentals', 'Introduction to cloud concepts', 1, 6),
  (v_course_id, 'AWS Core Services', 'EC2, S3, RDS, and VPC', 2, 12),
  (v_course_id, 'AWS Security', 'IAM, security groups, and best practices', 3, 10),
  (v_course_id, 'AWS Databases', 'RDS, DynamoDB, and database options', 4, 10),
  (v_course_id, 'AWS Networking', 'VPC, Route 53, and CloudFront', 5, 10),
  (v_course_id, 'AWS Storage', 'S3, EBS, EFS, and storage solutions', 6, 8),
  (v_course_id, 'AWS Architecture', 'Well-architected framework', 7, 10),
  (v_course_id, 'Exam Preparation', 'Practice tests and certification prep', 8, 10);
END $$;

-- Docker & Kubernetes Essentials
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'docker-kubernetes-essentials';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Containerization Basics', 'Introduction to containers and Docker', 1, 8),
  (v_course_id, 'Docker Fundamentals', 'Images, containers, and Dockerfile', 2, 10),
  (v_course_id, 'Docker Networking', 'Container networking and communication', 3, 8),
  (v_course_id, 'Docker Compose', 'Multi-container applications', 4, 10),
  (v_course_id, 'Kubernetes Architecture', 'Pods, nodes, and clusters', 5, 12),
  (v_course_id, 'Kubernetes Deployments', 'Managing application deployments', 6, 12),
  (v_course_id, 'Kubernetes Services', 'Service discovery and load balancing', 7, 10),
  (v_course_id, 'Production Kubernetes', 'Monitoring, logging, and security', 8, 14);
END $$;

-- Ethical Hacking & Penetration Testing
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'ethical-hacking-penetration-testing';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Introduction to Ethical Hacking', 'Legal and ethical considerations', 1, 6),
  (v_course_id, 'Reconnaissance and Footprinting', 'Information gathering techniques', 2, 10),
  (v_course_id, 'Scanning and Enumeration', 'Network scanning and enumeration', 3, 12),
  (v_course_id, 'Vulnerability Assessment', 'Identifying security weaknesses', 4, 10),
  (v_course_id, 'Exploitation Techniques', 'Common attack vectors', 5, 14),
  (v_course_id, 'Web Application Security', 'OWASP Top 10 and web vulnerabilities', 6, 12),
  (v_course_id, 'Wireless Network Security', 'WiFi hacking and security', 7, 10),
  (v_course_id, 'Reporting and Remediation', 'Professional penetration testing reports', 8, 8);
END $$;

-- Network Security Fundamentals
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'network-security-fundamentals';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Network Basics', 'TCP/IP, OSI model, and protocols', 1, 10),
  (v_course_id, 'Network Threats', 'Common attacks and vulnerabilities', 2, 8),
  (v_course_id, 'Firewalls and IDS', 'Network security devices', 3, 12),
  (v_course_id, 'VPNs and Encryption', 'Secure communications', 4, 10),
  (v_course_id, 'Network Monitoring', 'Tools and techniques', 5, 10),
  (v_course_id, 'Wireless Security', 'Securing wireless networks', 6, 8),
  (v_course_id, 'Network Access Control', 'NAC and 802.1X', 7, 8),
  (v_course_id, 'Security Architecture', 'Designing secure networks', 8, 12);
END $$;

-- React Native Mobile Development
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'react-native-mobile-development';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'React Native Basics', 'Setup and core concepts', 1, 8),
  (v_course_id, 'Components and Styling', 'Building UI components', 2, 12),
  (v_course_id, 'Navigation', 'React Navigation and routing', 3, 10),
  (v_course_id, 'State Management', 'Redux, Context API, and state', 4, 12),
  (v_course_id, 'API Integration', 'Fetching data and async operations', 5, 10),
  (v_course_id, 'Native Features', 'Camera, location, and device APIs', 6, 12),
  (v_course_id, 'Performance Optimization', 'Optimizing mobile apps', 7, 8),
  (v_course_id, 'Publishing Apps', 'App Store and Play Store deployment', 8, 10);
END $$;

-- Flutter & Dart Complete Guide
DO $$
DECLARE v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'flutter-dart-complete-guide';
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Dart Programming', 'Dart language fundamentals', 1, 10),
  (v_course_id, 'Flutter Basics', 'Widgets and Flutter architecture', 2, 12),
  (v_course_id, 'Layouts and UI', 'Building beautiful interfaces', 3, 14),
  (v_course_id, 'State Management', 'Provider, Riverpod, and BLoC', 4, 14),
  (v_course_id, 'Navigation and Routing', 'Multi-screen applications', 5, 10),
  (v_course_id, 'Data Persistence', 'SQLite, shared preferences, and more', 6, 10),
  (v_course_id, 'Firebase Integration', 'Authentication, Firestore, and cloud', 7, 12),
  (v_course_id, 'Publishing Flutter Apps', 'Deployment and distribution', 8, 10);
END $$;

-- Additional Courses (shorter modules)
DO $$
BEGIN
  -- Advanced React & TypeScript
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Advanced React Patterns', 'Hooks, Context, and advanced patterns', 1, 12 FROM courses WHERE slug = 'advanced-react-typescript'
  UNION ALL
  SELECT id, 'TypeScript Deep Dive', 'Advanced TypeScript features', 2, 10 FROM courses WHERE slug = 'advanced-react-typescript'
  UNION ALL
  SELECT id, 'State Management', 'Redux, Zustand, and state patterns', 3, 12 FROM courses WHERE slug = 'advanced-react-typescript'
  UNION ALL
  SELECT id, 'Testing React Apps', 'Jest, Testing Library, and E2E', 4, 10 FROM courses WHERE slug = 'advanced-react-typescript'
  UNION ALL
  SELECT id, 'Performance Optimization', 'React performance best practices', 5, 10 FROM courses WHERE slug = 'advanced-react-typescript'
  UNION ALL
  SELECT id, 'Advanced Projects', 'Build complex React applications', 6, 16 FROM courses WHERE slug = 'advanced-react-typescript';

  -- Node.js Backend Development
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Node.js Fundamentals', 'Core Node.js concepts and modules', 1, 10 FROM courses WHERE slug = 'nodejs-backend-development'
  UNION ALL
  SELECT id, 'Express.js Framework', 'Building REST APIs with Express', 2, 12 FROM courses WHERE slug = 'nodejs-backend-development'
  UNION ALL
  SELECT id, 'Database Integration', 'MongoDB, PostgreSQL with Node.js', 3, 12 FROM courses WHERE slug = 'nodejs-backend-development'
  UNION ALL
  SELECT id, 'Authentication & Security', 'JWT, OAuth, and security best practices', 4, 10 FROM courses WHERE slug = 'nodejs-backend-development'
  UNION ALL
  SELECT id, 'Real-time Applications', 'WebSockets and Socket.io', 5, 10 FROM courses WHERE slug = 'nodejs-backend-development'
  UNION ALL
  SELECT id, 'Testing and Deployment', 'Unit tests, integration tests, CI/CD', 6, 12 FROM courses WHERE slug = 'nodejs-backend-development';

  -- Django Web Framework
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Django Basics', 'Django setup and core concepts', 1, 10 FROM courses WHERE slug = 'django-web-framework'
  UNION ALL
  SELECT id, 'Models and Databases', 'Django ORM and database models', 2, 12 FROM courses WHERE slug = 'django-web-framework'
  UNION ALL
  SELECT id, 'Views and Templates', 'Rendering dynamic content', 3, 12 FROM courses WHERE slug = 'django-web-framework'
  UNION ALL
  SELECT id, 'Forms and Validation', 'User input handling', 4, 10 FROM courses WHERE slug = 'django-web-framework'
  UNION ALL
  SELECT id, 'Django REST Framework', 'Building APIs with Django', 5, 14 FROM courses WHERE slug = 'django-web-framework'
  UNION ALL
  SELECT id, 'Deployment', 'Production Django deployment', 6, 10 FROM courses WHERE slug = 'django-web-framework';

  -- Vue.js 3 Complete Course
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Vue 3 Fundamentals', 'Composition API and core concepts', 1, 10 FROM courses WHERE slug = 'vuejs-3-complete-course'
  UNION ALL
  SELECT id, 'Components and Props', 'Building reusable components', 2, 10 FROM courses WHERE slug = 'vuejs-3-complete-course'
  UNION ALL
  SELECT id, 'State Management with Pinia', 'Managing application state', 3, 12 FROM courses WHERE slug = 'vuejs-3-complete-course'
  UNION ALL
  SELECT id, 'Vue Router', 'Single page applications', 4, 10 FROM courses WHERE slug = 'vuejs-3-complete-course'
  UNION ALL
  SELECT id, 'Advanced Vue', 'Composables, plugins, and advanced patterns', 5, 12 FROM courses WHERE slug = 'vuejs-3-complete-course'
  UNION ALL
  SELECT id, 'Testing Vue Apps', 'Vitest and component testing', 6, 8 FROM courses WHERE slug = 'vuejs-3-complete-course';

  -- Entrepreneurship Essentials
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Startup Fundamentals', 'Ideation and validation', 1, 8 FROM courses WHERE slug = 'entrepreneurship-essentials'
  UNION ALL
  SELECT id, 'Business Planning', 'Creating effective business plans', 2, 10 FROM courses WHERE slug = 'entrepreneurship-essentials'
  UNION ALL
  SELECT id, 'Funding and Finance', 'Raising capital and financial management', 3, 12 FROM courses WHERE slug = 'entrepreneurship-essentials'
  UNION ALL
  SELECT id, 'Marketing for Startups', 'Growth hacking and customer acquisition', 4, 10 FROM courses WHERE slug = 'entrepreneurship-essentials'
  UNION ALL
  SELECT id, 'Building Teams', 'Hiring and team management', 5, 8 FROM courses WHERE slug = 'entrepreneurship-essentials'
  UNION ALL
  SELECT id, 'Scaling Your Business', 'Growth strategies and operations', 6, 10 FROM courses WHERE slug = 'entrepreneurship-essentials';

  -- Financial Analysis & Modeling
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Financial Statement Analysis', 'Reading and analyzing statements', 1, 10 FROM courses WHERE slug = 'financial-analysis-modeling'
  UNION ALL
  SELECT id, 'Excel for Finance', 'Advanced Excel for financial modeling', 2, 12 FROM courses WHERE slug = 'financial-analysis-modeling'
  UNION ALL
  SELECT id, 'Valuation Techniques', 'DCF, multiples, and valuation', 3, 14 FROM courses WHERE slug = 'financial-analysis-modeling'
  UNION ALL
  SELECT id, 'Financial Modeling', 'Building comprehensive models', 4, 16 FROM courses WHERE slug = 'financial-analysis-modeling'
  UNION ALL
  SELECT id, 'Investment Banking', 'M&A modeling and LBO', 5, 12 FROM courses WHERE slug = 'financial-analysis-modeling';

  -- Languages, Health, Personal Development, Photography
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Spanish Basics', 'Grammar, vocabulary, and pronunciation', 1, 15 FROM courses WHERE slug = 'spanish-for-beginners'
  UNION ALL
  SELECT id, 'Conversation Practice', 'Speaking and listening skills', 2, 15 FROM courses WHERE slug = 'spanish-for-beginners'
  UNION ALL
  SELECT id, 'Reading and Writing', 'Text comprehension and composition', 3, 10 FROM courses WHERE slug = 'spanish-for-beginners';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'French Fundamentals', 'Core grammar and vocabulary', 1, 15 FROM courses WHERE slug = 'french-language-fundamentals'
  UNION ALL
  SELECT id, 'French Conversation', 'Speaking practice and pronunciation', 2, 15 FROM courses WHERE slug = 'french-language-fundamentals';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Fitness Foundations', 'Exercise science and programming', 1, 12 FROM courses WHERE slug = 'personal-fitness-training'
  UNION ALL
  SELECT id, 'Strength Training', 'Weightlifting and muscle building', 2, 12 FROM courses WHERE slug = 'personal-fitness-training'
  UNION ALL
  SELECT id, 'Cardio and Conditioning', 'Endurance and cardiovascular health', 3, 10 FROM courses WHERE slug = 'personal-fitness-training';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Nutrition Science', 'Macronutrients and micronutrients', 1, 10 FROM courses WHERE slug = 'nutrition-meal-planning'
  UNION ALL
  SELECT id, 'Meal Planning', 'Creating balanced meal plans', 2, 12 FROM courses WHERE slug = 'nutrition-meal-planning'
  UNION ALL
  SELECT id, 'Special Diets', 'Vegetarian, keto, and dietary restrictions', 3, 10 FROM courses WHERE slug = 'nutrition-meal-planning';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Time Management Principles', 'Productivity systems and habits', 1, 8 FROM courses WHERE slug = 'time-management-productivity'
  UNION ALL
  SELECT id, 'Goal Setting', 'Effective goal-setting frameworks', 2, 6 FROM courses WHERE slug = 'time-management-productivity'
  UNION ALL
  SELECT id, 'Focus and Deep Work', 'Eliminating distractions', 3, 8 FROM courses WHERE slug = 'time-management-productivity';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Camera Fundamentals', 'Exposure, aperture, shutter speed', 1, 12 FROM courses WHERE slug = 'professional-photography-course'
  UNION ALL
  SELECT id, 'Composition', 'Framing and visual storytelling', 2, 10 FROM courses WHERE slug = 'professional-photography-course'
  UNION ALL
  SELECT id, 'Lighting Techniques', 'Natural and artificial lighting', 3, 12 FROM courses WHERE slug = 'professional-photography-course'
  UNION ALL
  SELECT id, 'Post-Processing', 'Lightroom and photo editing', 4, 14 FROM courses WHERE slug = 'professional-photography-course';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'Premiere Pro Basics', 'Interface and essential tools', 1, 10 FROM courses WHERE slug = 'video-editing-premiere-pro'
  UNION ALL
  SELECT id, 'Editing Techniques', 'Cutting, transitions, and pacing', 2, 14 FROM courses WHERE slug = 'video-editing-premiere-pro'
  UNION ALL
  SELECT id, 'Color Grading', 'Lumetri and color correction', 3, 12 FROM courses WHERE slug = 'video-editing-premiere-pro'
  UNION ALL
  SELECT id, 'Audio Editing', 'Sound design and mixing', 4, 10 FROM courses WHERE slug = 'video-editing-premiere-pro'
  UNION ALL
  SELECT id, 'Export and Delivery', 'Rendering for different platforms', 5, 6 FROM courses WHERE slug = 'video-editing-premiere-pro';

  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  SELECT id, 'QuickBooks Setup', 'Company setup and basics', 1, 8 FROM courses WHERE slug = 'quickbooks-for-business'
  UNION ALL
  SELECT id, 'Daily Transactions', 'Sales, expenses, and banking', 2, 10 FROM courses WHERE slug = 'quickbooks-for-business'
  UNION ALL
  SELECT id, 'Financial Reports', 'P&L, balance sheets, and reports', 3, 10 FROM courses WHERE slug = 'quickbooks-for-business'
  UNION ALL
  SELECT id, 'Payroll and Taxes', 'Managing payroll and tax obligations', 4, 10 FROM courses WHERE slug = 'quickbooks-for-business';
END $$;
