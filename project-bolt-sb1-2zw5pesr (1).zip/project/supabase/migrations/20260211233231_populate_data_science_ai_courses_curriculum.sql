/*
  # Data Science & AI Courses Curriculum Content

  1. Courses Covered
    - Python for Data Science
    - Machine Learning A-Z
    - SQL & Database Design
    - Deep Learning with TensorFlow
    - Natural Language Processing

  2. Content Structure
    - Comprehensive modules for each course
    - Hands-on projects and real-world applications
    - Industry-relevant skills and techniques

  3. Notes
    - Content designed for career-ready skills
    - Progressive difficulty from fundamentals to advanced
*/

-- Python for Data Science
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'python-for-data-science';
  
  -- Module 1
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  VALUES (v_course_id, 'Python Programming Basics', 'Master Python fundamentals for data science', 1, 10)
  RETURNING id INTO v_module_id;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Python Environment Setup', 'Setting up your Python development environment', 
  E'# Python Environment Setup\n\n## Installing Python\n\n### Windows\n1. Download Python from python.org\n2. Run installer with "Add to PATH" checked\n3. Verify: `python --version`\n\n### Mac/Linux\n```bash\n# Using Homebrew (Mac)\nbrew install python3\n\n# Using apt (Ubuntu/Debian)\nsudo apt update\nsudo apt install python3 python3-pip\n```\n\n## Setting Up Virtual Environments\n\n```bash\n# Create virtual environment\npython -m venv myenv\n\n# Activate (Windows)\nmyenv\\Scripts\\activate\n\n# Activate (Mac/Linux)\nsource myenv/bin/activate\n\n# Install packages\npip install numpy pandas matplotlib jupyter\n\n# Save dependencies\npip freeze > requirements.txt\n```\n\n## Jupyter Notebook\n\n```bash\n# Install\npip install jupyter\n\n# Launch\njupyter notebook\n```\n\n## Your First Python Script\n\n```python\n# hello.py\nprint("Hello, Data Science!")\n\nname = input("What is your name? ")\nprint(f"Welcome, {name}!")\n```',
  1, 45, ARRAY['Install Python and essential tools', 'Set up virtual environments', 'Use Jupyter Notebook for data analysis']),
  
  (v_course_id, v_module_id, 'Python Data Types and Variables', 'Understanding Python data structures', 
  E'# Python Data Types and Variables\n\n## Variables and Assignment\n\n```python\n# Numbers\nage = 25\nprice = 19.99\ncomplex_num = 3 + 4j\n\n# Strings\nname = "Alice"\nmessage = ''Single quotes work too''\nmultiline = """This is\na multiline\nstring"""\n\n# Boolean\nis_active = True\nhas_permission = False\n\n# None\nresult = None\n```\n\n## Data Structures\n\n### Lists (Ordered, Mutable)\n```python\nfruits = ["apple", "banana", "cherry"]\nnumbers = [1, 2, 3, 4, 5]\nmixed = [1, "two", 3.0, True]\n\n# Accessing elements\nprint(fruits[0])  # "apple"\nprint(fruits[-1])  # "cherry" (last item)\n\n# Slicing\nprint(fruits[0:2])  # ["apple", "banana"]\n\n# Modifying\nfruits.append("orange")\nfruits.remove("banana")\nfruits[0] = "avocado"\n\n# Methods\nfruits.sort()\nfruits.reverse()\nlen(fruits)\n```\n\n### Tuples (Ordered, Immutable)\n```python\ncoordinates = (10, 20)\nrgb = (255, 128, 0)\n\n# Unpacking\nx, y = coordinates\n```\n\n### Dictionaries (Key-Value Pairs)\n```python\nperson = {\n    "name": "Alice",\n    "age": 30,\n    "city": "New York"\n}\n\n# Accessing\nprint(person["name"])\nprint(person.get("age"))\n\n# Modifying\nperson["age"] = 31\nperson["email"] = "alice@example.com"\n\n# Methods\nperson.keys()\nperson.values()\nperson.items()\n```\n\n### Sets (Unordered, Unique)\n```python\nunique_numbers = {1, 2, 3, 4, 5}\n\n# Operations\nunique_numbers.add(6)\nunique_numbers.remove(3)\n\n# Set operations\na = {1, 2, 3}\nb = {3, 4, 5}\nprint(a.union(b))  # {1, 2, 3, 4, 5}\nprint(a.intersection(b))  # {3}\n```',
  2, 60, ARRAY['Work with Python data types', 'Manipulate lists, dictionaries, and sets', 'Choose appropriate data structures']),
  
  (v_course_id, v_module_id, 'Control Flow and Functions', 'Program logic and reusable code', 
  E'# Control Flow and Functions\n\n## Conditional Statements\n\n```python\nage = 18\n\nif age >= 18:\n    print("Adult")\nelif age >= 13:\n    print("Teenager")\nelse:\n    print("Child")\n\n# Ternary operator\nstatus = "Adult" if age >= 18 else "Minor"\n```\n\n## Loops\n\n### For Loops\n```python\n# Iterate over list\nfruits = ["apple", "banana", "cherry"]\nfor fruit in fruits:\n    print(fruit)\n\n# Range\nfor i in range(5):  # 0, 1, 2, 3, 4\n    print(i)\n\nfor i in range(1, 10, 2):  # 1, 3, 5, 7, 9\n    print(i)\n\n# Enumerate (with index)\nfor idx, fruit in enumerate(fruits):\n    print(f"{idx}: {fruit}")\n\n# Dictionary iteration\nperson = {"name": "Alice", "age": 30}\nfor key, value in person.items():\n    print(f"{key}: {value}")\n```\n\n### While Loops\n```python\ncount = 0\nwhile count < 5:\n    print(count)\n    count += 1\n\n# Break and continue\nwhile True:\n    user_input = input("Enter q to quit: ")\n    if user_input == "q":\n        break\n```\n\n## Functions\n\n```python\n# Basic function\ndef greet(name):\n    return f"Hello, {name}!"\n\nprint(greet("Alice"))\n\n# Default parameters\ndef power(base, exponent=2):\n    return base ** exponent\n\nprint(power(5))  # 25\nprint(power(5, 3))  # 125\n\n# Multiple return values\ndef get_stats(numbers):\n    return sum(numbers), len(numbers), sum(numbers)/len(numbers)\n\ntotal, count, avg = get_stats([1, 2, 3, 4, 5])\n\n# Variable arguments\ndef sum_all(*numbers):\n    return sum(numbers)\n\nprint(sum_all(1, 2, 3, 4, 5))  # 15\n\n# Keyword arguments\ndef create_profile(**kwargs):\n    return kwargs\n\nprofile = create_profile(name="Alice", age=30, city="NYC")\n```\n\n## Lambda Functions\n\n```python\n# Anonymous functions\nsquare = lambda x: x ** 2\nprint(square(5))  # 25\n\n# With map/filter\nnumbers = [1, 2, 3, 4, 5]\nsquared = list(map(lambda x: x**2, numbers))\neven = list(filter(lambda x: x % 2 == 0, numbers))\n```',
  3, 75, ARRAY['Write conditional logic', 'Use loops effectively', 'Create reusable functions']),
  
  (v_course_id, v_module_id, 'File Handling and Error Management', 'Working with files and exceptions', 
  E'# File Handling and Error Management\n\n## Reading Files\n\n```python\n# Read entire file\nwith open("data.txt", "r") as file:\n    content = file.read()\n    print(content)\n\n# Read line by line\nwith open("data.txt", "r") as file:\n    for line in file:\n        print(line.strip())\n\n# Read all lines into list\nwith open("data.txt", "r") as file:\n    lines = file.readlines()\n```\n\n## Writing Files\n\n```python\n# Write (overwrites)\nwith open("output.txt", "w") as file:\n    file.write("Hello World\\n")\n    file.write("Second line\\n")\n\n# Append\nwith open("output.txt", "a") as file:\n    file.write("Appended line\\n")\n\n# Write multiple lines\nlines = ["Line 1\\n", "Line 2\\n", "Line 3\\n"]\nwith open("output.txt", "w") as file:\n    file.writelines(lines)\n```\n\n## CSV Files\n\n```python\nimport csv\n\n# Read CSV\nwith open("data.csv", "r") as file:\n    reader = csv.reader(file)\n    for row in reader:\n        print(row)\n\n# Read with DictReader\nwith open("data.csv", "r") as file:\n    reader = csv.DictReader(file)\n    for row in reader:\n        print(row["name"], row["age"])\n\n# Write CSV\ndata = [\n    ["Name", "Age", "City"],\n    ["Alice", "30", "NYC"],\n    ["Bob", "25", "LA"]\n]\n\nwith open("output.csv", "w", newline="") as file:\n    writer = csv.writer(file)\n    writer.writerows(data)\n```\n\n## JSON Files\n\n```python\nimport json\n\n# Read JSON\nwith open("data.json", "r") as file:\n    data = json.load(file)\n\n# Write JSON\ndata = {\n    "name": "Alice",\n    "age": 30,\n    "skills": ["Python", "SQL", "ML"]\n}\n\nwith open("output.json", "w") as file:\n    json.dump(data, file, indent=2)\n```\n\n## Exception Handling\n\n```python\n# Try-except\ntry:\n    number = int(input("Enter a number: "))\n    result = 100 / number\n    print(f"Result: {result}")\nexcept ValueError:\n    print("Invalid input! Please enter a number.")\nexcept ZeroDivisionError:\n    print("Cannot divide by zero!")\nexcept Exception as e:\n    print(f"An error occurred: {e}")\nelse:\n    print("Operation successful!")\nfinally:\n    print("Execution completed.")\n\n# Raising exceptions\ndef validate_age(age):\n    if age < 0:\n        raise ValueError("Age cannot be negative")\n    if age > 150:\n        raise ValueError("Age seems invalid")\n    return True\n\ntry:\n    validate_age(-5)\nexcept ValueError as e:\n    print(e)\n```',
  4, 70, ARRAY['Read and write various file formats', 'Handle exceptions gracefully', 'Work with CSV and JSON data']);

  -- Module 2: NumPy for Data Analysis
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  VALUES (v_course_id, 'NumPy for Numerical Computing', 'Master NumPy arrays and numerical operations', 2, 8);

  -- Module 3: Pandas for Data Manipulation
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  VALUES (v_course_id, 'Pandas for Data Manipulation', 'Data cleaning, transformation, and analysis with Pandas', 3, 12);

  -- Module 4: Data Visualization
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  VALUES (v_course_id, 'Data Visualization', 'Create compelling visualizations with Matplotlib and Seaborn', 4, 10);

  -- Module 5: Statistical Analysis
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  VALUES (v_course_id, 'Statistical Analysis with Python', 'Descriptive and inferential statistics', 5, 8);

  -- Module 6: Real-World Projects
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours)
  VALUES (v_course_id, 'Data Science Projects', 'Complete end-to-end data science projects', 6, 15);
END $$;

-- Machine Learning A-Z
DO $$
DECLARE
  v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'machine-learning-a-z';
  
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Introduction to Machine Learning', 'ML fundamentals, types, and applications', 1, 6),
  (v_course_id, 'Data Preprocessing', 'Cleaning and preparing data for ML models', 2, 8),
  (v_course_id, 'Supervised Learning - Regression', 'Linear, polynomial, and advanced regression techniques', 3, 12),
  (v_course_id, 'Supervised Learning - Classification', 'Logistic regression, SVM, decision trees, and ensemble methods', 4, 14),
  (v_course_id, 'Unsupervised Learning', 'Clustering, dimensionality reduction, and association rules', 5, 10),
  (v_course_id, 'Model Evaluation and Optimization', 'Cross-validation, hyperparameter tuning, and performance metrics', 6, 8),
  (v_course_id, 'Deep Learning Fundamentals', 'Neural networks, CNNs, and RNNs', 7, 16),
  (v_course_id, 'ML Projects and Deployment', 'Build and deploy production ML models', 8, 15);
END $$;

-- Deep Learning with TensorFlow
DO $$
DECLARE
  v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'deep-learning-tensorflow';
  
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'TensorFlow Basics', 'TensorFlow fundamentals, tensors, and operations', 1, 8),
  (v_course_id, 'Neural Networks from Scratch', 'Build and train neural networks', 2, 10),
  (v_course_id, 'Convolutional Neural Networks', 'Image classification and computer vision', 3, 12),
  (v_course_id, 'Recurrent Neural Networks', 'Sequence modeling and time series', 4, 12),
  (v_course_id, 'Transfer Learning', 'Leverage pre-trained models', 5, 8),
  (v_course_id, 'Generative Models', 'GANs, VAEs, and generative AI', 6, 14),
  (v_course_id, 'Model Deployment', 'Deploy models with TensorFlow Serving', 7, 10);
END $$;

-- Natural Language Processing
DO $$
DECLARE
  v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'natural-language-processing';
  
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'NLP Fundamentals', 'Text processing and linguistic basics', 1, 6),
  (v_course_id, 'Text Preprocessing', 'Tokenization, stemming, lemmatization', 2, 8),
  (v_course_id, 'Feature Engineering for Text', 'Bag of words, TF-IDF, word embeddings', 3, 10),
  (v_course_id, 'Text Classification', 'Sentiment analysis and document categorization', 4, 12),
  (v_course_id, 'Named Entity Recognition', 'Extract entities from text', 5, 8),
  (v_course_id, 'Sequence-to-Sequence Models', 'Machine translation and text generation', 6, 14),
  (v_course_id, 'Transformers and BERT', 'Modern NLP with attention mechanisms', 7, 16),
  (v_course_id, 'NLP Applications', 'Chatbots, summarization, and question answering', 8, 12);
END $$;

-- SQL & Database Design
DO $$
DECLARE
  v_course_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'sql-database-design';
  
  INSERT INTO course_modules (course_id, title, description, order_index, duration_hours) VALUES
  (v_course_id, 'Database Fundamentals', 'Introduction to databases and SQL', 1, 6),
  (v_course_id, 'SQL Basics', 'SELECT, INSERT, UPDATE, DELETE operations', 2, 8),
  (v_course_id, 'Advanced Queries', 'JOINs, subqueries, and complex queries', 3, 12),
  (v_course_id, 'Database Design', 'Normalization, ERD, and schema design', 4, 10),
  (v_course_id, 'Indexes and Performance', 'Query optimization and indexing strategies', 5, 8),
  (v_course_id, 'Transactions and Concurrency', 'ACID properties and transaction management', 6, 8),
  (v_course_id, 'Stored Procedures and Triggers', 'Automate database operations', 7, 10),
  (v_course_id, 'Database Administration', 'Backup, recovery, and security', 8, 8);
END $$;
