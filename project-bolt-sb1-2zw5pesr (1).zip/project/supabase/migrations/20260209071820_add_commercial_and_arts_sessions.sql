/*
  # Add Commercial and Arts Tutorial Sessions

  1. New Sessions
    - Add commercial stream sessions (Accounting, Economics, Business Studies, Commerce)
    - Add arts stream sessions (Literature, Government, History, Geography, CRS)
    - Cover multiple exam types (GCE O/L, A/L, Cambridge, WAEC, NECO, JAMB)
    - Include sessions for both Nigerian and international students

  2. Subject Areas
    - Commercial: Accounting, Economics, Business Studies, Commerce, Marketing
    - Arts: Literature in English, Government, History, Geography, CRS/IRK, French
*/

-- Insert Commercial Stream Sessions
INSERT INTO tutorial_sessions (program_id, title, description, subjects, schedule, price, currency, max_students, start_date, end_date) VALUES
  (
    (SELECT id FROM tutorial_programs WHERE name = 'GCE O/L' LIMIT 1),
    'GCE O/L Commerce Stream - 2026 Cohort',
    'Complete O Level preparation for Commerce subjects. Expert tutors covering Accounting principles, Economics fundamentals, and Business Studies essentials.',
    ARRAY['Accounting', 'Economics', 'Business Studies', 'Commerce', 'Mathematics', 'English Language'],
    'Monday to Friday, 2:00 PM - 5:00 PM WAT',
    80000,
    'NGN',
    25,
    '2026-03-01',
    '2027-02-28'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'GCE O/L' LIMIT 1),
    'GCE O/L Arts Stream - 2026 Cohort',
    'Comprehensive Arts subjects preparation including Literature, History, and Geography. Develop critical thinking and analytical skills.',
    ARRAY['Literature in English', 'History', 'Geography', 'Government', 'English Language', 'CRS'],
    'Monday to Friday, 10:00 AM - 1:00 PM WAT',
    75000,
    'NGN',
    30,
    '2026-03-01',
    '2027-02-28'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'GCE A/L' LIMIT 1),
    'GCE A Level Arts & Humanities - 2026',
    'Advanced level Arts preparation covering Literature, History, and related subjects. Perfect for university-bound students.',
    ARRAY['Literature in English', 'History', 'Geography', 'Economics'],
    'Tuesday, Thursday, Saturday 3:00 PM - 6:00 PM',
    90000,
    'NGN',
    20,
    '2026-03-01',
    '2027-11-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'Cambridge AS/A Level' LIMIT 1),
    'Cambridge A Level Commerce - March 2026',
    'Rigorous Cambridge A Level Commerce preparation. Covers Accounting, Economics, and Business Studies with international standards.',
    ARRAY['Accounting', 'Economics', 'Business Studies', 'Mathematics'],
    'Weekdays 2:00 PM - 5:00 PM, Saturdays 9:00 AM - 1:00 PM',
    115000,
    'NGN',
    20,
    '2026-03-15',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'JUPEB' LIMIT 1),
    'JUPEB Arts Programme 2026/2027',
    'JUPEB direct entry for Arts students. Covers Government, Economics, Literature, and Use of English for university progression.',
    ARRAY['Government', 'Economics', 'Literature in English', 'Use of English'],
    'Monday to Friday, 9:00 AM - 4:00 PM',
    240000,
    'NGN',
    30,
    '2026-09-01',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'JUPEB' LIMIT 1),
    'JUPEB Commercial Programme 2026/2027',
    'JUPEB Commercial/Management Sciences stream. Expert instruction in Accounting, Economics, and related subjects.',
    ARRAY['Accounting', 'Economics', 'Government', 'Use of English'],
    'Monday to Friday, 9:00 AM - 4:00 PM',
    245000,
    'NGN',
    25,
    '2026-09-01',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'IJMB' LIMIT 1),
    'IJMB Arts & Social Sciences - 2026',
    'Fast-track IJMB for Arts students. Covers Literature, Government, Economics with comprehensive exam preparation.',
    ARRAY['Literature in English', 'Government', 'Economics'],
    'Monday to Saturday, 8:00 AM - 3:00 PM',
    175000,
    'NGN',
    35,
    '2026-10-01',
    '2027-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'WAEC' LIMIT 1),
    'WAEC Commercial Subjects - May/June 2026',
    'Specialized WAEC preparation for Commercial students. Focus on Accounting, Commerce, Economics, and Business Studies.',
    ARRAY['Accounting', 'Commerce', 'Economics', 'Business Studies', 'Mathematics', 'English Language'],
    'Weekdays 3:00 PM - 6:00 PM, Saturdays 10:00 AM - 2:00 PM',
    58000,
    'NGN',
    35,
    '2026-02-01',
    '2026-05-15'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'WAEC' LIMIT 1),
    'WAEC Arts Subjects - May/June 2026',
    'Complete WAEC Arts preparation covering Literature, Government, History, Geography, and CRS with experienced teachers.',
    ARRAY['Literature in English', 'Government', 'History', 'Geography', 'CRS', 'English Language'],
    'Weekdays 2:00 PM - 5:00 PM, Saturdays 9:00 AM - 1:00 PM',
    55000,
    'NGN',
    40,
    '2026-02-01',
    '2026-05-15'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NECO' LIMIT 1),
    'NECO Commercial Class - June/July 2026',
    'Intensive NECO commercial subjects coaching. Expert guidance in Accounting, Economics, Commerce, and Business Studies.',
    ARRAY['Accounting', 'Commerce', 'Economics', 'Business Studies', 'English Language', 'Mathematics'],
    'Tuesday, Thursday, Saturday 2:00 PM - 5:00 PM',
    53000,
    'NGN',
    30,
    '2026-02-15',
    '2026-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'NECO' LIMIT 1),
    'NECO Arts & Humanities - June/July 2026',
    'Comprehensive NECO Arts preparation. Quality instruction in Literature, History, Government, and related subjects.',
    ARRAY['Literature in English', 'Government', 'History', 'Geography', 'CRS', 'English Language'],
    'Monday, Wednesday, Friday 3:00 PM - 6:00 PM',
    52000,
    'NGN',
    35,
    '2026-02-15',
    '2026-06-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'JAMB UTME' LIMIT 1),
    'JAMB UTME 2026 - Arts & Social Sciences',
    'Targeted JAMB preparation for Arts students. Covers Use of English, Literature, Government, and CRS/IRK.',
    ARRAY['Use of English', 'Literature in English', 'Government', 'CRS'],
    'Weekdays 4:00 PM - 7:00 PM, Sundays 1:00 PM - 4:00 PM',
    33000,
    'NGN',
    50,
    '2026-01-15',
    '2026-04-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'JAMB UTME' LIMIT 1),
    'JAMB UTME 2026 - Commercial Class',
    'Intensive JAMB Commercial/Management prep. Focus on Use of English, Accounting, Economics, and Commerce.',
    ARRAY['Use of English', 'Accounting', 'Economics', 'Commerce'],
    'Weekdays 3:00 PM - 6:00 PM, Sundays 3:00 PM - 6:00 PM',
    33000,
    'NGN',
    50,
    '2026-01-15',
    '2026-04-30'
  ),
  (
    (SELECT id FROM tutorial_programs WHERE name = 'Cambridge AS/A Level' LIMIT 1),
    'Cambridge A Level Arts & Humanities - 2026',
    'Premium Cambridge Arts preparation. History, Literature, Geography, and Economics taught to international standards.',
    ARRAY['History', 'Literature in English', 'Geography', 'Economics'],
    'Monday, Wednesday, Friday 4:00 PM - 7:00 PM',
    110000,
    'NGN',
    18,
    '2026-03-15',
    '2027-06-30'
  )
ON CONFLICT DO NOTHING;