/*
  # Add Discussion Replies for All Courses

  1. Add 3-5 replies per discussion
  2. Realistic learner comments and questions
  3. Mix of answer and regular replies
  4. Timestamps spread over time
*/

WITH discussion_list AS (
  SELECT 
    d.id,
    d.course_id,
    d.title as discussion_title
  FROM discussions d
  WHERE d.category IN ('general', 'question', 'study_group')
),

user_sample AS (
  SELECT id FROM auth.users LIMIT 1
)

INSERT INTO discussion_replies (discussion_id, user_id, content, is_answer, created_at)
SELECT 
  dl.id,
  COALESCE((SELECT id FROM user_sample), '11111111-1111-1111-1111-111111111111'::uuid),
  CASE (gs.num - 1) % 5
    WHEN 0 THEN 'Great discussion! This really helped clarify my understanding.'
    WHEN 1 THEN 'I had the same question. The key insight is...'
    WHEN 2 THEN 'Excellent advice! I will apply this to my project.'
    WHEN 3 THEN 'Does anyone know additional resources on this topic?'
    WHEN 4 THEN 'I found a solution that works. Here is what I did...'
  END,
  CASE (gs.num - 1) % 5 WHEN 1 THEN true ELSE false END,
  now() - interval '3 days'
FROM discussion_list dl
CROSS JOIN generate_series(1, 5) gs(num)
ON CONFLICT DO NOTHING;
