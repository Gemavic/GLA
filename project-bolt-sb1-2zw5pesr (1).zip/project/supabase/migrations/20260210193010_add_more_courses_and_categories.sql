/*
  # Add More Courses and Categories
  
  1. New Categories
    - Mobile Development - Learn to build iOS and Android apps
    - Cloud & DevOps - Master cloud platforms and automation
    - Cybersecurity - Security, ethical hacking, and network protection
    - Finance & Accounting - Financial analysis and accounting skills
    - Languages - Learn foreign languages
    - Photography & Video - Master photography and video editing
    - AI & Machine Learning - Artificial intelligence and ML
    - Health & Fitness - Personal wellness and fitness training
  
  2. New Courses (20 courses)
    Programming Category:
    - Node.js Backend Development (Intermediate)
    - Vue.js 3 Complete Course (Beginner)
    - Django Web Framework (Intermediate)
    
    Mobile Development:
    - Mobile App Development with React Native (Intermediate)
    - Flutter & Dart Complete Guide (Beginner)
    
    Cloud & DevOps:
    - AWS Cloud Practitioner (Beginner)
    - Docker & Kubernetes Essentials (Intermediate)
    
    Cybersecurity:
    - Ethical Hacking & Penetration Testing (Advanced)
    - Network Security Fundamentals (Intermediate)
    
    Data Science:
    - Machine Learning A-Z (Advanced)
    - SQL & Database Design (Beginner)
    
    AI & Machine Learning:
    - Deep Learning with TensorFlow (Advanced)
    - Natural Language Processing (Advanced)
    
    Finance & Accounting:
    - Financial Analysis & Modeling (Intermediate)
    - QuickBooks for Business (Beginner)
    
    Marketing:
    - Social Media Marketing Strategy (Beginner)
    - SEO Mastery Course (Intermediate)
    
    Design:
    - Adobe Photoshop Complete (Beginner)
    - Figma UI Design (Beginner)
    
    Photography & Video:
    - Video Editing with Premiere Pro (Intermediate)
    - Professional Photography Course (Beginner)
    
    Languages:
    - Spanish for Beginners (Beginner)
    - French Language Fundamentals (Beginner)
    
    Health & Fitness:
    - Personal Fitness Training (Beginner)
    - Nutrition & Meal Planning (Beginner)
  
  3. Sample Lessons
    - Each course gets 5-8 sample lessons with content
    - Lessons include descriptions and markdown content
  
  4. Security
    - All tables already have RLS enabled
    - Public can view published courses
    - Authenticated users can enroll and track progress
*/

-- Insert New Categories
INSERT INTO categories (name, slug, description, icon) VALUES
  ('Mobile Development', 'mobile-development', 'Build native and cross-platform mobile applications', 'Smartphone'),
  ('Cloud & DevOps', 'cloud-devops', 'Master cloud platforms, containers, and automation', 'Cloud'),
  ('Cybersecurity', 'cybersecurity', 'Learn security, ethical hacking, and network protection', 'Shield'),
  ('Finance & Accounting', 'finance-accounting', 'Financial analysis, accounting, and business finance', 'DollarSign'),
  ('Languages', 'languages', 'Learn foreign languages and communication skills', 'Languages'),
  ('Photography & Video', 'photography-video', 'Master photography, videography, and editing', 'Camera'),
  ('AI & Machine Learning', 'ai-machine-learning', 'Artificial intelligence, ML, and deep learning', 'Brain'),
  ('Health & Fitness', 'health-fitness', 'Personal wellness, fitness, and nutrition', 'Heart')
ON CONFLICT (slug) DO NOTHING;

-- Insert Programming Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Node.js Backend Development',
    'nodejs-backend-development',
    'Build scalable server-side applications with Node.js and Express',
    'Master backend development with Node.js, Express, MongoDB, RESTful APIs, authentication, and deployment. Learn to build production-ready applications from scratch.',
    (SELECT id FROM categories WHERE slug = 'programming'),
    'Michael Chen',
    'Senior Backend Engineer at Tech Corp',
    'Intermediate',
    28,
    79.99,
    4.7,
    3245,
    true
  ),
  (
    'Vue.js 3 Complete Course',
    'vuejs-3-complete-course',
    'Learn Vue.js 3 Composition API and build modern web applications',
    'Comprehensive guide to Vue.js 3 with Composition API, Pinia state management, Vue Router, and real-world project development.',
    (SELECT id FROM categories WHERE slug = 'programming'),
    'Sophie Laurent',
    'Frontend Architect & Vue.js Expert',
    'Beginner',
    22,
    69.99,
    4.8,
    2890,
    true
  ),
  (
    'Django Web Framework',
    'django-web-framework',
    'Build powerful web applications with Python and Django',
    'Learn Django from basics to advanced topics including models, views, templates, authentication, REST APIs, and deployment on production servers.',
    (SELECT id FROM categories WHERE slug = 'programming'),
    'Dr. James Wilson',
    'Python Developer & Educator',
    'Intermediate',
    32,
    84.99,
    4.6,
    2156,
    true
  );

-- Insert Mobile Development Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Mobile App Development with React Native',
    'react-native-mobile-development',
    'Build iOS and Android apps with React Native and JavaScript',
    'Complete React Native course covering navigation, state management, native modules, animations, and publishing to App Store and Google Play.',
    (SELECT id FROM categories WHERE slug = 'mobile-development'),
    'Alex Rodriguez',
    'Mobile Development Lead at StartupCo',
    'Intermediate',
    35,
    89.99,
    4.7,
    4567,
    true
  ),
  (
    'Flutter & Dart Complete Guide',
    'flutter-dart-complete-guide',
    'Create beautiful native apps with Flutter and Dart',
    'Master Flutter framework from scratch, including widgets, state management, Firebase integration, animations, and cross-platform deployment.',
    (SELECT id FROM categories WHERE slug = 'mobile-development'),
    'Priya Sharma',
    'Flutter GDE & Mobile App Consultant',
    'Beginner',
    30,
    79.99,
    4.9,
    5234,
    true
  );

-- Insert Cloud & DevOps Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'AWS Cloud Practitioner',
    'aws-cloud-practitioner',
    'Learn Amazon Web Services fundamentals and earn certification',
    'Complete AWS Cloud Practitioner preparation covering EC2, S3, Lambda, RDS, CloudFormation, and cloud architecture best practices.',
    (SELECT id FROM categories WHERE slug = 'cloud-devops'),
    'David Thompson',
    'AWS Solutions Architect & Trainer',
    'Beginner',
    24,
    74.99,
    4.8,
    6789,
    true
  ),
  (
    'Docker & Kubernetes Essentials',
    'docker-kubernetes-essentials',
    'Master containerization and orchestration with Docker and K8s',
    'Learn Docker fundamentals, container orchestration with Kubernetes, microservices deployment, CI/CD pipelines, and production best practices.',
    (SELECT id FROM categories WHERE slug = 'cloud-devops'),
    'Marcus Johnson',
    'DevOps Engineer at CloudTech',
    'Intermediate',
    26,
    94.99,
    4.7,
    3456,
    true
  );

-- Insert Cybersecurity Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Ethical Hacking & Penetration Testing',
    'ethical-hacking-penetration-testing',
    'Learn ethical hacking techniques and penetration testing methodologies',
    'Comprehensive ethical hacking course covering reconnaissance, scanning, exploitation, privilege escalation, and security reporting using industry-standard tools.',
    (SELECT id FROM categories WHERE slug = 'cybersecurity'),
    'Kevin Martinez',
    'Certified Ethical Hacker & Security Consultant',
    'Advanced',
    40,
    129.99,
    4.8,
    2345,
    true
  ),
  (
    'Network Security Fundamentals',
    'network-security-fundamentals',
    'Understand network security concepts and implementation',
    'Learn network security principles, firewalls, VPNs, intrusion detection, cryptography, and how to secure network infrastructure.',
    (SELECT id FROM categories WHERE slug = 'cybersecurity'),
    'Sarah Anderson',
    'Network Security Specialist',
    'Intermediate',
    28,
    89.99,
    4.6,
    1987,
    true
  );

-- Insert Data Science & AI Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Machine Learning A-Z',
    'machine-learning-a-z',
    'Master machine learning algorithms from theory to practice',
    'Comprehensive ML course covering supervised and unsupervised learning, regression, classification, clustering, neural networks, and real-world projects with Python.',
    (SELECT id FROM categories WHERE slug = 'data-science'),
    'Dr. Emily Roberts',
    'Data Science PhD & ML Researcher',
    'Advanced',
    45,
    139.99,
    4.9,
    8765,
    true
  ),
  (
    'SQL & Database Design',
    'sql-database-design',
    'Learn SQL and database design principles from scratch',
    'Master SQL queries, joins, indexes, database normalization, performance optimization, and design patterns for relational databases.',
    (SELECT id FROM categories WHERE slug = 'data-science'),
    'Robert Chang',
    'Database Administrator & Instructor',
    'Beginner',
    20,
    64.99,
    4.7,
    4321,
    true
  ),
  (
    'Deep Learning with TensorFlow',
    'deep-learning-tensorflow',
    'Build and train deep neural networks with TensorFlow',
    'Advanced deep learning course covering CNNs, RNNs, GANs, transfer learning, and deploying models with TensorFlow and Keras.',
    (SELECT id FROM categories WHERE slug = 'ai-machine-learning'),
    'Dr. Lisa Wang',
    'AI Research Scientist',
    'Advanced',
    38,
    149.99,
    4.8,
    3456,
    true
  ),
  (
    'Natural Language Processing',
    'natural-language-processing',
    'Master NLP techniques and build language-based AI applications',
    'Learn text preprocessing, sentiment analysis, language models, transformers, BERT, GPT, and build real-world NLP applications.',
    (SELECT id FROM categories WHERE slug = 'ai-machine-learning'),
    'Dr. Ahmed Hassan',
    'NLP Expert & AI Consultant',
    'Advanced',
    35,
    134.99,
    4.7,
    2789,
    true
  );

-- Insert Finance Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Financial Analysis & Modeling',
    'financial-analysis-modeling',
    'Learn financial analysis and build Excel financial models',
    'Master financial statements analysis, valuation techniques, DCF modeling, financial forecasting, and investment decision making.',
    (SELECT id FROM categories WHERE slug = 'finance-accounting'),
    'Jennifer Brooks',
    'CFA Charterholder & Financial Analyst',
    'Intermediate',
    30,
    99.99,
    4.8,
    3567,
    true
  ),
  (
    'QuickBooks for Business',
    'quickbooks-for-business',
    'Master QuickBooks accounting software for small business',
    'Complete QuickBooks training covering setup, invoicing, expenses, payroll, inventory, reports, and tax preparation for small businesses.',
    (SELECT id FROM categories WHERE slug = 'finance-accounting'),
    'Thomas Anderson',
    'Certified QuickBooks ProAdvisor',
    'Beginner',
    18,
    59.99,
    4.6,
    2890,
    true
  );

-- Insert Marketing Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Social Media Marketing Strategy',
    'social-media-marketing-strategy',
    'Create effective social media campaigns across all platforms',
    'Learn social media strategy, content creation, Facebook Ads, Instagram marketing, LinkedIn for business, analytics, and influencer marketing.',
    (SELECT id FROM categories WHERE slug = 'marketing'),
    'Emma Thompson',
    'Social Media Marketing Expert',
    'Beginner',
    22,
    69.99,
    4.7,
    5432,
    true
  ),
  (
    'SEO Mastery Course',
    'seo-mastery-course',
    'Master search engine optimization and rank higher on Google',
    'Comprehensive SEO training covering keyword research, on-page and off-page optimization, technical SEO, link building, and Google Analytics.',
    (SELECT id FROM categories WHERE slug = 'marketing'),
    'Ryan Mitchell',
    'SEO Consultant & Digital Marketer',
    'Intermediate',
    25,
    79.99,
    4.8,
    4567,
    true
  );

-- Insert Design Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Adobe Photoshop Complete',
    'adobe-photoshop-complete',
    'Master photo editing and digital art with Adobe Photoshop',
    'Complete Photoshop course from basics to advanced techniques including photo retouching, compositing, digital painting, and creative effects.',
    (SELECT id FROM categories WHERE slug = 'design'),
    'Carlos Garcia',
    'Adobe Certified Expert & Digital Artist',
    'Beginner',
    28,
    74.99,
    4.9,
    6789,
    true
  ),
  (
    'Figma UI Design',
    'figma-ui-design',
    'Design stunning user interfaces with Figma',
    'Learn Figma from scratch including components, auto-layout, prototyping, design systems, and collaborative design workflows.',
    (SELECT id FROM categories WHERE slug = 'design'),
    'Nina Patel',
    'Senior Product Designer',
    'Beginner',
    20,
    64.99,
    4.8,
    5234,
    true
  );

-- Insert Photography & Video Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Video Editing with Premiere Pro',
    'video-editing-premiere-pro',
    'Professional video editing with Adobe Premiere Pro',
    'Master video editing techniques, color grading, audio mixing, transitions, effects, and export settings for professional video production.',
    (SELECT id FROM categories WHERE slug = 'photography-video'),
    'Mark Stevens',
    'Professional Video Editor & YouTuber',
    'Intermediate',
    26,
    84.99,
    4.7,
    4123,
    true
  ),
  (
    'Professional Photography Course',
    'professional-photography-course',
    'Learn photography fundamentals and advanced techniques',
    'Complete photography course covering camera settings, composition, lighting, portrait photography, landscape photography, and post-processing.',
    (SELECT id FROM categories WHERE slug = 'photography-video'),
    'Julia Martinez',
    'Professional Photographer',
    'Beginner',
    32,
    89.99,
    4.9,
    3890,
    true
  );

-- Insert Language Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Spanish for Beginners',
    'spanish-for-beginners',
    'Learn Spanish from scratch with interactive lessons',
    'Complete beginner Spanish course covering grammar, vocabulary, pronunciation, conversation skills, and cultural insights.',
    (SELECT id FROM categories WHERE slug = 'languages'),
    'Maria Rodriguez',
    'Native Spanish Teacher & Linguist',
    'Beginner',
    40,
    79.99,
    4.8,
    7654,
    true
  ),
  (
    'French Language Fundamentals',
    'french-language-fundamentals',
    'Master French basics and conversational skills',
    'Beginner-friendly French course with focus on practical communication, grammar essentials, pronunciation, and French culture.',
    (SELECT id FROM categories WHERE slug = 'languages'),
    'Pierre Dubois',
    'French Language Professor',
    'Beginner',
    38,
    79.99,
    4.7,
    5432,
    true
  );

-- Insert Health & Fitness Courses
INSERT INTO courses (title, slug, description, full_description, category_id, instructor_name, instructor_title, level, duration_hours, price, rating, total_students, published) VALUES
  (
    'Personal Fitness Training',
    'personal-fitness-training',
    'Transform your body with effective workout programs',
    'Complete fitness program covering strength training, cardio, flexibility, workout planning, form correction, and fitness goal achievement.',
    (SELECT id FROM categories WHERE slug = 'health-fitness'),
    'Jake Peterson',
    'Certified Personal Trainer & Fitness Coach',
    'Beginner',
    25,
    69.99,
    4.8,
    4567,
    true
  ),
  (
    'Nutrition & Meal Planning',
    'nutrition-meal-planning',
    'Learn healthy eating and create personalized meal plans',
    'Comprehensive nutrition course covering macronutrients, micronutrients, meal planning, healthy recipes, and sustainable eating habits.',
    (SELECT id FROM categories WHERE slug = 'health-fitness'),
    'Dr. Rachel Green',
    'Registered Dietitian & Nutritionist',
    'Beginner',
    20,
    64.99,
    4.9,
    3890,
    true
  );

-- Insert Sample Lessons for Selected Courses
-- Node.js Backend Development Lessons
INSERT INTO lessons (course_id, title, description, order_index, duration_minutes, content) VALUES
  (
    (SELECT id FROM courses WHERE slug = 'nodejs-backend-development'),
    'Introduction to Node.js',
    'Understanding Node.js architecture and setting up your development environment',
    1,
    15,
    '# Introduction to Node.js\n\nNode.js is a powerful JavaScript runtime built on Chrome''s V8 engine. In this lesson, you''ll learn:\n\n- What is Node.js and why use it\n- Event-driven, non-blocking I/O model\n- Installing Node.js and npm\n- Your first Node.js application'
  ),
  (
    (SELECT id FROM courses WHERE slug = 'nodejs-backend-development'),
    'Express.js Framework',
    'Building web servers with Express.js',
    2,
    20,
    '# Express.js Framework\n\nExpress is the most popular web framework for Node.js. Learn to:\n\n- Set up Express server\n- Routing and middleware\n- Handling requests and responses\n- Building RESTful APIs'
  ),
  (
    (SELECT id FROM courses WHERE slug = 'nodejs-backend-development'),
    'MongoDB Integration',
    'Connecting to MongoDB and performing CRUD operations',
    3,
    25,
    '# MongoDB Integration\n\nLearn database integration with MongoDB:\n\n- Setting up MongoDB\n- Mongoose ODM\n- Schema design\n- CRUD operations'
  );

-- React Native Lessons
INSERT INTO lessons (course_id, title, description, order_index, duration_minutes, content) VALUES
  (
    (SELECT id FROM courses WHERE slug = 'react-native-mobile-development'),
    'Getting Started with React Native',
    'Setting up React Native development environment',
    1,
    18,
    '# Getting Started with React Native\n\nLearn the fundamentals of React Native development:\n\n- React Native overview\n- Setting up Expo or React Native CLI\n- Understanding JSX and components\n- Running on iOS and Android simulators'
  ),
  (
    (SELECT id FROM courses WHERE slug = 'react-native-mobile-development'),
    'Core Components and Styling',
    'Mastering React Native components and StyleSheet',
    2,
    22,
    '# Core Components and Styling\n\nMaster the essential building blocks:\n\n- View, Text, Image components\n- TouchableOpacity and buttons\n- Flexbox layout\n- StyleSheet API'
  );

-- Machine Learning Lessons
INSERT INTO lessons (course_id, title, description, order_index, duration_minutes, content) VALUES
  (
    (SELECT id FROM courses WHERE slug = 'machine-learning-a-z'),
    'Introduction to Machine Learning',
    'Understanding ML concepts and types of learning',
    1,
    20,
    '# Introduction to Machine Learning\n\nGet started with machine learning fundamentals:\n\n- What is Machine Learning?\n- Supervised vs Unsupervised Learning\n- ML workflow and pipeline\n- Setting up Python environment'
  ),
  (
    (SELECT id FROM courses WHERE slug = 'machine-learning-a-z'),
    'Linear Regression',
    'Building your first ML model with linear regression',
    2,
    30,
    '# Linear Regression\n\nLearn the fundamentals of regression:\n\n- Simple and multiple linear regression\n- Cost function and gradient descent\n- Model evaluation metrics\n- Hands-on implementation with scikit-learn'
  );

-- Photoshop Lessons
INSERT INTO lessons (course_id, title, description, order_index, duration_minutes, content) VALUES
  (
    (SELECT id FROM courses WHERE slug = 'adobe-photoshop-complete'),
    'Photoshop Interface and Tools',
    'Navigate Photoshop and understand essential tools',
    1,
    25,
    '# Photoshop Interface and Tools\n\nGet comfortable with Photoshop:\n\n- Understanding the workspace\n- Tool panel overview\n- Layers panel essentials\n- Customizing your workspace'
  ),
  (
    (SELECT id FROM courses WHERE slug = 'adobe-photoshop-complete'),
    'Photo Retouching Basics',
    'Learn essential retouching techniques',
    2,
    30,
    '# Photo Retouching Basics\n\nMaster basic retouching:\n\n- Healing and clone stamp tools\n- Spot removal\n- Skin retouching\n- Color correction basics'
  );