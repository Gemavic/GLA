/*
  # Add Missing Foreign Key Indexes and Fix RLS Performance

  1. New Indexes
    - `idx_session_chat_messages_session_id` on session_chat_messages(session_id)
    - `idx_tutor_profiles_deleted_by` on tutor_profiles(deleted_by)
    - `idx_tutor_profiles_reviewed_by` on tutor_profiles(reviewed_by)
    - `idx_tutor_sessions_hybrid_track_id` on tutor_sessions(hybrid_track_id)
    - `idx_tutor_sessions_tutor_profile_id` on tutor_sessions(tutor_profile_id)
    - `idx_whiteboard_snapshots_session_id` on whiteboard_snapshots(session_id)

  2. Security Changes
    - Fix RLS policies to use (select auth.uid()) pattern for better performance
    - Tables affected: quote_requests, tutor_sessions, tutor_profiles, admin_users, admin_audit_logs

  3. New RLS Policies
    - Add policies for material_downloads, session_chat_messages, session_participants, whiteboard_snapshots
*/

-- Add missing foreign key indexes
CREATE INDEX IF NOT EXISTS idx_session_chat_messages_session_id ON session_chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_tutor_profiles_deleted_by ON tutor_profiles(deleted_by);
CREATE INDEX IF NOT EXISTS idx_tutor_profiles_reviewed_by ON tutor_profiles(reviewed_by);
CREATE INDEX IF NOT EXISTS idx_tutor_sessions_hybrid_track_id ON tutor_sessions(hybrid_track_id);
CREATE INDEX IF NOT EXISTS idx_tutor_sessions_tutor_profile_id ON tutor_sessions(tutor_profile_id);
CREATE INDEX IF NOT EXISTS idx_whiteboard_snapshots_session_id ON whiteboard_snapshots(session_id);

-- Fix quote_requests RLS policies
DROP POLICY IF EXISTS "Users can view own quote requests" ON quote_requests;
DROP POLICY IF EXISTS "Authenticated users can create quote requests" ON quote_requests;
DROP POLICY IF EXISTS "Users can update own pending quote requests" ON quote_requests;

CREATE POLICY "Users can view own quote requests"
  ON quote_requests FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Authenticated users can create quote requests"
  ON quote_requests FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own pending quote requests"
  ON quote_requests FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()) AND status = 'pending')
  WITH CHECK (user_id = (select auth.uid()));

-- Fix tutor_sessions RLS policies
DROP POLICY IF EXISTS "Tutors create sessions" ON tutor_sessions;
DROP POLICY IF EXISTS "Tutors update own sessions" ON tutor_sessions;

CREATE POLICY "Tutors create sessions"
  ON tutor_sessions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM tutor_profiles
      WHERE tutor_profiles.user_id = (select auth.uid())
      AND tutor_profiles.status = 'approved'
    )
  );

CREATE POLICY "Tutors update own sessions"
  ON tutor_sessions FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM tutor_profiles
      WHERE tutor_profiles.id = tutor_sessions.tutor_profile_id
      AND tutor_profiles.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM tutor_profiles
      WHERE tutor_profiles.id = tutor_sessions.tutor_profile_id
      AND tutor_profiles.user_id = (select auth.uid())
    )
  );

-- Fix tutor_profiles RLS policies
DROP POLICY IF EXISTS "Users can view their own tutor profile" ON tutor_profiles;
DROP POLICY IF EXISTS "Users can insert their own tutor application" ON tutor_profiles;
DROP POLICY IF EXISTS "Users can update their own pending profile" ON tutor_profiles;
DROP POLICY IF EXISTS "Admins can view all tutor profiles" ON tutor_profiles;
DROP POLICY IF EXISTS "Admins can update any tutor profile" ON tutor_profiles;

CREATE POLICY "Users can view their own tutor profile"
  ON tutor_profiles FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert their own tutor application"
  ON tutor_profiles FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update their own pending profile"
  ON tutor_profiles FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()) AND status = 'pending')
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Admins can view all tutor profiles"
  ON tutor_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Admins can update any tutor profile"
  ON tutor_profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );

-- Fix admin_users RLS policies
DROP POLICY IF EXISTS "Admins can view admin list" ON admin_users;
DROP POLICY IF EXISTS "Users can check if they are admin" ON admin_users;

CREATE POLICY "Admins can view admin list"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Users can check if they are admin"
  ON admin_users FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Fix admin_audit_logs RLS policies
DROP POLICY IF EXISTS "Super admin can view all audit logs" ON admin_audit_logs;
DROP POLICY IF EXISTS "Admins can view own audit logs" ON admin_audit_logs;
DROP POLICY IF EXISTS "Admins can insert audit logs" ON admin_audit_logs;

CREATE POLICY "Super admin can view all audit logs"
  ON admin_audit_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
      AND admin_users.role = 'super_admin'
    )
  );

CREATE POLICY "Admins can view own audit logs"
  ON admin_audit_logs FOR SELECT
  TO authenticated
  USING (admin_id = (select auth.uid()));

CREATE POLICY "Admins can insert audit logs"
  ON admin_audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (
    admin_id = (select auth.uid())
    AND EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );

-- Add RLS policies for tables with RLS enabled but no policies

-- material_downloads policies (uses downloader_id)
CREATE POLICY "Users can view own downloads"
  ON material_downloads FOR SELECT
  TO authenticated
  USING (downloader_id = (select auth.uid()));

CREATE POLICY "Users can insert own downloads"
  ON material_downloads FOR INSERT
  TO authenticated
  WITH CHECK (downloader_id = (select auth.uid()));

-- session_chat_messages policies (uses sender_id)
CREATE POLICY "Participants can view session messages"
  ON session_chat_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM session_participants sp
      WHERE sp.session_id = session_chat_messages.session_id
      AND sp.participant_id = (select auth.uid())
    )
  );

CREATE POLICY "Participants can send messages"
  ON session_chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = (select auth.uid())
    AND EXISTS (
      SELECT 1 FROM session_participants sp
      WHERE sp.session_id = session_chat_messages.session_id
      AND sp.participant_id = (select auth.uid())
    )
  );

-- session_participants policies (uses participant_id)
CREATE POLICY "Users can view sessions they participate in"
  ON session_participants FOR SELECT
  TO authenticated
  USING (participant_id = (select auth.uid()));

CREATE POLICY "Tutors can add participants to their sessions"
  ON session_participants FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM tutor_sessions ts
      JOIN tutor_profiles tp ON ts.tutor_profile_id = tp.id
      WHERE ts.id = session_participants.session_id
      AND tp.user_id = (select auth.uid())
    )
    OR participant_id = (select auth.uid())
  );

CREATE POLICY "Users can leave sessions"
  ON session_participants FOR DELETE
  TO authenticated
  USING (participant_id = (select auth.uid()));

-- whiteboard_snapshots policies
CREATE POLICY "Participants can view whiteboard snapshots"
  ON whiteboard_snapshots FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM session_participants sp
      WHERE sp.session_id = whiteboard_snapshots.session_id
      AND sp.participant_id = (select auth.uid())
    )
  );

CREATE POLICY "Participants can create whiteboard snapshots"
  ON whiteboard_snapshots FOR INSERT
  TO authenticated
  WITH CHECK (
    created_by = (select auth.uid())
    AND EXISTS (
      SELECT 1 FROM session_participants sp
      WHERE sp.session_id = whiteboard_snapshots.session_id
      AND sp.participant_id = (select auth.uid())
    )
  );
