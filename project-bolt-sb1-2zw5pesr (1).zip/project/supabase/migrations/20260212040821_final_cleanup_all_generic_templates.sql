/*
  # Final Cleanup: Remove All Remaining Generic Template Lessons

  ## Issue
  Previous migrations didn't fully remove all generic template lessons.
  Still have 108 "Advanced Topics" generic lessons remaining.

  ## Complete Template Patterns to Remove

  1. **Module X - Advanced Topics** (1126 characters)
     - "Professional Techniques, Take your skills to the next level"
     - "Optimization, Performance tuning, Resource management"
     - Identical generic content across all courses

  2. **Module X - Practical Application** (945 characters)
     - "Put your knowledge into practice"
     - "Planning, Implementation, Optimization"

  ## Solution
  Remove all generic module lessons by title pattern and content characteristics.
  This ensures only genuine, course-specific content remains.

  ## Impact
  - Removes final batch of low-quality template content
  - All remaining lessons will be course-specific
  - Significantly improves learning experience
*/

-- Delete all "Advanced Topics" generic module lessons
DELETE FROM lessons
WHERE title LIKE 'Module % - Advanced Topics'
  AND LENGTH(content) = 1126;

-- Delete any remaining "Practical Application" generic lessons
DELETE FROM lessons
WHERE title LIKE 'Module % - Practical Application'
  AND LENGTH(content) <= 950;

-- Delete any remaining generic module lessons by pattern
DELETE FROM lessons
WHERE (title LIKE 'Module % - Core Concepts'
   OR title LIKE 'Module % - Practical Application'
   OR title LIKE 'Module % - Advanced Topics')
  AND (content LIKE '%This module covers essential concepts%'
   OR content LIKE '%Put your knowledge into practice with real-world scenarios%'
   OR content LIKE '%Professional Techniques%Take your skills to the next level%');
