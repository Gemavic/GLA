/*
  # Populate Design and Creative Courses

  1. Courses Covered
    - Adobe Photoshop Complete (8 modules)
    - Graphic Design Pro (8 modules)
    - Professional Photography Course (4 modules)
    - Video Editing with Premiere Pro (5 modules)

  2. Comprehensive creative curriculum
  3. Total: 50+ new lessons
*/

-- Adobe Photoshop Complete
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'adobe-photoshop-complete';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Photoshop Interface', 'Getting started with Photoshop',
  E'# Photoshop Basics\n\n## Interface Overview\n\n### Toolbar (Left Side)\n- Move Tool (V)\n- Selection Tools (M, W, L)\n- Crop Tool (C)\n- Brush Tool (B)\n- Clone Stamp (S)\n- Eraser (E)\n- Gradient (G)\n- Text Tool (T)\n\n### Panels (Right Side)\n- Layers Panel\n- Properties Panel\n- Adjustments Panel\n- History Panel\n\n## Essential Shortcuts\n- Ctrl/Cmd + N: New Document\n- Ctrl/Cmd + O: Open\n- Ctrl/Cmd + S: Save\n- Ctrl/Cmd + Z: Undo\n- Ctrl/Cmd + J: Duplicate Layer\n- Ctrl/Cmd + T: Free Transform\n- Ctrl/Cmd + E: Merge Down\n\n## Creating Your First Document\n\n1. File > New\n2. Set dimensions (1920x1080 for web)\n3. Choose RGB color mode\n4. Set resolution (72 for web, 300 for print)\n5. Click Create',
  1, 60, ARRAY['Navigate Photoshop interface', 'Use essential tools', 'Create documents']),
  
  (v_course_id, v_module_id, 'Layers and Selections', 'Working with layers',
  E'# Layers and Selections\n\n## Layer Types\n\n### Background Layer\n- Locked by default\n- No transparency\n- Convert to regular layer by double-clicking\n\n### Regular Layers\n- Can be moved, transformed\n- Support transparency\n- Can apply blend modes\n\n### Adjustment Layers\n- Non-destructive edits\n- Apply color/tone adjustments\n- Editable at any time\n\n## Selection Tools\n\n### Rectangular/Elliptical Marquee (M)\n- Drag to create selection\n- Hold Shift for perfect square/circle\n- Hold Alt to draw from center\n\n### Lasso Tools (L)\n- Freehand selection\n- Polygonal for straight edges\n- Magnetic for contrast edges\n\n### Quick Selection (W)\n- Paint to select similar areas\n- Adjust brush size with [ ]\n\n### Select Subject\n- Select > Subject\n- AI-powered selection\n- Refine with Select and Mask\n\n## Layer Operations\n\n- Ctrl/Cmd + J: Duplicate\n- Ctrl/Cmd + G: Group\n- Ctrl/Cmd + E: Merge Down\n- Alt + drag: Create copy',
  2, 75, ARRAY['Work with layers', 'Make selections', 'Organize layer structure']),
  
  (v_course_id, v_module_id, 'Basic Photo Editing', 'Adjusting images',
  E'# Photo Editing Basics\n\n## Crop and Straighten\n\n1. Select Crop Tool (C)\n2. Drag corners to resize\n3. Rotate to straighten\n4. Press Enter to apply\n\n## Adjustments\n\n### Brightness/Contrast\nImage > Adjustments > Brightness/Contrast\n- Brightness: Overall lightness\n- Contrast: Difference between light/dark\n\n### Levels (Ctrl/Cmd + L)\n- Adjust black, white, mid-tone points\n- Input sliders: Source levels\n- Output sliders: Output range\n\n### Curves (Ctrl/Cmd + M)\n- More control than Levels\n- Drag curve to adjust tones\n- S-curve for contrast\n\n### Hue/Saturation (Ctrl/Cmd + U)\n- Hue: Change colors\n- Saturation: Color intensity\n- Lightness: Brightness of colors\n\n### Vibrance\nImage > Adjustments > Vibrance\n- Smart saturation boost\n- Protects skin tones\n\n## Quick Enhancement Workflow\n\n1. Crop and straighten\n2. Adjust Levels\n3. Add Vibrance\n4. Sharpen (Filter > Sharpen > Unsharp Mask)',
  3, 80, ARRAY['Crop and straighten images', 'Adjust tones and colors', 'Enhance photos']);

  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Retouching Techniques', 'Professional retouching',
  E'# Photo Retouching\n\n## Spot Healing\n\n### Spot Healing Brush (J)\n- Click on blemishes\n- Automatically samples surrounding area\n- Best for small imperfections\n\n### Healing Brush (J)\n- Alt + Click to sample source\n- Paint over problem area\n- Matches texture and tone\n\n### Clone Stamp (S)\n- Alt + Click to sample\n- Paint exact copy\n- Use for larger areas\n\n## Skin Retouching\n\n### Frequency Separation\n\n1. Duplicate layer twice\n2. Name bottom "Texture", top "Color"\n3. Color layer: Filter > Blur > Gaussian Blur (5-10px)\n4. Texture layer: Image > Apply Image\n   - Layer: Color\n   - Blending: Subtract\n   - Scale: 2, Offset: 128\n5. Set Texture blend mode to Linear Light\n6. Retouch color on Color layer\n7. Retouch texture on Texture layer\n\n### Dodge and Burn\n\n- Create 50% gray layer in Soft Light mode\n- Paint white (dodge) for highlights\n- Paint black (burn) for shadows\n- Build up gradually\n\n## Portrait Enhancement\n\n1. Remove blemishes\n2. Whiten teeth (Hue/Saturation)\n3. Enhance eyes (Sharpen)\n4. Smooth skin (Frequency Separation)\n5. Dodge and burn for dimension',
  1, 90, ARRAY['Remove blemishes', 'Retouch skin', 'Enhance portraits']),
  
  (v_course_id, v_module_id, 'Masking and Compositing', 'Combining images',
  E'# Masks and Compositing\n\n## Layer Masks\n\n### Creating Masks\n- Click mask icon at bottom of Layers panel\n- White reveals, black conceals\n- Paint with brush to refine\n\n### Refining Masks\n- Select > Select and Mask\n- Refine Edge Brush for hair\n- Adjust settings:\n  - Smooth: Reduce jagged edges\n  - Feather: Soften transition\n  - Contrast: Sharpen edge\n  - Shift Edge: Expand/contract\n\n## Compositing Workflow\n\n1. Select and mask subject\n2. Place on new background\n3. Match lighting:\n   - Add shadows\n   - Adjust color temperature\n   - Match contrast\n4. Add depth:\n   - Slight blur to background\n   - Add atmosphere/haze\n5. Color grade for cohesion\n\n## Blending Modes\n\n### Darken Group\n- Darken, Multiply: Darken images\n- Use for shadows\n\n### Lighten Group\n- Lighten, Screen: Brighten images\n- Use for highlights, light leaks\n\n### Contrast Group\n- Overlay, Soft Light: Add contrast\n- Use for textures, adjustments\n\n### Color Group\n- Color, Hue: Change colors\n- Preserve luminosity',
  2, 95, ARRAY['Create layer masks', 'Composite images', 'Use blending modes']);

END $$;

-- Graphic Design Pro
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'graphic-design-pro';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Design Principles', 'Fundamental design concepts',
  E'# Design Fundamentals\n\n## The 5 Core Principles\n\n### 1. Balance\n- **Symmetrical**: Mirror image across center\n- **Asymmetrical**: Visual weight without mirroring\n- **Radial**: Elements radiate from center\n\n### 2. Contrast\n- Size: Large vs small\n- Color: Complementary colors\n- Type: Bold vs light\n- Shape: Geometric vs organic\n\n### 3. Emphasis/Focal Point\n- Main element that draws attention\n- Achieved through:\n  - Size\n  - Color\n  - Position\n  - Isolation\n\n### 4. Movement\n- Guide viewer''s eye through design\n- Use lines, shapes, color\n- Create visual flow\n\n### 5. White Space\n- Negative space around elements\n- Improves readability\n- Creates sophistication\n- Guides attention\n\n## Applying Principles\n\n**Poster Design Example:**\n\n1. **Hierarchy**: Headline largest\n2. **Contrast**: Bold headline, light body\n3. **Balance**: Asymmetric layout\n4. **White Space**: Breathing room\n5. **Alignment**: Grid-based\n\n**Tips:**\n- Use odd numbers (Rule of 3, 5)\n- Create visual triangles\n- Repeat elements for unity\n- Limit fonts to 2-3\n- Use consistent spacing',
  1, 70, ARRAY['Understand design principles', 'Apply balance and contrast', 'Create visual hierarchy']),
  
  (v_course_id, v_module_id, 'Color Theory', 'Understanding and using color',
  E'# Color Theory\n\n## Color Wheel Basics\n\n### Primary Colors\n- Red, Blue, Yellow\n- Cannot be created by mixing\n\n### Secondary Colors\n- Green, Orange, Purple\n- Mix two primaries\n\n### Tertiary Colors\n- Red-Orange, Yellow-Green, etc.\n- Mix primary + secondary\n\n## Color Harmonies\n\n### Complementary\n- Opposite on color wheel\n- High contrast\n- Example: Blue & Orange\n\n### Analogous\n- Adjacent on color wheel\n- Harmonious, low contrast\n- Example: Blue, Blue-Green, Green\n\n### Triadic\n- Three colors equally spaced\n- Vibrant, balanced\n- Example: Red, Yellow, Blue\n\n### Split-Complementary\n- Base color + two adjacent to complement\n- Softer than complementary\n\n## Color Psychology\n\n- **Red**: Energy, passion, urgency\n- **Blue**: Trust, calm, professional\n- **Yellow**: Optimism, warmth, caution\n- **Green**: Growth, health, nature\n- **Purple**: Luxury, creativity, wisdom\n- **Orange**: Enthusiasm, confidence\n- **Black**: Power, elegance, sophistication\n- **White**: Purity, simplicity, cleanliness\n\n## Creating Color Palettes\n\n### 60-30-10 Rule\n- 60%: Dominant color\n- 30%: Secondary color\n- 10%: Accent color\n\n### Tools\n- Adobe Color\n- Coolors.co\n- Paletton\n\n### Tips\n- Start with inspiration image\n- Use neutrals for balance\n- Test on different backgrounds\n- Consider accessibility (contrast)',
  2, 75, ARRAY['Understand color theory', 'Create color palettes', 'Apply color psychology']),
  
  (v_course_id, v_module_id, 'Typography Basics', 'Mastering type',
  E'# Typography\n\n## Font Classifications\n\n### Serif\n- Small lines at letter ends\n- Traditional, trustworthy\n- Use: Print, body text\n- Examples: Times New Roman, Georgia\n\n### Sans-Serif\n- No serifs\n- Modern, clean\n- Use: Digital, headlines\n- Examples: Helvetica, Arial\n\n### Script\n- Handwritten style\n- Elegant, personal\n- Use: Invitations, logos\n- Use sparingly\n\n### Display\n- Decorative, unique\n- Attention-grabbing\n- Use: Headlines only\n- Never for body text\n\n## Typography Rules\n\n### Hierarchy\n- 3 levels: Headline, Subhead, Body\n- Size contrast: 2:1 ratio minimum\n- Weight variation\n\n### Font Pairing\n- Use 2-3 fonts maximum\n- Contrast is key\n- Common pairs:\n  - Serif + Sans-Serif\n  - Display + Simple Sans\n\n### Readability\n- Line length: 45-75 characters\n- Line height: 1.5x font size\n- Font size: 16px minimum for body\n- Avoid all caps for body text\n\n### Alignment\n- Left: Most readable\n- Center: Formal, limited text\n- Right: Rarely used\n- Justified: Can create rivers\n\n## Type Effects\n\n### Kerning\n- Space between two letters\n- Adjust for optical balance\n\n### Tracking\n- Overall letter spacing\n- Increase for headlines\n- Decrease for body\n\n### Leading\n- Space between lines\n- More for longer lines',
  3, 85, ARRAY['Understand type classifications', 'Pair fonts effectively', 'Apply typography rules']);

END $$;

-- Professional Photography
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'professional-photography-course';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Camera Basics', 'Understanding your camera',
  E'# Camera Fundamentals\n\n## Exposure Triangle\n\n### Aperture (f-stop)\n- Controls depth of field\n- Lower number = wider aperture = more light\n- f/1.8: Shallow depth, blurry background\n- f/16: Deep depth, everything sharp\n\n**Use Cases:**\n- Portraits: f/1.8-f/2.8\n- Landscapes: f/8-f/16\n- Street: f/5.6-f/8\n\n### Shutter Speed\n- Controls motion blur\n- Faster = freezes motion\n- Slower = motion blur\n\n**Guidelines:**\n- Handheld minimum: 1/(focal length)\n- Action: 1/1000s or faster\n- Panning: 1/60s - 1/250s\n- Long exposure: 1s - 30s\n\n### ISO\n- Controls light sensitivity\n- Higher ISO = more grain/noise\n\n**Guidelines:**\n- Bright sun: ISO 100-200\n- Overcast: ISO 400-800\n- Indoor: ISO 800-1600\n- Night: ISO 1600-6400+\n\n## Shooting Modes\n\n### Manual (M)\n- Full control\n- Set all three values\n- Use in studio, landscapes\n\n### Aperture Priority (A/Av)\n- You set aperture\n- Camera sets shutter speed\n- Great for portraits, depth control\n\n### Shutter Priority (S/Tv)\n- You set shutter speed\n- Camera sets aperture\n- Great for action, sports\n\n### Auto (P)\n- Camera sets both\n- You adjust with dial\n- Quick shooting',
  1, 80, ARRAY['Understand exposure triangle', 'Use shooting modes', 'Control camera settings']),
  
  (v_course_id, v_module_id, 'Composition Techniques', 'Creating compelling images',
  E'# Composition Rules\n\n## Rule of Thirds\n- Divide frame into 3x3 grid\n- Place subjects on intersections\n- More dynamic than center\n\n## Leading Lines\n- Use lines to guide eye\n- Roads, fences, rivers\n- Lead to subject\n\n## Framing\n- Use foreground elements\n- Windows, arches, branches\n- Draws attention to subject\n\n## Symmetry and Patterns\n- Create visual balance\n- Break pattern for interest\n- Architecture, nature\n\n## Negative Space\n- Empty space around subject\n- Gives breathing room\n- Minimalist, clean look\n\n## Perspective\n- Change your angle\n- Low: Makes subject powerful\n- High: Shows environment\n- Eye level: Natural, intimate\n\n## Depth\n- Foreground, middle, background\n- Creates 3D feel\n- Use f/8-f/16 for sharpness\n\n## Golden Hour\n- Hour after sunrise\n- Hour before sunset\n- Soft, warm light\n- Long shadows, dimension\n\n## Tips\n- Simplify composition\n- Watch edges of frame\n- Check background\n- Get closer\n- Take multiple shots',
  2, 75, ARRAY['Apply composition rules', 'Use leading lines', 'Create depth in images']),
  
  (v_course_id, v_module_id, 'Lighting Fundamentals', 'Mastering light',
  E'# Photography Lighting\n\n## Natural Light\n\n### Direction\n- **Front lighting**: Flat, even\n- **Side lighting**: Dimension, texture\n- **Back lighting**: Silhouette, rim light\n- **Top lighting**: Harsh shadows (avoid)\n\n### Quality\n- **Hard light**: Direct sun, harsh shadows\n- **Soft light**: Overcast, diffused\n\n### Color Temperature\n- Morning/Evening: Warm (3000K)\n- Midday: Cool (5500K)\n- Shade: Very cool (7000K+)\n\n## Window Light\n- Large, soft light source\n- Position subject 45° to window\n- Use reflector opposite window\n- Shoot in shade of window\n\n## Artificial Light\n\n### Flash Basics\n- Bounce off ceiling/wall\n- Never direct at subject\n- Use diffuser\n\n### Three-Point Lighting\n\n1. **Key Light**: Main light (45°)\n2. **Fill Light**: Soften shadows (opposite)\n3. **Back Light**: Separate from background\n\n## Light Modifiers\n\n- **Softbox**: Soft, even light\n- **Umbrella**: Broad, soft light\n- **Reflector**: Bounce light, fill shadows\n- **Diffuser**: Soften harsh light\n\n## Tips\n- Avoid harsh midday sun\n- Use golden hour\n- Diffuse harsh light\n- Watch for catchlights in eyes',
  3, 85, ARRAY['Understand light quality', 'Use natural light', 'Apply basic lighting setups']);

  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Portrait Photography', 'Capturing people',
  E'# Portrait Photography\n\n## Camera Settings\n- Aperture: f/1.8 - f/4\n- Shutter: 1/125s minimum\n- ISO: As low as possible\n- Focal length: 85mm-135mm\n\n## Posing Tips\n\n### Body Language\n- Weight on back foot\n- Angle body slightly\n- Hands with purpose\n- Chin slightly forward\n\n### Flattering Angles\n- Slightly above eye level\n- Turn body 45°\n- Avoid straight-on\n\n### Expressions\n- Think of happy memory\n- Genuine laugh\n- Soft smile\n- Serious/editorial\n\n## Lighting\n- 45° to subject (Rembrandt)\n- Catchlight in eyes\n- Fill shadows with reflector\n- Avoid harsh overhead\n\n## Common Mistakes\n- Too much background\n- Distracting elements\n- Harsh lighting\n- Cutting off joints\n- Dead space above head\n\n## Workflow\n1. Scout location\n2. Set up lighting\n3. Test exposure\n4. Direct subject\n5. Shoot variations\n6. Review and adjust',
  1, 90, ARRAY['Shoot portraits effectively', 'Pose subjects', 'Control portrait lighting']);

END $$;

-- Video Editing with Premiere Pro
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'video-editing-premiere-pro';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Premiere Pro Interface', 'Getting started',
  E'# Premiere Pro Basics\n\n## Workspace Layout\n\n### Panels\n- **Project Panel**: Import and organize media\n- **Source Monitor**: Preview clips\n- **Program Monitor**: Preview timeline\n- **Timeline**: Edit sequence\n- **Tools Panel**: Editing tools\n- **Audio Meters**: Monitor levels\n\n## Essential Shortcuts\n- Space: Play/Pause\n- I: Mark In\n- O: Mark Out\n- C: Razor Tool\n- V: Selection Tool\n- Cmd/Ctrl + K: Cut\n- Cmd/Ctrl + Z: Undo\n\n## Project Setup\n\n1. New Project\n2. Import media (Cmd/Ctrl + I)\n3. Create Sequence\n   - Match settings to footage\n   - 1920x1080, 24/30/60fps\n4. Organize bins\n\n## Basic Workflow\n\n1. Import footage\n2. Review clips in Source Monitor\n3. Mark In/Out points\n4. Drag to Timeline\n5. Trim and arrange\n6. Add transitions\n7. Color correct\n8. Export',
  1, 70, ARRAY['Navigate Premiere Pro', 'Set up projects', 'Import and organize media']),
  
  (v_course_id, v_module_id, 'Basic Editing', 'Cutting and arranging clips',
  E'# Video Editing Basics\n\n## Timeline Editing\n\n### Adding Clips\n- Drag from Project Panel\n- Insert (Comma): Shifts clips\n- Overwrite (Period): Replaces clips\n\n### Trimming\n- Ripple Edit (B): Adjusts one side, shifts rest\n- Rolling Edit (N): Adjusts cut point\n- Drag clip ends to trim\n\n### Cutting\n- Razor Tool (C): Click to cut\n- Cmd/Ctrl + K: Cut at playhead\n\n## Three-Point Editing\n\n1. Mark clip In/Out in Source\n2. Mark Timeline In point\n3. Insert or Overwrite\n\n## Transitions\n\n### Cross Dissolve\n- Effects > Video Transitions > Dissolve\n- Drag to cut point\n- Default: Cmd/Ctrl + D\n\n### Transition Settings\n- Double-click in timeline\n- Adjust duration\n- Change alignment\n\n## Best Practices\n\n- Cut on action\n- Use J-cuts and L-cuts\n- Vary shot sizes\n- Match eye lines\n- Maintain continuity',
  2, 80, ARRAY['Edit video clips', 'Apply transitions', 'Trim footage precisely']),
  
  (v_course_id, v_module_id, 'Audio Editing', 'Working with sound',
  E'# Audio in Premiere Pro\n\n## Audio Levels\n\n### Target Levels\n- Dialogue: -12dB to -6dB\n- Music: -18dB to -12dB\n- Sound effects: -12dB to -6dB\n- Peak: Never above -3dB\n\n### Adjusting Levels\n- Select clip, press G for gain\n- Drag volume line in timeline\n- Audio Track Mixer (Shift + 6)\n\n## Audio Transitions\n\n### Crossfade\n- Effects > Audio Transitions > Crossfade\n- Constant Power (most common)\n- Exponential Fade\n\n### Fade In/Out\n- Apply at clip ends\n- Smooth audio transitions\n\n## Essential Sound Panel\n\n1. Window > Essential Sound\n2. Assign clip type:\n   - Dialogue\n   - Music\n   - SFX\n   - Ambience\n3. Apply presets\n4. Adjust settings\n\n### Dialogue\n- Repair (reduce noise, hum)\n- Clarity (EQ, enhance)\n- Dynamics (compress, limit)\n\n## Multi-Track Audio\n\n- Separate dialogue, music, SFX\n- Use audio tracks\n- Apply effects per track\n- Mix in Audio Track Mixer',
  3, 75, ARRAY['Edit audio clips', 'Mix audio levels', 'Apply audio effects']);

END $$;
