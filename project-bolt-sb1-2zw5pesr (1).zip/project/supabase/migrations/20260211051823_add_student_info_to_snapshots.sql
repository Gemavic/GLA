/*
  # Add Student Information to Progress Snapshots

  1. Changes to Tables
    - `progress_snapshots`
      - Add `student_name` (text) - Full name of the student
      - Add `exam_number` (text) - Student's examination number
      - Add `exam_centre` (text) - Name of the examination centre
  
  2. Notes
    - Fields are optional to maintain backward compatibility
    - Existing snapshots will have NULL values for these fields
*/

-- Add student information columns to progress_snapshots
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'progress_snapshots' AND column_name = 'student_name'
  ) THEN
    ALTER TABLE progress_snapshots ADD COLUMN student_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'progress_snapshots' AND column_name = 'exam_number'
  ) THEN
    ALTER TABLE progress_snapshots ADD COLUMN exam_number text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'progress_snapshots' AND column_name = 'exam_centre'
  ) THEN
    ALTER TABLE progress_snapshots ADD COLUMN exam_centre text;
  END IF;
END $$;