/*
  # Optimize RLS Policies with SELECT Wrapper (Fixed)

  1. Performance Optimization
    - Wraps all auth.uid() calls with (select auth.uid())
    - Prevents re-evaluation for each row
    - Critical for performance at scale
    
  2. Tables Affected
    - All tables with RLS policies using auth functions
    
  3. Security
    - Maintains same security level
    - Improves query performance dramatically
*/

-- Drop and recreate enrollments policies
DROP POLICY IF EXISTS "Users can view own enrollments" ON enrollments;
DROP POLICY IF EXISTS "Users can create own enrollments" ON enrollments;
DROP POLICY IF EXISTS "Users can update own enrollments" ON enrollments;

CREATE POLICY "Users can view own enrollments"
  ON enrollments FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can create own enrollments"
  ON enrollments FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own enrollments"
  ON enrollments FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate lesson_progress policies
DROP POLICY IF EXISTS "Users can view own lesson progress" ON lesson_progress;
DROP POLICY IF EXISTS "Users can create own lesson progress" ON lesson_progress;
DROP POLICY IF EXISTS "Users can update own lesson progress" ON lesson_progress;

CREATE POLICY "Users can view own lesson progress"
  ON lesson_progress FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can create own lesson progress"
  ON lesson_progress FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own lesson progress"
  ON lesson_progress FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate tutorial_enrollments policies
DROP POLICY IF EXISTS "Users can view own enrollments" ON tutorial_enrollments;
DROP POLICY IF EXISTS "Authenticated users can enroll in sessions" ON tutorial_enrollments;
DROP POLICY IF EXISTS "Users can update own enrollments" ON tutorial_enrollments;

CREATE POLICY "Users can view own enrollments"
  ON tutorial_enrollments FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Authenticated users can enroll in sessions"
  ON tutorial_enrollments FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own enrollments"
  ON tutorial_enrollments FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate student_progress policies
DROP POLICY IF EXISTS "Users can view own progress" ON student_progress;
DROP POLICY IF EXISTS "Users can insert own progress" ON student_progress;
DROP POLICY IF EXISTS "Users can update own progress" ON student_progress;
DROP POLICY IF EXISTS "Users can delete own progress" ON student_progress;

CREATE POLICY "Users can view own progress"
  ON student_progress FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own progress"
  ON student_progress FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own progress"
  ON student_progress FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own progress"
  ON student_progress FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Drop and recreate progress_snapshots policies
DROP POLICY IF EXISTS "Users can view own snapshots" ON progress_snapshots;
DROP POLICY IF EXISTS "Users can insert own snapshots" ON progress_snapshots;
DROP POLICY IF EXISTS "Users can delete own snapshots" ON progress_snapshots;

CREATE POLICY "Users can view own snapshots"
  ON progress_snapshots FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own snapshots"
  ON progress_snapshots FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own snapshots"
  ON progress_snapshots FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Drop and recreate assignments policies
DROP POLICY IF EXISTS "Enrolled students view published assignments" ON assignments;

CREATE POLICY "Enrolled students view published assignments"
  ON assignments FOR SELECT
  TO authenticated
  USING (
    status = 'active' AND
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = assignments.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

-- Drop and recreate assignment_submissions policies
DROP POLICY IF EXISTS "Users view own submissions" ON assignment_submissions;
DROP POLICY IF EXISTS "Users create own submissions" ON assignment_submissions;
DROP POLICY IF EXISTS "Users update own submissions" ON assignment_submissions;

CREATE POLICY "Users view own submissions"
  ON assignment_submissions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users create own submissions"
  ON assignment_submissions FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users update own submissions"
  ON assignment_submissions FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate quizzes policies
DROP POLICY IF EXISTS "Enrolled students view published quizzes" ON quizzes;

CREATE POLICY "Enrolled students view published quizzes"
  ON quizzes FOR SELECT
  TO authenticated
  USING (
    status = 'active' AND
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = quizzes.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

-- Drop and recreate quiz_questions policies
DROP POLICY IF EXISTS "Enrolled students view quiz questions" ON quiz_questions;

CREATE POLICY "Enrolled students view quiz questions"
  ON quiz_questions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM quizzes q
      JOIN enrollments e ON e.course_id = q.course_id
      WHERE q.id = quiz_questions.quiz_id
      AND e.user_id = (select auth.uid())
    )
  );

-- Drop and recreate quiz_attempts policies
DROP POLICY IF EXISTS "Users view own quiz attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "Users create own quiz attempts" ON quiz_attempts;
DROP POLICY IF EXISTS "Users update own quiz attempts" ON quiz_attempts;

CREATE POLICY "Users view own quiz attempts"
  ON quiz_attempts FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users create own quiz attempts"
  ON quiz_attempts FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users update own quiz attempts"
  ON quiz_attempts FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate quiz_answers policies
DROP POLICY IF EXISTS "Users view own quiz answers" ON quiz_answers;
DROP POLICY IF EXISTS "Users create own quiz answers" ON quiz_answers;

CREATE POLICY "Users view own quiz answers"
  ON quiz_answers FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM quiz_attempts
      WHERE quiz_attempts.id = quiz_answers.attempt_id
      AND quiz_attempts.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Users create own quiz answers"
  ON quiz_answers FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM quiz_attempts
      WHERE quiz_attempts.id = quiz_answers.attempt_id
      AND quiz_attempts.user_id = (select auth.uid())
    )
  );

-- Drop and recreate discussions policies
DROP POLICY IF EXISTS "Enrolled students view discussions" ON discussions;
DROP POLICY IF EXISTS "Enrolled students create discussions" ON discussions;
DROP POLICY IF EXISTS "Users update own discussions" ON discussions;

CREATE POLICY "Enrolled students view discussions"
  ON discussions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = discussions.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Enrolled students create discussions"
  ON discussions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = discussions.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Users update own discussions"
  ON discussions FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate discussion_replies policies
DROP POLICY IF EXISTS "Enrolled students view replies" ON discussion_replies;
DROP POLICY IF EXISTS "Enrolled students create replies" ON discussion_replies;

CREATE POLICY "Enrolled students view replies"
  ON discussion_replies FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM discussions d
      JOIN enrollments e ON e.course_id = d.course_id
      WHERE d.id = discussion_replies.discussion_id
      AND e.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Enrolled students create replies"
  ON discussion_replies FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM discussions d
      JOIN enrollments e ON e.course_id = d.course_id
      WHERE d.id = discussion_replies.discussion_id
      AND e.user_id = (select auth.uid())
    )
  );

-- Drop and recreate mentorship_requests policies
DROP POLICY IF EXISTS "Students view own mentorship requests" ON mentorship_requests;
DROP POLICY IF EXISTS "Students create mentorship requests" ON mentorship_requests;
DROP POLICY IF EXISTS "Students update own requests" ON mentorship_requests;

CREATE POLICY "Students view own mentorship requests"
  ON mentorship_requests FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = student_id);

CREATE POLICY "Students create mentorship requests"
  ON mentorship_requests FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = student_id);

CREATE POLICY "Students update own requests"
  ON mentorship_requests FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = student_id)
  WITH CHECK ((select auth.uid()) = student_id);

-- Drop and recreate mentorship_sessions policies
DROP POLICY IF EXISTS "Students view own sessions" ON mentorship_sessions;

CREATE POLICY "Students view own sessions"
  ON mentorship_sessions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = student_id);

-- Drop and recreate messages policies
DROP POLICY IF EXISTS "Users view own messages" ON messages;
DROP POLICY IF EXISTS "Users send messages" ON messages;
DROP POLICY IF EXISTS "Recipients update messages" ON messages;

CREATE POLICY "Users view own messages"
  ON messages FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = sender_id OR (select auth.uid()) = recipient_id);

CREATE POLICY "Users send messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = sender_id);

CREATE POLICY "Recipients update messages"
  ON messages FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = recipient_id)
  WITH CHECK ((select auth.uid()) = recipient_id);

-- Drop and recreate study_materials policies
DROP POLICY IF EXISTS "Enrolled students view study materials" ON study_materials;

CREATE POLICY "Enrolled students view study materials"
  ON study_materials FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = study_materials.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

-- Drop and recreate announcements policies
DROP POLICY IF EXISTS "Enrolled students view announcements" ON announcements;

CREATE POLICY "Enrolled students view announcements"
  ON announcements FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = announcements.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

-- Drop and recreate achievements policies
DROP POLICY IF EXISTS "Users view own achievements" ON achievements;

CREATE POLICY "Users view own achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Drop and recreate calendar_events policies
DROP POLICY IF EXISTS "Enrolled students view calendar events" ON calendar_events;

CREATE POLICY "Enrolled students view calendar events"
  ON calendar_events FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = calendar_events.course_id
      AND enrollments.user_id = (select auth.uid())
    )
  );

-- Drop and recreate attendance policies
DROP POLICY IF EXISTS "Users view own attendance" ON attendance;
DROP POLICY IF EXISTS "Users create own attendance" ON attendance;

CREATE POLICY "Users view own attendance"
  ON attendance FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users create own attendance"
  ON attendance FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate notifications policies
DROP POLICY IF EXISTS "Users view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users delete own notifications" ON notifications;

CREATE POLICY "Users view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Drop and recreate notification_preferences policies
DROP POLICY IF EXISTS "Users view own preferences" ON notification_preferences;
DROP POLICY IF EXISTS "Users update own preferences" ON notification_preferences;
DROP POLICY IF EXISTS "Users insert own preferences" ON notification_preferences;

CREATE POLICY "Users view own preferences"
  ON notification_preferences FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users update own preferences"
  ON notification_preferences FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users insert own preferences"
  ON notification_preferences FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate certificates policies
DROP POLICY IF EXISTS "Users view own certificates" ON certificates;

CREATE POLICY "Users view own certificates"
  ON certificates FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Drop and recreate leaderboard_entries policies
DROP POLICY IF EXISTS "Users update own leaderboard entry" ON leaderboard_entries;
DROP POLICY IF EXISTS "Users insert own leaderboard entry" ON leaderboard_entries;

CREATE POLICY "Users update own leaderboard entry"
  ON leaderboard_entries FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users insert own leaderboard entry"
  ON leaderboard_entries FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate student_analytics policies
DROP POLICY IF EXISTS "Users view own analytics" ON student_analytics;

CREATE POLICY "Users view own analytics"
  ON student_analytics FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Drop and recreate learning_recommendations policies
DROP POLICY IF EXISTS "Users view own recommendations" ON learning_recommendations;
DROP POLICY IF EXISTS "Users update own recommendations" ON learning_recommendations;

CREATE POLICY "Users view own recommendations"
  ON learning_recommendations FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users update own recommendations"
  ON learning_recommendations FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate study_sessions policies
DROP POLICY IF EXISTS "Users view own study sessions" ON study_sessions;
DROP POLICY IF EXISTS "Users create own study sessions" ON study_sessions;
DROP POLICY IF EXISTS "Users update own study sessions" ON study_sessions;

CREATE POLICY "Users view own study sessions"
  ON study_sessions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users create own study sessions"
  ON study_sessions FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users update own study sessions"
  ON study_sessions FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- Drop and recreate grade_reports policies
DROP POLICY IF EXISTS "Users view own grade reports" ON grade_reports;

CREATE POLICY "Users view own grade reports"
  ON grade_reports FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);
