/*
  # Comprehensive Course Lessons - Part 2

  1. Courses Covered
    - Machine Learning A-Z
    - Figma UI Design
    - AWS Cloud Practitioner
    - React Native Mobile Development
    - SEO Mastery Course

  2. Content Details
    - Essential lessons for each module
    - Practical examples and exercises
    - Learning objectives aligned with industry standards
*/

-- Machine Learning A-Z
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'machine-learning-a-z';
  
  -- Module 1: Introduction to ML
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'What is Machine Learning?', 'Understanding ML fundamentals', 
  E'# Introduction to Machine Learning\n\n## Types of Machine Learning\n\n### 1. Supervised Learning\n- Learn from labeled data\n- Predict outcomes\n- Examples: Classification, Regression\n\n### 2. Unsupervised Learning\n- Find patterns in unlabeled data\n- Examples: Clustering, Dimensionality Reduction\n\n### 3. Reinforcement Learning\n- Learn through trial and error\n- Agent interacts with environment\n- Example: Game AI, Robotics\n\n## ML Workflow\n\n1. Problem Definition\n2. Data Collection\n3. Data Preprocessing\n4. Model Selection\n5. Training\n6. Evaluation\n7. Deployment',
  1, 60, ARRAY['Understand ML types', 'Know the ML workflow', 'Identify ML applications']),
  
  (v_course_id, v_module_id, 'Python for ML', 'Essential Python libraries', 
  E'# Python for Machine Learning\n\n## Key Libraries\n\n```python\n# NumPy - Numerical computing\nimport numpy as np\narr = np.array([1, 2, 3, 4, 5])\nprint(np.mean(arr))\n\n# Pandas - Data manipulation\nimport pandas as pd\ndf = pd.DataFrame({''A'': [1, 2, 3], ''B'': [4, 5, 6]})\nprint(df.describe())\n\n# Matplotlib - Visualization\nimport matplotlib.pyplot as plt\nplt.plot([1, 2, 3], [1, 4, 9])\nplt.show()\n\n# Scikit-learn - ML algorithms\nfrom sklearn.linear_model import LinearRegression\nmodel = LinearRegression()\nmodel.fit(X_train, y_train)\n```',
  2, 70, ARRAY['Use Python ML libraries', 'Manipulate data with Pandas', 'Create visualizations']);

  -- Module 3: Regression
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 3;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Linear Regression', 'Predicting continuous values', 
  E'# Linear Regression\n\n## Concept\n\nFind the best-fit line: y = mx + b\n\n## Implementation\n\n```python\nfrom sklearn.linear_model import LinearRegression\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.metrics import mean_squared_error, r2_score\n\n# Prepare data\nX = df[[''feature'']]\ny = df[''target'']\n\n# Split data\nX_train, X_test, y_train, y_test = train_test_split(\n    X, y, test_size=0.2, random_state=42\n)\n\n# Train model\nmodel = LinearRegression()\nmodel.fit(X_train, y_train)\n\n# Predict\ny_pred = model.predict(X_test)\n\n# Evaluate\nmse = mean_squared_error(y_test, y_pred)\nr2 = r2_score(y_test, y_pred)\nprint(f''MSE: {mse}, R²: {r2}'')\n```',
  1, 85, ARRAY['Implement linear regression', 'Train and evaluate models', 'Interpret regression metrics']),
  
  (v_course_id, v_module_id, 'Multiple Linear Regression', 'Multiple features prediction', 
  E'# Multiple Linear Regression\n\n## Multiple Features\n\ny = b0 + b1*x1 + b2*x2 + ... + bn*xn\n\n```python\n# Multiple features\nX = df[[''feature1'', ''feature2'', ''feature3'']]\ny = df[''target'']\n\nX_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)\n\nmodel = LinearRegression()\nmodel.fit(X_train, y_train)\n\n# Coefficients\nprint(''Coefficients:'', model.coef_)\nprint(''Intercept:'', model.intercept_)\n\n# Predictions\ny_pred = model.predict(X_test)\n\n# Evaluation\nfrom sklearn.metrics import mean_absolute_error\nmae = mean_absolute_error(y_test, y_pred)\nprint(f''MAE: {mae}'')\n```',
  2, 80, ARRAY['Work with multiple features', 'Understand coefficients', 'Evaluate model performance']);

END $$;

-- Figma UI Design
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'figma-ui-design';
  
  -- Module 1: Figma Basics
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Getting Started with Figma', 'Figma interface and tools', 
  E'# Figma Introduction\n\n## Interface Overview\n\n### Top Toolbar\n- Move Tool (V)\n- Frame Tool (F)\n- Shape Tools (R, O, L)\n- Text Tool (T)\n- Hand Tool (H)\n- Comment Tool (C)\n\n### Left Sidebar\n- Layers Panel\n- Assets Panel\n- Pages\n\n### Right Sidebar\n- Design Properties\n- Prototype Settings\n- Code Panel\n\n## Creating Your First Design\n\n1. Create Frame (F)\n2. Add shapes and text\n3. Apply colors and styles\n4. Group elements (Cmd/Ctrl + G)\n5. Create components\n\n## Keyboard Shortcuts\n\n- V: Move\n- R: Rectangle\n- T: Text\n- Cmd/Ctrl + D: Duplicate\n- Cmd/Ctrl + G: Group',
  1, 55, ARRAY['Navigate Figma interface', 'Use basic tools', 'Know essential shortcuts']),
  
  (v_course_id, v_module_id, 'Frames and Layouts', 'Organizing designs', 
  E'# Frames and Layouts\n\n## Frames vs Groups\n\n### Frames\n- Can have Auto Layout\n- Can be used as components\n- Can clip content\n- Have background color\n\n### Groups\n- Simple container\n- No Auto Layout\n- Transparent background\n\n## Creating Responsive Layouts\n\n1. Create Frame with device dimensions\n2. Use constraints for responsiveness\n3. Apply Auto Layout for flexibility\n4. Use grids for alignment\n\n## Layout Grids\n\n- Rows: Horizontal guides\n- Columns: Vertical guides\n- Grid: Square grid\n\nCommon grid: 12 columns, 20px gutter',
  2, 65, ARRAY['Create and use frames', 'Apply layout grids', 'Understand constraints']);

  -- Module 3: Components and Variants
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 3;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Creating Components', 'Reusable design elements', 
  E'# Figma Components\n\n## What are Components?\n\nReusable design elements that maintain consistency.\n\n## Creating Components\n\n1. Design the element\n2. Select it\n3. Click "Create Component" (Cmd/Ctrl + Alt + K)\n4. Name it descriptively\n\n## Component Instances\n\n- Instances inherit from main component\n- Changes to main component update all instances\n- Instances can override certain properties\n\n## Component Properties\n\n### Overridable\n- Text content\n- Images\n- Visibility\n- Some style properties\n\n### Not Overridable\n- Structure\n- Layout\n- Base styles\n\n## Best Practices\n\n- Use clear naming (Button/Primary/Large)\n- Organize in pages\n- Document usage\n- Keep it simple',
  1, 75, ARRAY['Create components', 'Use component instances', 'Follow component best practices']),
  
  (v_course_id, v_module_id, 'Component Variants', 'Managing component states', 
  E'# Component Variants\n\n## What are Variants?\n\nMultiple versions of a component in one place.\n\n## Creating Variants\n\n1. Create multiple versions of component\n2. Select all versions\n3. Click "Combine as Variants"\n4. Define properties\n\n## Example: Button Variants\n\n### Properties\n- **Type**: Primary, Secondary, Tertiary\n- **Size**: Small, Medium, Large\n- **State**: Default, Hover, Pressed, Disabled\n\n## Using Variants\n\n1. Insert component\n2. Select variant properties from right panel\n3. Quickly switch between states\n\n## Interactive Components\n\n- Add prototype interactions\n- Change variant on hover/click\n- Create realistic prototypes',
  2, 85, ARRAY['Create component variants', 'Manage component states', 'Build interactive components']);

END $$;

-- AWS Cloud Practitioner
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'aws-cloud-practitioner';
  
  -- Module 1: Cloud Computing Fundamentals
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Introduction to Cloud Computing', 'Cloud concepts and benefits', 
  E'# Cloud Computing Basics\n\n## What is Cloud Computing?\n\nOn-demand delivery of IT resources over the internet with pay-as-you-go pricing.\n\n## Cloud Service Models\n\n### IaaS (Infrastructure as a Service)\n- Virtual machines\n- Storage\n- Networks\n- Example: Amazon EC2\n\n### PaaS (Platform as a Service)\n- Development platforms\n- Databases\n- Example: AWS Elastic Beanstalk\n\n### SaaS (Software as a Service)\n- Complete applications\n- Example: Gmail, Salesforce\n\n## Cloud Deployment Models\n\n1. **Public Cloud**: AWS, Azure, GCP\n2. **Private Cloud**: On-premises\n3. **Hybrid Cloud**: Mix of both\n\n## Benefits\n\n- Cost savings\n- Scalability\n- Reliability\n- Global reach\n- Security',
  1, 60, ARRAY['Understand cloud computing', 'Know service models', 'Identify cloud benefits']),
  
  (v_course_id, v_module_id, 'AWS Global Infrastructure', 'Regions, AZs, and Edge Locations', 
  E'# AWS Global Infrastructure\n\n## Regions\n\nGeographic areas with multiple data centers.\n- Examples: us-east-1, eu-west-1, ap-south-1\n- Choose based on:\n  - Latency\n  - Compliance\n  - Cost\n  - Service availability\n\n## Availability Zones (AZs)\n\n- Multiple isolated locations within each Region\n- Connected with low-latency links\n- Redundancy and fault tolerance\n- Minimum 3 AZs per Region\n\n## Edge Locations\n\n- Content Delivery Network (CDN) endpoints\n- Serve cached content\n- Lower latency for users\n- 200+ Edge Locations worldwide\n\n## Best Practices\n\n- Deploy across multiple AZs\n- Use CloudFront for global delivery\n- Choose Region closest to users',
  2, 50, ARRAY['Understand AWS infrastructure', 'Know Regions and AZs', 'Choose appropriate Regions']);

  -- Module 2: AWS Core Services
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Amazon EC2', 'Virtual servers in the cloud', 
  E'# Amazon EC2 (Elastic Compute Cloud)\n\n## What is EC2?\n\nVirtual servers in the cloud.\n\n## Instance Types\n\n### General Purpose (T3, M5)\n- Balanced compute, memory, networking\n- Web servers, development\n\n### Compute Optimized (C5)\n- High-performance processors\n- Batch processing, gaming\n\n### Memory Optimized (R5, X1)\n- Fast performance for large datasets\n- Databases, caching\n\n### Storage Optimized (I3, D2)\n- High sequential read/write\n- Data warehousing\n\n## Pricing Models\n\n1. **On-Demand**: Pay by hour/second\n2. **Reserved**: 1-3 year commitment (up to 75% savings)\n3. **Spot**: Unused capacity (up to 90% savings)\n4. **Dedicated**: Physical server\n\n## Creating an Instance\n\n1. Choose AMI (Amazon Machine Image)\n2. Select instance type\n3. Configure network\n4. Add storage\n5. Add tags\n6. Configure security group\n7. Review and launch',
  1, 85, ARRAY['Understand EC2 instances', 'Choose appropriate instance types', 'Know pricing models']),
  
  (v_course_id, v_module_id, 'Amazon S3', 'Object storage service', 
  E'# Amazon S3 (Simple Storage Service)\n\n## What is S3?\n\nObject storage for files and data.\n\n## Key Concepts\n\n### Buckets\n- Containers for objects\n- Globally unique names\n- Region-specific\n\n### Objects\n- Files stored in buckets\n- Up to 5 TB per object\n- Key-value pairs\n\n## Storage Classes\n\n1. **S3 Standard**: Frequent access\n2. **S3 Intelligent-Tiering**: Automatic optimization\n3. **S3 Standard-IA**: Infrequent access\n4. **S3 One Zone-IA**: Lower cost, less redundancy\n5. **S3 Glacier**: Archive (minutes to hours)\n6. **S3 Glacier Deep Archive**: Long-term (12 hours)\n\n## Use Cases\n\n- Backup and restore\n- Data archiving\n- Static website hosting\n- Big data analytics\n- Content distribution\n\n## Security\n\n- Bucket policies\n- Access Control Lists (ACLs)\n- Encryption at rest\n- Versioning\n- MFA Delete',
  2, 75, ARRAY['Work with S3 buckets', 'Understand storage classes', 'Implement S3 security']);

END $$;

-- React Native Mobile Development
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'react-native-mobile-development';
  
  -- Module 1: React Native Basics
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Introduction to React Native', 'Building mobile apps with React', 
  E'# React Native Fundamentals\n\n## What is React Native?\n\nBuild native mobile apps using React and JavaScript.\n\n## Setup\n\n```bash\nnpx react-native init MyApp\ncd MyApp\nnpx react-native run-ios   # iOS\nnpx react-native run-android # Android\n```\n\n## Core Components\n\n```jsx\nimport React from ''react'';\nimport { View, Text, StyleSheet } from ''react-native'';\n\nfunction App() {\n  return (\n    <View style={styles.container}>\n      <Text style={styles.text}>Hello React Native!</Text>\n    </View>\n  );\n}\n\nconst styles = StyleSheet.create({\n  container: {\n    flex: 1,\n    justifyContent: ''center'',\n    alignItems: ''center'',\n  },\n  text: {\n    fontSize: 20,\n    fontWeight: ''bold'',\n  },\n});\n\nexport default App;\n```',
  1, 70, ARRAY['Setup React Native', 'Use core components', 'Style mobile apps']),
  
  (v_course_id, v_module_id, 'Mobile UI Components', 'Building mobile interfaces', 
  E'# Mobile UI Components\n\n## Basic Components\n\n```jsx\nimport {\n  View,\n  Text,\n  Image,\n  TextInput,\n  Button,\n  ScrollView,\n  FlatList,\n  TouchableOpacity\n} from ''react-native'';\n\n// Image\n<Image\n  source={{uri: ''https://example.com/image.jpg''}}\n  style={{width: 200, height: 200}}\n/>\n\n// TextInput\n<TextInput\n  placeholder="Enter text"\n  value={text}\n  onChangeText={setText}\n  style={styles.input}\n/>\n\n// Button\n<Button\n  title="Press Me"\n  onPress={() => console.log(''Pressed'')}\n/>\n\n// Touchable\n<TouchableOpacity onPress={handlePress}>\n  <Text>Tap Me</Text>\n</TouchableOpacity>\n```\n\n## Lists\n\n```jsx\n<FlatList\n  data={items}\n  keyExtractor={item => item.id}\n  renderItem={({item}) => (\n    <Text>{item.name}</Text>\n  )}\n/>\n```',
  2, 80, ARRAY['Use React Native components', 'Handle user input', 'Render lists efficiently']);

END $$;

-- SEO Mastery Course
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'seo-mastery-course';
  
  -- Module 1: SEO Fundamentals
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'How Search Engines Work', 'Understanding search algorithms', 
  E'# Search Engine Fundamentals\n\n## How Google Works\n\n### 1. Crawling\n- Googlebot discovers pages\n- Follows links between pages\n- Finds new and updated content\n\n### 2. Indexing\n- Analyzes content\n- Processes text, images, videos\n- Stores in Google Index\n\n### 3. Ranking\n- Matches queries to indexed pages\n- Ranks by relevance\n- Considers 200+ factors\n\n## Ranking Factors\n\n### Content Quality\n- Relevance\n- Depth\n- Uniqueness\n- Freshness\n\n### Technical\n- Page speed\n- Mobile-friendliness\n- HTTPS\n- Core Web Vitals\n\n### Authority\n- Backlinks\n- Domain authority\n- Trust signals\n\n### User Experience\n- Click-through rate\n- Dwell time\n- Bounce rate',
  1, 55, ARRAY['Understand search engines', 'Know ranking factors', 'Grasp SEO fundamentals']),
  
  (v_course_id, v_module_id, 'SEO Strategy Basics', 'Planning SEO campaigns', 
  E'# SEO Strategy\n\n## SEO Types\n\n### On-Page SEO\n- Content optimization\n- Title tags\n- Meta descriptions\n- Headers (H1-H6)\n- URL structure\n- Internal linking\n\n### Off-Page SEO\n- Link building\n- Social signals\n- Brand mentions\n- Guest posting\n\n### Technical SEO\n- Site speed\n- Mobile optimization\n- XML sitemaps\n- Robots.txt\n- Structured data\n\n## SEO Process\n\n1. **Audit**: Analyze current state\n2. **Research**: Keywords and competitors\n3. **Strategy**: Create action plan\n4. **Implementation**: Make changes\n5. **Monitoring**: Track results\n6. **Optimization**: Continuous improvement\n\n## Setting Goals\n\n- Increase organic traffic\n- Improve rankings for keywords\n- Boost conversions\n- Enhance brand visibility',
  2, 60, ARRAY['Plan SEO strategies', 'Understand SEO types', 'Set SEO goals']);

  -- Module 2: Keyword Research
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Keyword Research Fundamentals', 'Finding the right keywords', 
  E'# Keyword Research\n\n## Types of Keywords\n\n### By Length\n- **Short-tail**: 1-2 words (high volume, competitive)\n- **Long-tail**: 3+ words (low volume, specific)\n\n### By Intent\n- **Informational**: "how to bake bread"\n- **Navigational**: "facebook login"\n- **Commercial**: "best laptop 2024"\n- **Transactional**: "buy iphone 15"\n\n## Keyword Metrics\n\n### Search Volume\n- Monthly searches\n- Seasonal trends\n\n### Keyword Difficulty\n- Competition level\n- Ranking difficulty (0-100)\n\n### Cost Per Click (CPC)\n- Commercial value\n- Competition indicator\n\n### Search Intent\n- User goal\n- Expected content type\n\n## Research Process\n\n1. Brainstorm seed keywords\n2. Use keyword tools\n3. Analyze competitors\n4. Check search intent\n5. Assess difficulty\n6. Prioritize keywords',
  1, 75, ARRAY['Understand keyword types', 'Use keyword metrics', 'Conduct keyword research']);

END $$;
