/*
  # Add Certificate Indexes for Performance

  1. Indexes
    - User-course lookup
    - Completion date tracking
    - Certificate number verification
*/

CREATE INDEX IF NOT EXISTS idx_certificates_user_course 
  ON certificates(user_id, course_id);

CREATE INDEX IF NOT EXISTS idx_certificates_completion_date 
  ON certificates(completion_date);

CREATE INDEX IF NOT EXISTS idx_certificates_certificate_number 
  ON certificates(certificate_number);
