/*
  # Remove Duplicate Lessons

  ## Problem
  Found multiple courses with duplicate lesson entries:
  - Same lesson title appearing multiple times in same course
  - Most duplicates have identical content (true duplicates)
  - Some duplicates have different content (need renaming, not deletion)

  ## Strategy
  Delete duplicate lessons keeping only one instance per unique (course_id, title, content) combination.
  Uses PostgreSQL's ctid (tuple identifier) to identify which rows to keep.

  ## Affected Courses
  - Entrepreneurship Essentials: "Starting a Business" (3 duplicates)
  - Ethical Hacking: Multiple lessons (3 duplicates each)
  - Flutter & Dart: Multiple lessons (3 duplicates each)
  - And 13 more courses with 2 duplicates each
*/

-- Delete duplicate lessons, keeping only the first occurrence
DELETE FROM lessons a
USING lessons b
WHERE a.course_id = b.course_id
  AND a.title = b.title
  AND a.content = b.content
  AND a.ctid > b.ctid;
