/*
  # Populate Assignments and Projects for All Courses

  1. New Data
    - Create practical assignments for each course
    - Add project-based assessments
    - Include submission guidelines and rubrics
  
  2. Assignment Types
    - Web Development: Build projects, code challenges
    - Data Science: Data analysis, model building
    - Cloud: Infrastructure setup, deployment tasks
    - Design: Design mockups, prototypes
    - Business: Case studies, presentations
    
  3. Settings
    - Due dates: 1-4 weeks from course start
    - Submission types: text, file, or both
    - Points: 50-200 points each
*/

WITH course_list AS (
  SELECT id, title, created_at FROM courses WHERE published = true
)

INSERT INTO assignments (course_id, title, description, instructions, due_date, total_points, submission_type, status)
SELECT 
  c.id,
  CASE 
    WHEN c.title LIKE '%Web%' OR c.title LIKE '%React%' THEN 'Build a Todo Application'
    WHEN c.title LIKE '%JavaScript%' THEN 'Create Interactive Website'
    WHEN c.title LIKE '%Frontend%' THEN 'Design Responsive Landing Page'
    WHEN c.title LIKE '%Data%' THEN 'Analyze Real-world Dataset'
    WHEN c.title LIKE '%AI%' OR c.title LIKE '%Machine%' THEN 'Build Predictive Model'
    WHEN c.title LIKE '%Python%' THEN 'Python Data Processing Project'
    WHEN c.title LIKE '%Cloud%' OR c.title LIKE '%AWS%' THEN 'Deploy Application to Cloud'
    WHEN c.title LIKE '%DevOps%' OR c.title LIKE '%Docker%' THEN 'Containerize Application'
    WHEN c.title LIKE '%Kubernetes%' THEN 'Deploy Microservices'
    WHEN c.title LIKE '%Design%' OR c.title LIKE '%UX%' THEN 'Create Design System'
    WHEN c.title LIKE '%Graphic%' THEN 'Design Marketing Materials'
    WHEN c.title LIKE '%Digital%Marketing%' THEN 'Plan Marketing Campaign'
    WHEN c.title LIKE '%SEO%' THEN 'Optimize Website for Search'
    WHEN c.title LIKE '%Social%' THEN 'Create Social Media Strategy'
    WHEN c.title LIKE '%Business%' OR c.title LIKE '%Leadership%' THEN 'Develop Business Plan'
    WHEN c.title LIKE '%Management%' THEN 'Project Management Case Study'
    WHEN c.title LIKE '%Security%' THEN 'Security Audit Report'
    WHEN c.title LIKE '%Mobile%' THEN 'Build Mobile App'
    WHEN c.title LIKE '%API%' THEN 'Design RESTful API'
    WHEN c.title LIKE '%Database%' THEN 'Database Design Project'
    ELSE c.title || ' - Capstone Project'
  END,
  CASE 
    WHEN c.title LIKE '%Web%' OR c.title LIKE '%React%' THEN 'Build a fully functional todo application with add, edit, delete, and filter functionality.'
    WHEN c.title LIKE '%JavaScript%' THEN 'Create an interactive website showcasing your understanding of DOM manipulation and event handling.'
    WHEN c.title LIKE '%Frontend%' THEN 'Design a responsive landing page that works seamlessly on mobile, tablet, and desktop devices.'
    WHEN c.title LIKE '%Data%' THEN 'Find an interesting dataset and perform exploratory data analysis with visualizations.'
    WHEN c.title LIKE '%AI%' OR c.title LIKE '%Machine%' THEN 'Build and train a predictive model to solve a real-world problem.'
    WHEN c.title LIKE '%Python%' THEN 'Process and analyze data using Python libraries like pandas and numpy.'
    WHEN c.title LIKE '%Cloud%' OR c.title LIKE '%AWS%' THEN 'Deploy a web application to cloud infrastructure and configure auto-scaling.'
    WHEN c.title LIKE '%DevOps%' OR c.title LIKE '%Docker%' THEN 'Create Docker containers for a multi-tier application.'
    WHEN c.title LIKE '%Kubernetes%' THEN 'Deploy and manage microservices using Kubernetes.'
    WHEN c.title LIKE '%Design%' OR c.title LIKE '%UX%' THEN 'Create a comprehensive design system with components and guidelines.'
    WHEN c.title LIKE '%Graphic%' THEN 'Design professional marketing materials including flyers and social media graphics.'
    WHEN c.title LIKE '%Digital%Marketing%' THEN 'Develop a comprehensive digital marketing campaign with strategy and tactics.'
    WHEN c.title LIKE '%SEO%' THEN 'Conduct SEO audit and implement optimization strategies.'
    WHEN c.title LIKE '%Social%' THEN 'Create 30-day social media content calendar and strategy.'
    WHEN c.title LIKE '%Business%' OR c.title LIKE '%Leadership%' THEN 'Develop a detailed business plan for a startup idea.'
    WHEN c.title LIKE '%Management%' THEN 'Analyze a case study and propose project management solutions.'
    WHEN c.title LIKE '%Security%' THEN 'Conduct comprehensive security audit and document findings.'
    WHEN c.title LIKE '%Mobile%' THEN 'Build a mobile app with core features and user authentication.'
    WHEN c.title LIKE '%API%' THEN 'Design and document a RESTful API with proper endpoints.'
    WHEN c.title LIKE '%Database%' THEN 'Design normalized database schema and implement queries.'
    ELSE 'Apply all course concepts to create a comprehensive capstone project.'
  END,
  CASE 
    WHEN c.title LIKE '%Web%' OR c.title LIKE '%React%' THEN 'Create a todo app with: 1) Add new todos, 2) Mark as complete, 3) Edit existing todos, 4) Delete todos, 5) Filter by status. Submit your code repository link.'
    WHEN c.title LIKE '%JavaScript%' THEN 'Build an interactive website with form validation, DOM manipulation, and event handlers. Include JavaScript source file.'
    WHEN c.title LIKE '%Frontend%' THEN 'Design responsive layout using CSS Grid/Flexbox. Test on multiple screen sizes. Submit HTML, CSS, and screenshots.'
    WHEN c.title LIKE '%Data%' THEN 'Clean dataset, perform analysis, create visualizations. Submit Jupyter notebook with code and analysis.'
    WHEN c.title LIKE '%AI%' OR c.title LIKE '%Machine%' THEN 'Build model, train on data, evaluate performance. Submit code, model file, and accuracy report.'
    WHEN c.title LIKE '%Python%' THEN 'Write Python scripts for data processing. Submit .py files with comments and documentation.'
    WHEN c.title LIKE '%Cloud%' OR c.title LIKE '%AWS%' THEN 'Deploy app to AWS, configure VPC, load balancer, auto-scaling. Submit architecture diagram and deployment guide.'
    WHEN c.title LIKE '%DevOps%' OR c.title LIKE '%Docker%' THEN 'Create Dockerfile, docker-compose file for multi-container app. Submit Docker files and documentation.'
    WHEN c.title LIKE '%Kubernetes%' THEN 'Create deployment manifests, services, ingress. Submit YAML files and deployment guide.'
    WHEN c.title LIKE '%Design%' OR c.title LIKE '%UX%' THEN 'Create comprehensive design system with 20+ components. Submit design file and usage guidelines.'
    WHEN c.title LIKE '%Graphic%' THEN 'Design 3-5 professional marketing materials. Submit high-resolution files in multiple formats.'
    WHEN c.title LIKE '%Digital%Marketing%' THEN 'Develop 30-day campaign plan with tactics and metrics. Submit document with strategy and implementation timeline.'
    WHEN c.title LIKE '%SEO%' THEN 'Audit real website, identify issues, propose improvements. Submit audit report with recommendations.'
    WHEN c.title LIKE '%Social%' THEN 'Create 30-day content calendar with 90 posts/ideas. Submit calendar and content strategy document.'
    WHEN c.title LIKE '%Business%' OR c.title LIKE '%Leadership%' THEN 'Write 10-page business plan including market analysis and financial projections. Submit PDF document.'
    WHEN c.title LIKE '%Management%' THEN 'Analyze case study, provide management solutions. Submit 5-page analysis with recommendations.'
    WHEN c.title LIKE '%Security%' THEN 'Perform security audit of system, document vulnerabilities. Submit detailed audit report with findings.'
    WHEN c.title LIKE '%Mobile%' THEN 'Build fully functional app with authentication. Submit code repository with APK/IPA file.'
    WHEN c.title LIKE '%API%' THEN 'Design API with 10+ endpoints, full documentation. Submit OpenAPI spec and code.'
    WHEN c.title LIKE '%Database%' THEN 'Design 3+ table schema, write complex queries. Submit schema diagram and SQL file.'
    ELSE 'Apply all course learnings to create final capstone project. Submit complete project files and documentation.'
  END,
  (c.created_at + INTERVAL '14 days')::timestamp with time zone,
  CASE 
    WHEN c.title LIKE '%Web%' OR c.title LIKE '%React%' THEN 100
    WHEN c.title LIKE '%Cloud%' OR c.title LIKE '%DevOps%' THEN 150
    WHEN c.title LIKE '%Data%' OR c.title LIKE '%AI%' THEN 125
    WHEN c.title LIKE '%Business%' THEN 100
    ELSE 100
  END,
  'both',
  'published'
FROM course_list c
ON CONFLICT DO NOTHING;
