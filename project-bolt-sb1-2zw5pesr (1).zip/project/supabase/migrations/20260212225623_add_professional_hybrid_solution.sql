/*
  # Rebrand Tutorial Programs to Professional Hybrid Solution

  1. Changes
    - Rename tutorial_programs to hybrid_solution_tracks
    - Add column to distinguish between prep classes and tutorial programs
    - Add field to track the integrated track structure
    - Update descriptions to reflect professional hybrid learning model

  2. New Structure
    - Each track now has integrated Prep Classes (structured curriculum) and Tutorial Programs (human layer coaching)
    - Programs leverage HyFlex capability - students choose mode that fits their week
    - Positioned as learning-outcome academy aligned with industry standards

  3. Migration Strategy
    - Create new table with enhanced structure
    - Copy data from existing tutorial_programs
    - Preserve all existing enrollments and relationships
    - Add marketing content about professional hybrid approach

  4. Database Changes
    - New table: hybrid_solution_tracks (replacement for tutorial_programs)
    - Updated tutorial_sessions to support both prep class and coaching layers
    - RLS policies updated for new table naming
*/

-- Create new professional hybrid solution tracks table
CREATE TABLE IF NOT EXISTS hybrid_solution_tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  full_name text NOT NULL,
  description text,
  detailed_description text,
  target_audience text,
  duration text,
  level text,
  region text,
  icon text,
  color text,
  is_active boolean DEFAULT true,
  hyflex_description text,
  prep_classes_description text,
  coaching_description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Update tutorial_sessions to support both layers
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutorial_sessions' AND column_name = 'session_type'
  ) THEN
    ALTER TABLE tutorial_sessions ADD COLUMN session_type text DEFAULT 'coaching';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutorial_sessions' AND column_name = 'is_prep_class'
  ) THEN
    ALTER TABLE tutorial_sessions ADD COLUMN is_prep_class boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutorial_sessions' AND column_name = 'delivery_mode'
  ) THEN
    ALTER TABLE tutorial_sessions ADD COLUMN delivery_mode text DEFAULT 'in-person';
  END IF;
END $$;

-- Copy existing data from tutorial_programs to hybrid_solution_tracks
INSERT INTO hybrid_solution_tracks (
  id, name, full_name, description, target_audience, 
  duration, level, region, icon, color, is_active, created_at, updated_at
)
SELECT 
  id, name, full_name, description, target_audience,
  duration, level, region, icon, color, is_active, created_at, updated_at
FROM tutorial_programs
WHERE NOT EXISTS (SELECT 1 FROM hybrid_solution_tracks WHERE hybrid_solution_tracks.id = tutorial_programs.id);

-- Update foreign key in tutorial_sessions to point to new table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'tutorial_sessions_track_id_fkey'
  ) THEN
    ALTER TABLE tutorial_sessions 
    ADD CONSTRAINT tutorial_sessions_track_id_fkey 
    FOREIGN KEY (program_id) REFERENCES hybrid_solution_tracks(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Enable RLS on new table
ALTER TABLE hybrid_solution_tracks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for hybrid solution tracks
CREATE POLICY "Anyone can view active hybrid solution tracks"
  ON hybrid_solution_tracks
  FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

-- Update tutorial_sessions RLS to work with new table structure
DROP POLICY IF EXISTS "Anyone can view active tutorial sessions" ON tutorial_sessions;
CREATE POLICY "Anyone can view active tutorial sessions"
  ON tutorial_sessions
  FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_hybrid_tracks_level ON hybrid_solution_tracks(level);
CREATE INDEX IF NOT EXISTS idx_hybrid_tracks_region ON hybrid_solution_tracks(region);
CREATE INDEX IF NOT EXISTS idx_tutorial_sessions_type ON tutorial_sessions(session_type);
CREATE INDEX IF NOT EXISTS idx_tutorial_sessions_prep_class ON tutorial_sessions(is_prep_class);
