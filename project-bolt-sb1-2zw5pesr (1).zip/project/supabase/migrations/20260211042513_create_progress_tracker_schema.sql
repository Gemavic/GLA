/*
  # Create Progress Tracker Schema

  1. New Tables
    - `student_progress`
      - `id` (uuid, primary key) - Unique identifier for each progress record
      - `user_id` (uuid, foreign key) - References auth.users
      - `subject_name` (text) - Name of the subject (e.g., Mathematics, Physics)
      - `current_score` (numeric) - Current mock average percentage (0-100)
      - `grade` (text) - Calculated grade (A, B, C, D, E, F)
      - `points` (integer) - Points earned (0-5)
      - `created_at` (timestamptz) - When the record was created
      - `updated_at` (timestamptz) - When the record was last updated
      
    - `progress_snapshots`
      - `id` (uuid, primary key) - Unique identifier for each snapshot
      - `user_id` (uuid, foreign key) - References auth.users
      - `total_points` (integer) - Total points calculated
      - `bonus_points` (integer) - Bonus points earned
      - `final_score` (integer) - Total predicted points
      - `status` (text) - Performance status (ELITE, STRONG, ACTION REQUIRED)
      - `subjects_data` (jsonb) - JSON array of subject details
      - `created_at` (timestamptz) - Snapshot timestamp

  2. Security
    - Enable RLS on both tables
    - Users can only read/write their own progress data
    - Authenticated users only

  3. Indexes
    - Index on user_id for faster queries
    - Index on created_at for historical tracking
*/

-- Create student_progress table
CREATE TABLE IF NOT EXISTS student_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  subject_name text NOT NULL,
  current_score numeric(5,2) CHECK (current_score >= 0 AND current_score <= 100) NOT NULL,
  grade text NOT NULL CHECK (grade IN ('A', 'B', 'C', 'D', 'E', 'F')),
  points integer NOT NULL CHECK (points >= 0 AND points <= 5),
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, subject_name)
);

-- Create progress_snapshots table
CREATE TABLE IF NOT EXISTS progress_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  total_points integer NOT NULL,
  bonus_points integer NOT NULL,
  final_score integer NOT NULL,
  status text NOT NULL CHECK (status IN ('ELITE', 'STRONG', 'ACTION REQUIRED')),
  subjects_data jsonb NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_student_progress_user_id ON student_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_student_progress_created_at ON student_progress(created_at);
CREATE INDEX IF NOT EXISTS idx_progress_snapshots_user_id ON progress_snapshots(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_snapshots_created_at ON progress_snapshots(created_at DESC);

-- Enable Row Level Security
ALTER TABLE student_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_snapshots ENABLE ROW LEVEL SECURITY;

-- Policies for student_progress
CREATE POLICY "Users can view own progress"
  ON student_progress FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own progress"
  ON student_progress FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
  ON student_progress FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own progress"
  ON student_progress FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies for progress_snapshots
CREATE POLICY "Users can view own snapshots"
  ON progress_snapshots FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own snapshots"
  ON progress_snapshots FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own snapshots"
  ON progress_snapshots FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update updated_at
CREATE TRIGGER update_student_progress_updated_at
  BEFORE UPDATE ON student_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();