/*
  # Gemavicedu Educational Platform Schema

  1. New Tables
    - `categories`
      - `id` (uuid, primary key)
      - `name` (text, unique) - Category name (e.g., "Programming", "Design")
      - `slug` (text, unique) - URL-friendly version
      - `description` (text) - Category description
      - `icon` (text) - Icon name for display
      - `created_at` (timestamptz)
    
    - `courses`
      - `id` (uuid, primary key)
      - `title` (text) - Course title
      - `slug` (text, unique) - URL-friendly version
      - `description` (text) - Short description
      - `full_description` (text) - Detailed description
      - `category_id` (uuid, foreign key) - Links to categories
      - `instructor_name` (text) - Instructor name
      - `instructor_title` (text) - Instructor title/credentials
      - `image_url` (text) - Course thumbnail
      - `level` (text) - Beginner, Intermediate, Advanced
      - `duration_hours` (integer) - Course duration
      - `price` (decimal) - Course price (0 for free)
      - `rating` (decimal) - Average rating
      - `total_students` (integer) - Number of enrolled students
      - `published` (boolean) - Is course published
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `lessons`
      - `id` (uuid, primary key)
      - `course_id` (uuid, foreign key) - Links to courses
      - `title` (text) - Lesson title
      - `description` (text) - Lesson description
      - `order_index` (integer) - Lesson order in course
      - `duration_minutes` (integer) - Lesson duration
      - `video_url` (text) - Video content URL
      - `content` (text) - Text content
      - `created_at` (timestamptz)
    
    - `enrollments`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - Links to auth.users
      - `course_id` (uuid, foreign key) - Links to courses
      - `enrolled_at` (timestamptz) - Enrollment date
      - `progress_percentage` (integer) - Overall progress (0-100)
      - `last_accessed` (timestamptz) - Last access date
      - `completed` (boolean) - Course completion status
      - `completed_at` (timestamptz) - Completion date
    
    - `lesson_progress`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - Links to auth.users
      - `lesson_id` (uuid, foreign key) - Links to lessons
      - `completed` (boolean) - Lesson completion status
      - `completed_at` (timestamptz) - Completion date
      - `last_position` (integer) - Video position for resume

  2. Security
    - Enable RLS on all tables
    - Public read access for categories and published courses
    - Authenticated users can enroll in courses
    - Users can only access their own enrollments and progress
*/

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  icon text DEFAULT 'book',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view categories"
  ON categories FOR SELECT
  TO public
  USING (true);

-- Courses table
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  full_description text DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  instructor_name text DEFAULT '',
  instructor_title text DEFAULT '',
  image_url text DEFAULT '',
  level text DEFAULT 'Beginner',
  duration_hours integer DEFAULT 0,
  price decimal(10,2) DEFAULT 0,
  rating decimal(3,2) DEFAULT 0,
  total_students integer DEFAULT 0,
  published boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE courses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view published courses"
  ON courses FOR SELECT
  TO public
  USING (published = true);

-- Lessons table
CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  order_index integer NOT NULL,
  duration_minutes integer DEFAULT 0,
  video_url text DEFAULT '',
  content text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view lessons for published courses"
  ON lessons FOR SELECT
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = lessons.course_id
      AND courses.published = true
    )
  );

-- Enrollments table
CREATE TABLE IF NOT EXISTS enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  enrolled_at timestamptz DEFAULT now(),
  progress_percentage integer DEFAULT 0,
  last_accessed timestamptz DEFAULT now(),
  completed boolean DEFAULT false,
  completed_at timestamptz,
  UNIQUE(user_id, course_id)
);

ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own enrollments"
  ON enrollments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own enrollments"
  ON enrollments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own enrollments"
  ON enrollments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Lesson progress table
CREATE TABLE IF NOT EXISTS lesson_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  lesson_id uuid REFERENCES lessons(id) ON DELETE CASCADE NOT NULL,
  completed boolean DEFAULT false,
  completed_at timestamptz,
  last_position integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

ALTER TABLE lesson_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own lesson progress"
  ON lesson_progress FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own lesson progress"
  ON lesson_progress FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own lesson progress"
  ON lesson_progress FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_courses_category ON courses(category_id);
CREATE INDEX IF NOT EXISTS idx_courses_published ON courses(published);
CREATE INDEX IF NOT EXISTS idx_lessons_course ON lessons(course_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_user ON enrollments(user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_course ON enrollments(course_id);
CREATE INDEX IF NOT EXISTS idx_lesson_progress_user ON lesson_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_lesson_progress_lesson ON lesson_progress(lesson_id);