/*
  # Fix Tutor Session RLS for Tutors and Admins

  1. Problem
    - Tutors cannot access whiteboard, chat, or participants in their own sessions
    - RLS policies were checking only for participant_id match
    - Tutors own sessions via tutor_id field, not participant_id

  2. Changes
    - Update session_participants SELECT policy to allow tutors to view their session participants
    - Update session_chat_messages policies to allow tutors to view/send messages in their sessions
    - Update whiteboard_snapshots policies to allow tutors to view/create snapshots in their sessions
    - Add admin access to all session-related tables

  3. Security
    - Tutors can only access data for sessions they own (tutor_id match)
    - Admins can access all session data
    - Regular participants can only access their own participation data
*/

-- Fix session_participants policies
DROP POLICY IF EXISTS "Users can view sessions they participate in" ON session_participants;

CREATE POLICY "Users can view sessions they participate in"
  ON session_participants FOR SELECT
  TO authenticated
  USING (
    participant_id = (select auth.uid())
    OR EXISTS (
      SELECT 1 FROM tutor_sessions ts
      WHERE ts.id = session_participants.session_id
      AND ts.tutor_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );

-- Fix session_chat_messages policies
DROP POLICY IF EXISTS "Participants can view session messages" ON session_chat_messages;
DROP POLICY IF EXISTS "Participants can send messages" ON session_chat_messages;

CREATE POLICY "Participants can view session messages"
  ON session_chat_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM session_participants sp
      WHERE sp.session_id = session_chat_messages.session_id
      AND sp.participant_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM tutor_sessions ts
      WHERE ts.id = session_chat_messages.session_id
      AND ts.tutor_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Participants can send messages"
  ON session_chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = (select auth.uid())
    AND (
      EXISTS (
        SELECT 1 FROM session_participants sp
        WHERE sp.session_id = session_chat_messages.session_id
        AND sp.participant_id = (select auth.uid())
      )
      OR EXISTS (
        SELECT 1 FROM tutor_sessions ts
        WHERE ts.id = session_chat_messages.session_id
        AND ts.tutor_id = (select auth.uid())
      )
      OR EXISTS (
        SELECT 1 FROM admin_users
        WHERE admin_users.user_id = (select auth.uid())
      )
    )
  );

-- Fix whiteboard_snapshots policies
DROP POLICY IF EXISTS "Participants can view whiteboard snapshots" ON whiteboard_snapshots;
DROP POLICY IF EXISTS "Participants can create whiteboard snapshots" ON whiteboard_snapshots;

CREATE POLICY "Participants can view whiteboard snapshots"
  ON whiteboard_snapshots FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM session_participants sp
      WHERE sp.session_id = whiteboard_snapshots.session_id
      AND sp.participant_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM tutor_sessions ts
      WHERE ts.id = whiteboard_snapshots.session_id
      AND ts.tutor_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Participants can create whiteboard snapshots"
  ON whiteboard_snapshots FOR INSERT
  TO authenticated
  WITH CHECK (
    created_by = (select auth.uid())
    AND (
      EXISTS (
        SELECT 1 FROM session_participants sp
        WHERE sp.session_id = whiteboard_snapshots.session_id
        AND sp.participant_id = (select auth.uid())
      )
      OR EXISTS (
        SELECT 1 FROM tutor_sessions ts
        WHERE ts.id = whiteboard_snapshots.session_id
        AND ts.tutor_id = (select auth.uid())
      )
      OR EXISTS (
        SELECT 1 FROM admin_users
        WHERE admin_users.user_id = (select auth.uid())
      )
    )
  );

-- Add tutor access to insert participants (fix the existing policy to also check tutor_id)
DROP POLICY IF EXISTS "Tutors can add participants to their sessions" ON session_participants;

CREATE POLICY "Tutors can add participants to their sessions"
  ON session_participants FOR INSERT
  TO authenticated
  WITH CHECK (
    participant_id = (select auth.uid())
    OR EXISTS (
      SELECT 1 FROM tutor_sessions ts
      WHERE ts.id = session_participants.session_id
      AND ts.tutor_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM tutor_sessions ts
      JOIN tutor_profiles tp ON ts.tutor_profile_id = tp.id
      WHERE ts.id = session_participants.session_id
      AND tp.user_id = (select auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.user_id = (select auth.uid())
    )
  );
