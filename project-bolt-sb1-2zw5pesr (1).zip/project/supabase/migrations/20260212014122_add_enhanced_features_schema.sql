/*
  # Enhanced Features Schema

  1. New Tables
    - `notifications` - Real-time notification system
    - `notification_preferences` - User notification settings
    - `certificates` - Course completion certificates
    - `leaderboard_entries` - Student rankings and points
    - `student_analytics` - Detailed learning analytics
    - `learning_recommendations` - AI-powered suggestions
    - `study_sessions` - Track study time and sessions
    - `grade_reports` - Comprehensive grade reports

  2. Security
    - Enable RLS on all tables
    - Policies for authenticated users
*/

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  type text CHECK (type IN ('info', 'success', 'warning', 'error', 'assignment', 'quiz', 'announcement', 'achievement', 'message', 'event')),
  priority text DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  is_read boolean DEFAULT false,
  read_at timestamptz,
  action_url text,
  action_label text,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Notification Preferences Table
CREATE TABLE IF NOT EXISTS notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email_notifications boolean DEFAULT true,
  push_notifications boolean DEFAULT true,
  assignment_reminders boolean DEFAULT true,
  quiz_reminders boolean DEFAULT true,
  announcement_alerts boolean DEFAULT true,
  discussion_replies boolean DEFAULT true,
  achievement_alerts boolean DEFAULT true,
  event_reminders boolean DEFAULT true,
  weekly_digest boolean DEFAULT true,
  marketing_emails boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own preferences"
  ON notification_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users update own preferences"
  ON notification_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users insert own preferences"
  ON notification_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Certificates Table
CREATE TABLE IF NOT EXISTS certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  certificate_number text UNIQUE NOT NULL,
  student_name text NOT NULL,
  course_title text NOT NULL,
  completion_date date NOT NULL,
  grade text,
  final_score numeric CHECK (final_score >= 0 AND final_score <= 100),
  instructor_name text,
  certificate_url text,
  verification_url text,
  issued_at timestamptz DEFAULT now(),
  metadata jsonb,
  UNIQUE(user_id, course_id)
);

ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own certificates"
  ON certificates FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Leaderboard Entries Table
CREATE TABLE IF NOT EXISTS leaderboard_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  display_name text NOT NULL,
  total_points integer DEFAULT 0,
  assignments_completed integer DEFAULT 0,
  quizzes_completed integer DEFAULT 0,
  discussions_posted integer DEFAULT 0,
  courses_completed integer DEFAULT 0,
  achievements_earned integer DEFAULT 0,
  study_hours numeric DEFAULT 0,
  current_streak integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  last_active timestamptz DEFAULT now(),
  rank integer,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  period text DEFAULT 'all_time' CHECK (period IN ('all_time', 'monthly', 'weekly')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, course_id, period)
);

ALTER TABLE leaderboard_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view all leaderboard entries"
  ON leaderboard_entries FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users update own leaderboard entry"
  ON leaderboard_entries FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users insert own leaderboard entry"
  ON leaderboard_entries FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Student Analytics Table
CREATE TABLE IF NOT EXISTS student_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  total_time_spent_minutes integer DEFAULT 0,
  lessons_completed integer DEFAULT 0,
  lessons_in_progress integer DEFAULT 0,
  assignments_submitted integer DEFAULT 0,
  assignments_graded integer DEFAULT 0,
  average_assignment_score numeric,
  quizzes_attempted integer DEFAULT 0,
  quizzes_passed integer DEFAULT 0,
  average_quiz_score numeric,
  discussions_created integer DEFAULT 0,
  discussion_replies integer DEFAULT 0,
  resources_downloaded integer DEFAULT 0,
  last_login timestamptz,
  login_count integer DEFAULT 0,
  average_session_minutes numeric,
  completion_rate numeric,
  engagement_score numeric,
  performance_trend text CHECK (performance_trend IN ('improving', 'stable', 'declining')),
  period_start date,
  period_end date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE student_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own analytics"
  ON student_analytics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Learning Recommendations Table
CREATE TABLE IF NOT EXISTS learning_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  recommendation_type text CHECK (recommendation_type IN ('course', 'lesson', 'resource', 'study_time', 'skill_gap', 'peer_group')),
  title text NOT NULL,
  description text NOT NULL,
  reason text,
  confidence_score numeric CHECK (confidence_score >= 0 AND confidence_score <= 100),
  target_id uuid,
  target_type text,
  priority integer DEFAULT 50 CHECK (priority >= 0 AND priority <= 100),
  is_viewed boolean DEFAULT false,
  is_acted_on boolean DEFAULT false,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE learning_recommendations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own recommendations"
  ON learning_recommendations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users update own recommendations"
  ON learning_recommendations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Study Sessions Table
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  lesson_id uuid REFERENCES lessons(id) ON DELETE CASCADE,
  session_start timestamptz NOT NULL,
  session_end timestamptz,
  duration_minutes integer,
  activity_type text CHECK (activity_type IN ('video', 'reading', 'assignment', 'quiz', 'discussion', 'practice')),
  completed boolean DEFAULT false,
  focus_score numeric CHECK (focus_score >= 0 AND focus_score <= 100),
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own study sessions"
  ON study_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users create own study sessions"
  ON study_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own study sessions"
  ON study_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Grade Reports Table
CREATE TABLE IF NOT EXISTS grade_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  report_type text DEFAULT 'midterm' CHECK (report_type IN ('midterm', 'final', 'quarterly', 'custom')),
  overall_grade text,
  overall_score numeric CHECK (overall_score >= 0 AND overall_score <= 100),
  assignment_score numeric,
  quiz_score numeric,
  participation_score numeric,
  attendance_score numeric,
  total_points_earned integer,
  total_points_possible integer,
  grade_breakdown jsonb,
  comments text,
  strengths text,
  areas_for_improvement text,
  generated_at timestamptz DEFAULT now(),
  period_start date,
  period_end date
);

ALTER TABLE grade_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own grade reports"
  ON grade_reports FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_certificates_user_id ON certificates(user_id);
CREATE INDEX IF NOT EXISTS idx_leaderboard_rank ON leaderboard_entries(rank);
CREATE INDEX IF NOT EXISTS idx_leaderboard_points ON leaderboard_entries(total_points DESC);
CREATE INDEX IF NOT EXISTS idx_student_analytics_user_course ON student_analytics(user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_study_sessions_user_id ON study_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_grade_reports_user_course ON grade_reports(user_id, course_id);

-- Function to generate certificate number
CREATE OR REPLACE FUNCTION generate_certificate_number()
RETURNS text AS $$
BEGIN
  RETURN 'CERT-' || TO_CHAR(NOW(), 'YYYY') || '-' || LPAD(FLOOR(RANDOM() * 999999)::text, 6, '0');
END;
$$ LANGUAGE plpgsql;

-- Function to update leaderboard rankings
CREATE OR REPLACE FUNCTION update_leaderboard_rankings()
RETURNS trigger AS $$
BEGIN
  WITH ranked_entries AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (PARTITION BY course_id, period ORDER BY total_points DESC, current_streak DESC) as new_rank
    FROM leaderboard_entries
    WHERE period = NEW.period AND (course_id = NEW.course_id OR (course_id IS NULL AND NEW.course_id IS NULL))
  )
  UPDATE leaderboard_entries le
  SET rank = re.new_rank
  FROM ranked_entries re
  WHERE le.id = re.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_leaderboard_rankings_trigger
AFTER INSERT OR UPDATE ON leaderboard_entries
FOR EACH ROW
EXECUTE FUNCTION update_leaderboard_rankings();
