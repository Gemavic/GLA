/*
  # Fix Course Thumbnails
  
  1. Updates
    - Add valid Pexels stock photo URLs to courses with missing thumbnails
    - Images are selected based on course subject matter for visual relevance
    
  2. Changes
    - Update 25 courses with empty image_url fields
    - All images are from Pexels with proper licensing
*/

-- Update design and creative courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1779487/pexels-photo-1779487.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'adobe-photoshop-complete';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/3803517/pexels-photo-3803517.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'figma-ui-design';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1694000/pexels-photo-1694000.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'video-editing-premiere-pro';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/853168/pexels-photo-853168.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'professional-photography-course';

-- Update cloud and infrastructure courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'aws-cloud-practitioner';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'docker-kubernetes-essentials';

-- Update AI and Machine Learning courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'deep-learning-tensorflow';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'machine-learning-a-z';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'natural-language-processing';

-- Update web development courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'django-web-framework';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'nodejs-backend-development';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'vuejs-3-complete-course';

-- Update mobile development courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'flutter-dart-complete-guide';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'react-native-mobile-development';

-- Update security courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'ethical-hacking-penetration-testing';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'network-security-fundamentals';

-- Update business and finance courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'financial-analysis-modeling';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'quickbooks-for-business';

-- Update marketing courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/270637/pexels-photo-270637.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'seo-mastery-course';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'social-media-marketing-strategy';

-- Update language courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/256417/pexels-photo-256417.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'french-language-fundamentals';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1389460/pexels-photo-1389460.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'spanish-for-beginners';

-- Update health and fitness courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'nutrition-meal-planning';
UPDATE courses SET image_url = 'https://images.pexels.com/photos/703012/pexels-photo-703012.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'personal-fitness-training';

-- Update database courses
UPDATE courses SET image_url = 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=800' WHERE slug = 'sql-database-design';