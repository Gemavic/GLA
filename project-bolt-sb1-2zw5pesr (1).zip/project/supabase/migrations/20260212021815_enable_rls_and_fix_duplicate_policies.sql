/*
  # Enable RLS and Fix Duplicate Policies

  1. Security Enhancement
    - Enable RLS on public tables that were missing it
    - Remove duplicate permissive policies
    
  2. Tables Affected
    - achievement_types (enable RLS)
    - notification_templates (enable RLS)
    - tutorial_programs (remove duplicate policy)
    
  3. Security
    - All public tables now have RLS enabled
    - Only one permissive policy per action
*/

-- Enable RLS on achievement_types
ALTER TABLE achievement_types ENABLE ROW LEVEL SECURITY;

-- Add read-only policy for achievement_types
CREATE POLICY "Anyone can view achievement types"
  ON achievement_types FOR SELECT
  TO authenticated
  USING (true);

-- Enable RLS on notification_templates
ALTER TABLE notification_templates ENABLE ROW LEVEL SECURITY;

-- Add read-only policy for notification_templates
CREATE POLICY "Anyone can view notification templates"
  ON notification_templates FOR SELECT
  TO authenticated
  USING (true);

-- Remove duplicate policy on tutorial_programs
DROP POLICY IF EXISTS "Anyone can view active tutorial programs" ON tutorial_programs;

-- Keep only the authenticated users policy which is more comprehensive
-- Policy "Authenticated users can view all tutorial programs" already exists
