/*
  # Add Missing Foreign Key Indexes

  1. Performance Optimization
    - Creates indexes on all foreign key columns that were missing them
    - Improves JOIN performance and referential integrity checks
    - Essential for scaling to thousands of users
    
  2. Tables Affected
    - achievements (user_id)
    - assignments (module_id)
    - attendance (user_id)
    - calendar_events (course_id)
    - certificates (course_id)
    - discussion_replies (discussion_id, user_id)
    - discussions (user_id)
    - grade_reports (course_id)
    - leaderboard_entries (course_id)
    - learning_recommendations (user_id)
    - mentorship_requests (course_id, student_id)
    - mentorship_sessions (course_id, request_id, student_id)
    - messages (sender_id)
    - quiz_answers (attempt_id, question_id)
    - quiz_attempts (quiz_id)
    - quiz_questions (quiz_id)
    - quizzes (lesson_id, module_id)
    - student_analytics (course_id)
    - study_materials (course_id, module_id)
    - study_sessions (course_id, lesson_id)
    - tutorial_sessions (instructor_id)
*/

-- Achievements table
CREATE INDEX IF NOT EXISTS idx_achievements_user_id ON achievements(user_id);

-- Assignments table
CREATE INDEX IF NOT EXISTS idx_assignments_module_id ON assignments(module_id);

-- Attendance table
CREATE INDEX IF NOT EXISTS idx_attendance_user_id ON attendance(user_id);

-- Calendar events table
CREATE INDEX IF NOT EXISTS idx_calendar_events_course_id ON calendar_events(course_id);

-- Certificates table
CREATE INDEX IF NOT EXISTS idx_certificates_course_id ON certificates(course_id);

-- Discussion replies table
CREATE INDEX IF NOT EXISTS idx_discussion_replies_discussion_id ON discussion_replies(discussion_id);
CREATE INDEX IF NOT EXISTS idx_discussion_replies_user_id ON discussion_replies(user_id);

-- Discussions table
CREATE INDEX IF NOT EXISTS idx_discussions_user_id ON discussions(user_id);

-- Grade reports table
CREATE INDEX IF NOT EXISTS idx_grade_reports_course_id ON grade_reports(course_id);

-- Leaderboard entries table
CREATE INDEX IF NOT EXISTS idx_leaderboard_entries_course_id ON leaderboard_entries(course_id);

-- Learning recommendations table
CREATE INDEX IF NOT EXISTS idx_learning_recommendations_user_id ON learning_recommendations(user_id);

-- Mentorship requests table
CREATE INDEX IF NOT EXISTS idx_mentorship_requests_course_id ON mentorship_requests(course_id);
CREATE INDEX IF NOT EXISTS idx_mentorship_requests_student_id ON mentorship_requests(student_id);

-- Mentorship sessions table
CREATE INDEX IF NOT EXISTS idx_mentorship_sessions_course_id ON mentorship_sessions(course_id);
CREATE INDEX IF NOT EXISTS idx_mentorship_sessions_request_id ON mentorship_sessions(request_id);
CREATE INDEX IF NOT EXISTS idx_mentorship_sessions_student_id ON mentorship_sessions(student_id);

-- Messages table
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);

-- Quiz answers table
CREATE INDEX IF NOT EXISTS idx_quiz_answers_attempt_id ON quiz_answers(attempt_id);
CREATE INDEX IF NOT EXISTS idx_quiz_answers_question_id ON quiz_answers(question_id);

-- Quiz attempts table
CREATE INDEX IF NOT EXISTS idx_quiz_attempts_quiz_id ON quiz_attempts(quiz_id);

-- Quiz questions table
CREATE INDEX IF NOT EXISTS idx_quiz_questions_quiz_id ON quiz_questions(quiz_id);

-- Quizzes table
CREATE INDEX IF NOT EXISTS idx_quizzes_lesson_id ON quizzes(lesson_id);
CREATE INDEX IF NOT EXISTS idx_quizzes_module_id ON quizzes(module_id);

-- Student analytics table
CREATE INDEX IF NOT EXISTS idx_student_analytics_course_id ON student_analytics(course_id);

-- Study materials table
CREATE INDEX IF NOT EXISTS idx_study_materials_course_id ON study_materials(course_id);
CREATE INDEX IF NOT EXISTS idx_study_materials_module_id ON study_materials(module_id);

-- Study sessions table
CREATE INDEX IF NOT EXISTS idx_study_sessions_course_id ON study_sessions(course_id);
CREATE INDEX IF NOT EXISTS idx_study_sessions_lesson_id ON study_sessions(lesson_id);

-- Tutorial sessions table
CREATE INDEX IF NOT EXISTS idx_tutorial_sessions_instructor_id ON tutorial_sessions(instructor_id);
