/*
  # Populate Data Science, AI and Cloud Courses

  1. Courses Covered
    - Deep Learning with TensorFlow (7 modules)
    - Natural Language Processing (8 modules)
    - SQL & Database Design (8 modules)
    - Docker & Kubernetes Essentials (8 modules)

  2. Comprehensive lessons with examples
  3. Total: 60+ new lessons
*/

-- Deep Learning with TensorFlow
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'deep-learning-tensorflow';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'TensorFlow Basics', 'Introduction to TensorFlow',
  E'# TensorFlow Fundamentals\n\n```python\nimport tensorflow as tf\nimport numpy as np\n\n# Tensors\nscalar = tf.constant(42)\nvector = tf.constant([1, 2, 3])\nmatrix = tf.constant([[1, 2], [3, 4]])\n\n# Operations\na = tf.constant([[1, 2], [3, 4]])\nb = tf.constant([[5, 6], [7, 8]])\n\nsum = tf.add(a, b)\nproduct = tf.matmul(a, b)\n\n# Variables\nweight = tf.Variable([[1.0, 2.0], [3.0, 4.0]])\nweight.assign([[2.0, 3.0], [4.0, 5.0]])\n\n# Automatic differentiation\nx = tf.Variable(3.0)\nwith tf.GradientTape() as tape:\n    y = x ** 2\ngrad = tape.gradient(y, x)\nprint(grad)  # 6.0\n```',
  1, 75, ARRAY['Understand TensorFlow basics', 'Work with tensors', 'Use automatic differentiation']),
  
  (v_course_id, v_module_id, 'Building Neural Networks', 'Creating deep learning models',
  E'# Neural Networks with Keras\n\n```python\nimport tensorflow as tf\nfrom tensorflow import keras\n\n# Sequential API\nmodel = keras.Sequential([\n    keras.layers.Dense(128, activation=''relu'', input_shape=(784,)),\n    keras.layers.Dropout(0.2),\n    keras.layers.Dense(64, activation=''relu''),\n    keras.layers.Dropout(0.2),\n    keras.layers.Dense(10, activation=''softmax'')\n])\n\n# Compile\nmodel.compile(\n    optimizer=''adam'',\n    loss=''sparse_categorical_crossentropy'',\n    metrics=[''accuracy'']\n)\n\n# Train\nhistory = model.fit(\n    X_train, y_train,\n    epochs=10,\n    batch_size=32,\n    validation_split=0.2,\n    callbacks=[keras.callbacks.EarlyStopping(patience=3)]\n)\n\n# Evaluate\ntest_loss, test_acc = model.evaluate(X_test, y_test)\nprint(f''Test accuracy: {test_acc}'')\n```',
  2, 90, ARRAY['Build neural networks', 'Train deep learning models', 'Evaluate model performance']),
  
  (v_course_id, v_module_id, 'Convolutional Neural Networks', 'Image classification with CNNs',
  E'# CNN Architecture\n\n```python\nimport tensorflow as tf\nfrom tensorflow import keras\n\nmodel = keras.Sequential([\n    # Conv Block 1\n    keras.layers.Conv2D(32, (3, 3), activation=''relu'', input_shape=(28, 28, 1)),\n    keras.layers.MaxPooling2D((2, 2)),\n    \n    # Conv Block 2\n    keras.layers.Conv2D(64, (3, 3), activation=''relu''),\n    keras.layers.MaxPooling2D((2, 2)),\n    \n    # Conv Block 3\n    keras.layers.Conv2D(64, (3, 3), activation=''relu''),\n    \n    # Dense layers\n    keras.layers.Flatten(),\n    keras.layers.Dense(64, activation=''relu''),\n    keras.layers.Dropout(0.5),\n    keras.layers.Dense(10, activation=''softmax'')\n])\n\nmodel.compile(\n    optimizer=''adam'',\n    loss=''sparse_categorical_crossentropy'',\n    metrics=[''accuracy'']\n)\n\nmodel.summary()\n```',
  3, 100, ARRAY['Build CNN architectures', 'Process image data', 'Train image classifiers']);
  
  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Transfer Learning', 'Using pre-trained models',
  E'# Transfer Learning\n\n```python\nfrom tensorflow.keras.applications import ResNet50\nfrom tensorflow.keras.layers import Dense, GlobalAveragePooling2D\nfrom tensorflow.keras.models import Model\n\n# Load pre-trained model\nbase_model = ResNet50(weights=''imagenet'', include_top=False, input_shape=(224, 224, 3))\n\n# Freeze base model\nbase_model.trainable = False\n\n# Add custom layers\nx = base_model.output\nx = GlobalAveragePooling2D()(x)\nx = Dense(1024, activation=''relu'')(x)\noutput = Dense(10, activation=''softmax'')(x)\n\nmodel = Model(inputs=base_model.input, outputs=output)\n\nmodel.compile(\n    optimizer=''adam'',\n    loss=''categorical_crossentropy'',\n    metrics=[''accuracy'']\n)\n\n# Train only top layers\nmodel.fit(X_train, y_train, epochs=10)\n\n# Fine-tune\nbase_model.trainable = True\nfor layer in base_model.layers[:-20]:\n    layer.trainable = False\n\nmodel.compile(\n    optimizer=keras.optimizers.Adam(1e-5),\n    loss=''categorical_crossentropy'',\n    metrics=[''accuracy'']\n)\n\nmodel.fit(X_train, y_train, epochs=5)\n```',
  1, 95, ARRAY['Use pre-trained models', 'Implement transfer learning', 'Fine-tune models']);

END $$;

-- Natural Language Processing
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'natural-language-processing';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Text Preprocessing', 'Preparing text data',
  E'# Text Preprocessing\n\n```python\nimport nltk\nfrom nltk.tokenize import word_tokenize, sent_tokenize\nfrom nltk.corpus import stopwords\nfrom nltk.stem import PorterStemmer, WordNetLemmatizer\nimport re\n\n# Download resources\nnltk.download(''punkt'')\nnltk.download(''stopwords'')\nnltk.download(''wordnet'')\n\ntext = "Hello! This is an example sentence. Natural Language Processing is amazing."\n\n# Tokenization\nwords = word_tokenize(text)\nsentences = sent_tokenize(text)\n\n# Lowercasing\nwords_lower = [w.lower() for w in words]\n\n# Remove punctuation\nwords_clean = [re.sub(r''[^\\w\\s]'', '''', w) for w in words_lower]\n\n# Remove stopwords\nstop_words = set(stopwords.words(''english''))\nfiltered = [w for w in words_clean if w not in stop_words and w]\n\n# Stemming\nstemmer = PorterStemmer()\nstemmed = [stemmer.stem(w) for w in filtered]\n\n# Lemmatization\nlemmatizer = WordNetLemmatizer()\nlemmatized = [lemmatizer.lemmatize(w) for w in filtered]\n\nprint(f''Original: {words}'')\nprint(f''Cleaned: {filtered}'')\nprint(f''Lemmatized: {lemmatized}'')\n```',
  1, 80, ARRAY['Tokenize text', 'Clean text data', 'Apply stemming and lemmatization']),
  
  (v_course_id, v_module_id, 'Text Vectorization', 'Converting text to numbers',
  E'# Text Vectorization\n\n```python\nfrom sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer\n\ncorpus = [\n    ''This is the first document.'',\n    ''This document is the second document.'',\n    ''And this is the third one.'',\n    ''Is this the first document?''\n]\n\n# Bag of Words\nvectorizer = CountVectorizer()\nX = vectorizer.fit_transform(corpus)\nprint(vectorizer.get_feature_names_out())\nprint(X.toarray())\n\n# TF-IDF\ntfidf = TfidfVectorizer()\nX_tfidf = tfidf.fit_transform(corpus)\nprint(X_tfidf.toarray())\n\n# Word Embeddings with Gensim\nfrom gensim.models import Word2Vec\n\nsentences = [doc.split() for doc in corpus]\nmodel = Word2Vec(sentences, vector_size=100, window=5, min_count=1)\n\n# Get vector for word\nvector = model.wv[''document'']\nsimilar = model.wv.most_similar(''document'', topn=3)\n```',
  2, 85, ARRAY['Create bag of words', 'Use TF-IDF', 'Work with word embeddings']),
  
  (v_course_id, v_module_id, 'Text Classification', 'Building classifiers',
  E'# Text Classification\n\n```python\nfrom sklearn.feature_extraction.text import TfidfVectorizer\nfrom sklearn.naive_bayes import MultinomialNB\nfrom sklearn.pipeline import Pipeline\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.metrics import classification_report\n\n# Sample data\ntexts = [...]\nlabels = [...]\n\nX_train, X_test, y_train, y_test = train_test_split(texts, labels, test_size=0.2)\n\n# Create pipeline\npipeline = Pipeline([\n    (''tfidf'', TfidfVectorizer()),\n    (''clf'', MultinomialNB())\n])\n\n# Train\npipeline.fit(X_train, y_train)\n\n# Predict\ny_pred = pipeline.predict(X_test)\n\n# Evaluate\nprint(classification_report(y_test, y_pred))\n\n# Use with new text\nnew_text = ["This is a new document"]\nprediction = pipeline.predict(new_text)\n```',
  3, 90, ARRAY['Build text classifiers', 'Train NLP models', 'Evaluate classification performance']);

  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Named Entity Recognition', 'Extracting entities from text',
  E'# Named Entity Recognition\n\n```python\nimport spacy\n\n# Load model\nnlp = spacy.load(''en_core_web_sm'')\n\ntext = "Apple Inc. was founded by Steve Jobs in Cupertino, California on April 1, 1976."\n\n# Process text\ndoc = nlp(text)\n\n# Extract entities\nfor ent in doc.ents:\n    print(f''{ent.text} ({ent.label_})'')\n\n# Visualize\nfrom spacy import displacy\ndisplacy.render(doc, style=''ent'', jupyter=True)\n\n# Custom NER with training\nfrom spacy.training import Example\n\ntrain_data = [\n    ("Apple is a tech company", {"entities": [(0, 5, "ORG")]}),\n    ("Steve lives in California", {"entities": [(0, 5, "PERSON"), (15, 25, "GPE")]})\n]\n\n# Train model\nfor epoch in range(10):\n    for text, annotations in train_data:\n        doc = nlp.make_doc(text)\n        example = Example.from_dict(doc, annotations)\n        nlp.update([example])\n```',
  1, 85, ARRAY['Perform NER', 'Extract entities', 'Train custom NER models']);

END $$;

-- SQL & Database Design
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'sql-database-design';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'SQL Fundamentals', 'Basic SQL operations',
  E'# SQL Basics\n\n```sql\n-- SELECT\nSELECT * FROM users;\nSELECT name, email FROM users WHERE age > 25;\nSELECT COUNT(*) FROM orders;\n\n-- INSERT\nINSERT INTO users (name, email, age) VALUES (''Alice'', ''alice@example.com'', 30);\n\n-- UPDATE\nUPDATE users SET age = 31 WHERE email = ''alice@example.com'';\n\n-- DELETE\nDELETE FROM users WHERE id = 5;\n\n-- WHERE conditions\nSELECT * FROM products WHERE price BETWEEN 10 AND 50;\nSELECT * FROM users WHERE name LIKE ''A%'';\nSELECT * FROM orders WHERE status IN (''pending'', ''shipped'');\n\n-- ORDER BY\nSELECT * FROM products ORDER BY price DESC;\n\n-- LIMIT\nSELECT * FROM products ORDER BY price DESC LIMIT 10;\n\n-- DISTINCT\nSELECT DISTINCT category FROM products;\n```',
  1, 70, ARRAY['Write SQL queries', 'Perform CRUD operations', 'Filter and sort data']),
  
  (v_course_id, v_module_id, 'JOINs and Relationships', 'Combining data from multiple tables',
  E'# SQL JOINs\n\n```sql\n-- INNER JOIN\nSELECT users.name, orders.total\nFROM users\nINNER JOIN orders ON users.id = orders.user_id;\n\n-- LEFT JOIN\nSELECT users.name, orders.total\nFROM users\nLEFT JOIN orders ON users.id = orders.user_id;\n\n-- RIGHT JOIN\nSELECT users.name, orders.total\nFROM users\nRIGHT JOIN orders ON users.id = orders.user_id;\n\n-- Multiple JOINs\nSELECT \n    users.name,\n    orders.id as order_id,\n    products.name as product_name,\n    order_items.quantity\nFROM users\nJOIN orders ON users.id = orders.user_id\nJOIN order_items ON orders.id = order_items.order_id\nJOIN products ON order_items.product_id = products.id;\n\n-- Self JOIN\nSELECT \n    e.name as employee,\n    m.name as manager\nFROM employees e\nLEFT JOIN employees m ON e.manager_id = m.id;\n```',
  2, 85, ARRAY['Use different JOIN types', 'Combine multiple tables', 'Understand relationships']),
  
  (v_course_id, v_module_id, 'Aggregate Functions', 'Summarizing data',
  E'# SQL Aggregation\n\n```sql\n-- Basic aggregates\nSELECT COUNT(*) FROM users;\nSELECT AVG(price) FROM products;\nSELECT SUM(total) FROM orders;\nSELECT MIN(price), MAX(price) FROM products;\n\n-- GROUP BY\nSELECT category, COUNT(*) as product_count\nFROM products\nGROUP BY category;\n\nSELECT category, AVG(price) as avg_price\nFROM products\nGROUP BY category\nORDER BY avg_price DESC;\n\n-- HAVING\nSELECT category, COUNT(*) as count\nFROM products\nGROUP BY category\nHAVING COUNT(*) > 10;\n\n-- Complex aggregation\nSELECT \n    users.name,\n    COUNT(orders.id) as order_count,\n    SUM(orders.total) as total_spent,\n    AVG(orders.total) as avg_order\nFROM users\nLEFT JOIN orders ON users.id = orders.user_id\nGROUP BY users.id, users.name\nHAVING COUNT(orders.id) > 5\nORDER BY total_spent DESC;\n```',
  3, 80, ARRAY['Use aggregate functions', 'Group data', 'Filter aggregated results']);

  -- Module 2
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 2;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Database Design Principles', 'Designing effective schemas',
  E'# Database Design\n\n## Normalization\n\n### First Normal Form (1NF)\n- Atomic values (no arrays or lists)\n- Each column has unique name\n- Each row is unique\n\n### Second Normal Form (2NF)\n- Must be in 1NF\n- No partial dependencies\n\n### Third Normal Form (3NF)\n- Must be in 2NF\n- No transitive dependencies\n\n## Example Schema\n\n```sql\n-- Users table\nCREATE TABLE users (\n    id SERIAL PRIMARY KEY,\n    email VARCHAR(255) UNIQUE NOT NULL,\n    name VARCHAR(100) NOT NULL,\n    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\n-- Orders table\nCREATE TABLE orders (\n    id SERIAL PRIMARY KEY,\n    user_id INTEGER REFERENCES users(id),\n    total DECIMAL(10, 2) NOT NULL,\n    status VARCHAR(20) DEFAULT ''pending'',\n    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\n-- Products table\nCREATE TABLE products (\n    id SERIAL PRIMARY KEY,\n    name VARCHAR(200) NOT NULL,\n    price DECIMAL(10, 2) NOT NULL,\n    category VARCHAR(50)\n);\n\n-- Order items (junction table)\nCREATE TABLE order_items (\n    id SERIAL PRIMARY KEY,\n    order_id INTEGER REFERENCES orders(id),\n    product_id INTEGER REFERENCES products(id),\n    quantity INTEGER NOT NULL,\n    price DECIMAL(10, 2) NOT NULL\n);\n```',
  1, 90, ARRAY['Apply normalization principles', 'Design database schemas', 'Create relationships']);

END $$;

-- Docker & Kubernetes Essentials
DO $$
DECLARE
  v_course_id uuid;
  v_module_id uuid;
BEGIN
  SELECT id INTO v_course_id FROM courses WHERE slug = 'docker-kubernetes-essentials';
  
  -- Module 1
  SELECT id INTO v_module_id FROM course_modules WHERE course_id = v_course_id AND order_index = 1;
  INSERT INTO lessons (course_id, module_id, title, description, content, order_index, duration_minutes, learning_objectives) VALUES
  (v_course_id, v_module_id, 'Docker Fundamentals', 'Introduction to containers',
  E'# Docker Basics\n\n## Running Containers\n\n```bash\n# Pull image\ndocker pull nginx\n\n# Run container\ndocker run -d -p 8080:80 --name mynginx nginx\n\n# List running containers\ndocker ps\n\n# Stop container\ndocker stop mynginx\n\n# Remove container\ndocker rm mynginx\n\n# View logs\ndocker logs mynginx\n\n# Execute command in container\ndocker exec -it mynginx bash\n```\n\n## Dockerfile\n\n```dockerfile\nFROM node:18-alpine\n\nWORKDIR /app\n\nCOPY package*.json ./\nRUN npm install\n\nCOPY . .\n\nEXPOSE 3000\n\nCMD ["npm", "start"]\n```\n\n```bash\n# Build image\ndocker build -t myapp:1.0 .\n\n# Run image\ndocker run -d -p 3000:3000 myapp:1.0\n```',
  1, 75, ARRAY['Use Docker containers', 'Create Dockerfiles', 'Build and run images']),
  
  (v_course_id, v_module_id, 'Docker Compose', 'Multi-container applications',
  E'# Docker Compose\n\n```yaml\n# docker-compose.yml\nversion: ''3.8''\n\nservices:\n  web:\n    build: .\n    ports:\n      - "3000:3000"\n    environment:\n      - DATABASE_URL=postgresql://db:5432/myapp\n    depends_on:\n      - db\n    volumes:\n      - ./src:/app/src\n  \n  db:\n    image: postgres:15\n    environment:\n      POSTGRES_PASSWORD: password\n      POSTGRES_DB: myapp\n    volumes:\n      - postgres_data:/var/lib/postgresql/data\n    ports:\n      - "5432:5432"\n  \n  redis:\n    image: redis:7-alpine\n    ports:\n      - "6379:6379"\n\nvolumes:\n  postgres_data:\n```\n\n```bash\n# Start all services\ndocker-compose up -d\n\n# View logs\ndocker-compose logs -f\n\n# Stop services\ndocker-compose down\n\n# Rebuild\ndocker-compose up -d --build\n```',
  2, 80, ARRAY['Use Docker Compose', 'Define multi-container apps', 'Manage services']);

END $$;
