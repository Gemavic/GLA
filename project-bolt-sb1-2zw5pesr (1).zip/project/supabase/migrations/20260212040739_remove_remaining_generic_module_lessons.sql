/*
  # Remove Remaining Generic Module Lessons

  ## Problem
  After removing "Core Concepts" generic lessons, found additional generic template lessons:
  - "Module X - Practical Application" lessons (identical generic content)
  - "Module X - Advanced Topics" lessons (identical generic content)

  ## Template Patterns
  
  ### Practical Application Template:
  - "Put your knowledge into practice with real-world scenarios"
  - "Planning, Implementation, Optimization"
  - "Start with simple examples, Build complexity gradually"
  - Generic 945-character template

  ### Advanced Topics Template:
  - "Professional Techniques, Take your skills to the next level"
  - "Optimization, Professional Development"
  - Generic content with no course specificity

  ## Solution
  Remove all remaining generic module template lessons to ensure only 
  genuine, course-specific educational content remains.
*/

-- Delete generic "Practical Application" module lessons
DELETE FROM lessons
WHERE title LIKE 'Module % - Practical Application'
  AND content LIKE '%Put your knowledge into practice with real-world scenarios%'
  AND content LIKE '%Start with simple examples%Build complexity gradually%';

-- Delete generic "Advanced Topics" module lessons
DELETE FROM lessons
WHERE title LIKE 'Module % - Advanced Topics'
  AND content LIKE '%Professional Techniques%Take your skills to the next level%'
  AND content LIKE '%Optimization%Professional Development%';
