/*
  # Seed Enhanced Features Data

  1. Sample Data
    - Sample notifications
    - Sample leaderboard entries
    - Sample learning recommendations
    - Sample analytics data

  2. Purpose
    - Demonstrate new features
    - Enable testing of enhanced dashboard
*/

-- Sample Notifications (will need actual user_id)
-- Creating notification templates that can be used

CREATE TABLE IF NOT EXISTS notification_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key text UNIQUE NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL,
  priority text DEFAULT 'normal'
);

INSERT INTO notification_templates (template_key, title, message, type, priority)
VALUES
('assignment_due_soon', 'Assignment Due Soon', 'Your assignment "{assignment_title}" is due in {days} days', 'assignment', 'high'),
('quiz_available', 'New Quiz Available', 'A new quiz "{quiz_title}" is now available for {course_title}', 'quiz', 'normal'),
('achievement_earned', 'Achievement Unlocked!', 'Congratulations! You earned the "{achievement_title}" badge', 'achievement', 'normal'),
('course_completed', 'Course Completed!', 'You have successfully completed {course_title}', 'success', 'high'),
('new_announcement', 'New Announcement', 'New announcement posted in {course_title}', 'announcement', 'normal'),
('discussion_reply', 'New Reply', '{user_name} replied to your discussion', 'message', 'normal'),
('mentor_session_scheduled', 'Mentoring Session Scheduled', 'Your mentoring session is scheduled for {date} at {time}', 'event', 'high'),
('grade_posted', 'Grade Posted', 'Your grade for "{item_title}" has been posted', 'info', 'normal'),
('certificate_ready', 'Certificate Available', 'Your certificate for {course_title} is ready to download', 'success', 'high'),
('study_streak', 'Keep It Up!', 'You''re on a {days}-day learning streak!', 'success', 'normal')
ON CONFLICT (template_key) DO NOTHING;

-- Sample Leaderboard Entries (for demonstration)
-- These would normally be created automatically as users progress

-- Sample Learning Recommendations Templates
INSERT INTO learning_recommendations (user_id, recommendation_type, title, description, reason, confidence_score, priority)
SELECT 
  u.id,
  'course',
  'Advanced ' || c.title,
  'Based on your progress in ' || c.title || ', we recommend this advanced course to deepen your knowledge.',
  'You''ve shown strong performance in related topics',
  85,
  80
FROM auth.users u
CROSS JOIN LATERAL (
  SELECT id, title FROM courses WHERE published = true ORDER BY RANDOM() LIMIT 1
) c
LIMIT 3
ON CONFLICT DO NOTHING;

-- Sample Analytics Summary Function
CREATE OR REPLACE FUNCTION initialize_student_analytics(p_user_id uuid)
RETURNS void AS $$
BEGIN
  INSERT INTO student_analytics (
    user_id,
    course_id,
    total_time_spent_minutes,
    lessons_completed,
    average_assignment_score,
    average_quiz_score,
    engagement_score,
    performance_trend,
    period_start,
    period_end
  )
  SELECT 
    p_user_id,
    e.course_id,
    FLOOR(RANDOM() * 300 + 100)::integer,
    FLOOR(RANDOM() * 20 + 5)::integer,
    ROUND((RANDOM() * 30 + 70)::numeric, 2),
    ROUND((RANDOM() * 30 + 70)::numeric, 2),
    ROUND((RANDOM() * 40 + 60)::numeric, 2),
    CASE 
      WHEN RANDOM() < 0.6 THEN 'improving'
      WHEN RANDOM() < 0.9 THEN 'stable'
      ELSE 'declining'
    END,
    CURRENT_DATE - interval '30 days',
    CURRENT_DATE
  FROM enrollments e
  WHERE e.user_id = p_user_id
  ON CONFLICT DO NOTHING;
END;
$$ LANGUAGE plpgsql;

-- Sample Certificate Generation Function
CREATE OR REPLACE FUNCTION generate_course_certificate(
  p_user_id uuid,
  p_course_id uuid,
  p_student_name text,
  p_final_score numeric
)
RETURNS uuid AS $$
DECLARE
  v_cert_id uuid;
  v_course_title text;
  v_cert_number text;
BEGIN
  -- Get course title
  SELECT title INTO v_course_title FROM courses WHERE id = p_course_id;
  
  -- Generate unique certificate number
  v_cert_number := generate_certificate_number();
  
  -- Create certificate
  INSERT INTO certificates (
    user_id,
    course_id,
    certificate_number,
    student_name,
    course_title,
    completion_date,
    grade,
    final_score,
    instructor_name,
    verification_url
  )
  VALUES (
    p_user_id,
    p_course_id,
    v_cert_number,
    p_student_name,
    v_course_title,
    CURRENT_DATE,
    CASE 
      WHEN p_final_score >= 90 THEN 'A'
      WHEN p_final_score >= 80 THEN 'B'
      WHEN p_final_score >= 70 THEN 'C'
      WHEN p_final_score >= 60 THEN 'D'
      ELSE 'F'
    END,
    p_final_score,
    'Gemavicedu Instructor',
    'https://verify.gemavicedu.com/' || v_cert_number
  )
  RETURNING id INTO v_cert_id;
  
  -- Create notification
  INSERT INTO notifications (
    user_id,
    title,
    message,
    type,
    priority,
    action_url,
    action_label
  )
  VALUES (
    p_user_id,
    'Certificate Available!',
    'Congratulations! Your certificate for ' || v_course_title || ' is ready to download.',
    'success',
    'high',
    '/certificates/' || v_cert_id,
    'Download Certificate'
  );
  
  RETURN v_cert_id;
END;
$$ LANGUAGE plpgsql;

-- Function to update leaderboard entry
CREATE OR REPLACE FUNCTION update_student_leaderboard(p_user_id uuid)
RETURNS void AS $$
DECLARE
  v_display_name text;
  v_total_points integer;
  v_assignments_completed integer;
  v_quizzes_completed integer;
  v_discussions integer;
  v_courses_completed integer;
  v_achievements integer;
BEGIN
  -- Get user display name (email prefix for now)
  SELECT split_part(email, '@', 1) INTO v_display_name
  FROM auth.users WHERE id = p_user_id;
  
  -- Calculate total points
  SELECT 
    COALESCE(SUM(score), 0) INTO v_total_points
  FROM assignment_submissions
  WHERE user_id = p_user_id AND status = 'graded';
  
  -- Count assignments completed
  SELECT COUNT(*) INTO v_assignments_completed
  FROM assignment_submissions
  WHERE user_id = p_user_id AND status IN ('submitted', 'graded');
  
  -- Count quizzes completed
  SELECT COUNT(*) INTO v_quizzes_completed
  FROM quiz_attempts
  WHERE user_id = p_user_id AND status = 'completed';
  
  -- Count discussions
  SELECT COUNT(*) INTO v_discussions
  FROM discussions
  WHERE user_id = p_user_id;
  
  -- Count completed courses
  SELECT COUNT(*) INTO v_courses_completed
  FROM enrollments
  WHERE user_id = p_user_id AND completed = true;
  
  -- Count achievements
  SELECT COUNT(*) INTO v_achievements
  FROM achievements
  WHERE user_id = p_user_id;
  
  -- Update or insert leaderboard entry
  INSERT INTO leaderboard_entries (
    user_id,
    display_name,
    total_points,
    assignments_completed,
    quizzes_completed,
    discussions_posted,
    courses_completed,
    achievements_earned,
    period
  )
  VALUES (
    p_user_id,
    v_display_name,
    v_total_points,
    v_assignments_completed,
    v_quizzes_completed,
    v_discussions,
    v_courses_completed,
    v_achievements,
    'all_time'
  )
  ON CONFLICT (user_id, course_id, period) 
  WHERE course_id IS NULL
  DO UPDATE SET
    total_points = EXCLUDED.total_points,
    assignments_completed = EXCLUDED.assignments_completed,
    quizzes_completed = EXCLUDED.quizzes_completed,
    discussions_posted = EXCLUDED.discussions_posted,
    courses_completed = EXCLUDED.courses_completed,
    achievements_earned = EXCLUDED.achievements_earned,
    last_active = now(),
    updated_at = now();
END;
$$ LANGUAGE plpgsql;

-- Create sample grade report function
CREATE OR REPLACE FUNCTION generate_grade_report(
  p_user_id uuid,
  p_course_id uuid
)
RETURNS uuid AS $$
DECLARE
  v_report_id uuid;
  v_assignment_avg numeric;
  v_quiz_avg numeric;
  v_overall numeric;
  v_grade text;
BEGIN
  -- Calculate assignment average
  SELECT COALESCE(AVG(score), 0) INTO v_assignment_avg
  FROM assignment_submissions
  WHERE user_id = p_user_id AND status = 'graded';
  
  -- Calculate quiz average
  SELECT COALESCE(AVG(score), 0) INTO v_quiz_avg
  FROM quiz_attempts
  WHERE user_id = p_user_id AND status = 'completed';
  
  -- Calculate overall (weighted)
  v_overall := (v_assignment_avg * 0.6) + (v_quiz_avg * 0.4);
  
  -- Determine grade
  v_grade := CASE 
    WHEN v_overall >= 90 THEN 'A'
    WHEN v_overall >= 80 THEN 'B'
    WHEN v_overall >= 70 THEN 'C'
    WHEN v_overall >= 60 THEN 'D'
    ELSE 'F'
  END;
  
  -- Create report
  INSERT INTO grade_reports (
    user_id,
    course_id,
    report_type,
    overall_grade,
    overall_score,
    assignment_score,
    quiz_score,
    participation_score,
    period_start,
    period_end
  )
  VALUES (
    p_user_id,
    p_course_id,
    'final',
    v_grade,
    v_overall,
    v_assignment_avg,
    v_quiz_avg,
    75.0,
    CURRENT_DATE - interval '90 days',
    CURRENT_DATE
  )
  RETURNING id INTO v_report_id;
  
  RETURN v_report_id;
END;
$$ LANGUAGE plpgsql;
