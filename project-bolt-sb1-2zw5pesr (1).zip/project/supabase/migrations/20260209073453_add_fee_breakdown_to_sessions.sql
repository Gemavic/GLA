/*
  # Add Fee Breakdown Structure to Tutorial Sessions

  1. Changes
    - Add `fee_breakdown` JSONB column to `tutorial_sessions` table
    - Add `price_disclaimer` text column for economic situation disclaimers
    - Update existing sessions with default fee breakdown structure

  2. Fee Breakdown Structure
    The fee_breakdown JSONB will contain:
    - registration: Registration fee amount
    - acceptance: Acceptance fee amount
    - textbook: Textbook/materials fee amount
    - tuition: Main tuition fee amount
    - examination: Examination fee amount
    - hostel: Optional hostel fee amount
    - other_fees: Array of additional fees with {name, amount, optional}
    
  3. Notes
    - Prices are subject to change based on economic conditions
    - Fee breakdown provides transparency for students
*/

-- Add fee_breakdown and price_disclaimer columns
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutorial_sessions' AND column_name = 'fee_breakdown'
  ) THEN
    ALTER TABLE tutorial_sessions ADD COLUMN fee_breakdown JSONB DEFAULT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tutorial_sessions' AND column_name = 'price_disclaimer'
  ) THEN
    ALTER TABLE tutorial_sessions ADD COLUMN price_disclaimer TEXT DEFAULT 'All fees are subject to change based on current economic conditions and institutional policies. Students will be notified of any fee adjustments.';
  END IF;
END $$;