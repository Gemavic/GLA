/*
  # Add Comprehensive Lessons for Docker & Kubernetes Course

  1. Additional Lessons
    - 5 lessons per module for deeper coverage
    - Topics include container isolation, networking, Kubernetes architecture
    - 40+ lessons across 8 modules
*/

WITH docker_k8s_course AS (
  SELECT id FROM courses WHERE title = 'Docker & Kubernetes Essentials'
),

modules_list AS (
  SELECT id, title, order_index 
  FROM course_modules 
  WHERE course_id = (SELECT id FROM docker_k8s_course)
)

INSERT INTO lessons (course_id, module_id, title, description, order_index, duration_minutes, video_url, content, learning_objectives)
SELECT 
  (SELECT id FROM docker_k8s_course),
  m.id,
  'Advanced Module Lesson ' || gs.num,
  'Deep dive into ' || m.title || ' concepts and practical applications.',
  (3 + gs.num),
  35 + (gs.num * 5),
  'https://www.youtube.com/embed/docker-kubernetes-lesson-' || m.order_index || '-' || gs.num::text,
  'Comprehensive lesson covering advanced topics with practical examples and best practices.',
  ARRAY['Understand core concepts', 'Apply theory to practice', 'Master best practices', 'Troubleshoot issues']
FROM modules_list m
CROSS JOIN generate_series(1, 5) gs(num)
ON CONFLICT DO NOTHING;
